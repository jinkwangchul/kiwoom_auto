"""M240 short source: requested capacity != available history."""
import json
import time
from pathlib import Path
from unittest.mock import Mock

from tests.test_indicator_follow_signal_validation_v4_normal_base import case, legacy
from tests.test_indicator_follow_signal_validation_v4_warmup_legend import flow_case
from indicator_follow_validation_timeframe import normalize_validation_timeframe

ROOT = Path(__file__).resolve().parents[1]


def _m240(case, requested=1400):
    rows = json.loads((ROOT / "runtime/signal_validation_v2_history_cache/005930_240_1400.json").read_text(encoding="utf-8"))["candles"]
    w, f, _s, _p, rules, _ = flow_case(case, rows, count=500, regular=False)
    rules["bar"]["bar_minutes"] = 240
    rules["validation_timeframe"] = normalize_validation_timeframe(240)
    settings = legacy.ValidationSettingsSnapshot(rules)
    session = legacy.ValidationSession(legacy.ValidationRequest(case.stock, settings, 240), operation_active_reader=lambda: False)
    pool = f._pool_from_candles(session, rows, requested_count=requested, request_id="ARCHIVED_M240", market_data_identity="005930", market_source="KRX")
    return w, f, session, pool


def test_m240_archive_reports_requested_vs_actual_independently(case):
    w, f, session, pool = _m240(case)
    assert pool["requested_count"] == 1400
    assert len(pool["candles"]) == 508
    assert pool["actual_candle_count"] == 508
    assert pool["source_request_underfilled"] is True


def test_m240_already_requested_1400_does_not_duplicate_history_probe(case):
    w, f, session, pool = _m240(case)
    provider = Mock(side_effect=AssertionError("duplicate request for already attempted 1400"))
    f._historical_provider_factory = provider
    f._history_targets[id(w)] = 500
    f._use_pool_for_window(w, session, pool, evaluation_count=100)
    deadline = time.monotonic()+12
    while time.monotonic()<deadline and not w._normal_base_ready:
        case.app.processEvents()
        time.sleep(.012)
    assert w._normal_base_ready
    provider.assert_not_called()
    assert len(w._calculation_candles) == 508
    cache = w.visualization_cache
    assert cache is not None
    assert any(channel=="RSI" and any(v is not None for v in values) for _,channel,values in cache.series)
    assert any(channel=="OSC" and any(v is not None for v in values) for _,channel,values in cache.series)


def test_m240_not_yet_requested_full_context_still_tries_more_history(case):
    w, f, session, pool = _m240(case, requested=508)
    requested = []
    class Provider:
        def request_latest(self, count, callback):
            requested.append(count)
    f._historical_provider_factory = lambda *_args:Provider()
    f._history_targets[id(w)] = 500
    f._use_pool_for_window(w, session, pool, evaluation_count=100)
    assert requested == [1400]
    assert not w._normal_base_ready



def test_m240_manual_history_path_still_attempts_required_warmup(case):
    # Manual selected-period replay must not silently bypass warmup evidence.
    w, f, session, pool = _m240(case)
    requested = []
    class Provider:
        def request_latest(self, count, callback):
            requested.append(count)
            return {"ok": True}
    f._historical_provider_factory = lambda *_args: Provider()
    f._history_targets[id(w)] = 500
    begun = f._ensure_normal_base_history(
        w, session, pool, 100, on_ready=lambda *_args: None,
    )
    assert begun is True
    assert requested == [1400]


def test_m240_prior_cache_count_does_not_advance_without_older_rows(case):
    # A cached request envelope of 1400 with only 508 rows cannot create
    # phantom history or pretend to satisfy a 900-bar warmup.
    from types import SimpleNamespace
    w, f, session, pool = _m240(case, requested=508)
    f._history_targets[id(w)] = 500
    accessed = []
    def load(_stock, _minutes, _key, requested):
        accessed.append(requested)
        return SimpleNamespace(
            requested_count=1400,
            candles=tuple(pool["candles"]),
        )
    f._cached_history = load
    requested = []
    class Provider:
        def request_latest(self, count, callback):
            requested.append(count)
    f._historical_provider_factory = lambda *_: Provider()
    f._ensure_normal_base_history(w, session, pool, 100)
    assert accessed == [509]
    assert requested == [1400]

