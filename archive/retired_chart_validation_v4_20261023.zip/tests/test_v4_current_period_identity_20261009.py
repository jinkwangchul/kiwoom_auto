"""Selected D/W/MO/Y query-time snapshots must not vanish as forming M1."""
from datetime import datetime

import pytest

from candle_timeframe_aggregation import SEOUL_TIMEZONE
from tests.test_indicator_follow_validation_replay import (
    ValidationHistoricalSnapshot,
    ValidationStockRef,
    project_validation_candles,
)
from tests.test_indicator_follow_validation_replay import (
    routine_validation_replay as replay_module,
)


@pytest.mark.parametrize("period,as_of,current_stamp", [
    ("D1", datetime(2026, 10, 9, 11, 30, tzinfo=SEOUL_TIMEZONE), "20261009000000"),
    ("W1", datetime(2026, 10, 9, 11, 30, tzinfo=SEOUL_TIMEZONE), "20261005000000"),
    ("MO1", datetime(2026, 10, 9, 11, 30, tzinfo=SEOUL_TIMEZONE), "20261001000000"),
    ("Y1", datetime(2026, 10, 9, 11, 30, tzinfo=SEOUL_TIMEZONE), "20260102000000"),
])
def test_direct_period_snapshot_retains_current_period(period, as_of, current_stamp):
    rows = [
        {"\uCCB4\uACB0\uC2DC\uAC04": current_stamp, "\uC2DC\uAC00": "120", "\uACE0\uAC00": "130", "\uC800\uAC00": "115", "\uD604\uC7AC\uAC00": "125", "\uAC70\uB798\uB7C9": "200"},
        {"\uCCB4\uACB0\uC2DC\uAC04": "20250102000000", "\uC2DC\uAC00": "95", "\uACE0\uAC00": "110", "\uC800\uAC00": "91", "\uD604\uC7AC\uAC00": "105", "\uAC70\uB798\uB7C9": "150"},
    ]
    snapshot = ValidationHistoricalSnapshot(
        stock=ValidationStockRef("005930", "Samsung"),
        timeframe_minutes=3, timeframe_key=period,
        requested_count=len(rows), request_id="CURRENT_DIRECT",
        rows=rows, market_data_identity="005930", market_source="KRX",
    )
    projected, dropped = project_validation_candles(snapshot, as_of=as_of)
    assert [row["time"] for row in projected] == ["20250102000000", current_stamp]
    assert dropped == 0
    assert projected[-1]["close"] == 125.0


def test_m1_forming_exclusion_stays_intact():
    as_of = datetime(2026, 10, 9, 11, 30, 30, tzinfo=SEOUL_TIMEZONE)
    assert replay_module._latest_candle_is_forming(
        "20261009113000", 1, timeframe_key="M1", as_of=as_of,
    ) is True


@pytest.mark.parametrize("minutes,start_stamp", [
    (3, "20261009113000"), (5, "20261009113000"),
    (10, "20261009113000"), (15, "20261009113000"),
    (30, "20261009113000"), (60, "20261009110000"),
    (120, "20261009110000"), (240, "20261009090000"),
])
def test_selected_higher_minute_query_snapshot_is_not_dropped(minutes, start_stamp):
    # A partial current higher-period broker candle is the read-time snapshot;
    # only the separately defined M1 forming bar is excluded.
    as_of = datetime(2026, 10, 9, 11, 30, 30, tzinfo=SEOUL_TIMEZONE)
    assert replay_module._latest_candle_is_forming(
        start_stamp, minutes, timeframe_key=f"M{minutes}", as_of=as_of,
    ) is False
