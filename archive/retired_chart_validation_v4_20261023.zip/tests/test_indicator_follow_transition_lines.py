import json
import os
import unittest
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication

from gui_indicator_follow_signal_validation_window import (
    IndicatorFollowSignalValidationChartCanvas,
)
from gui_indicator_follow_signal_validation_v4_window import (
    IndicatorFollowSignalValidationChartCanvas as V4IndicatorFollowSignalValidationChartCanvas,
)
from indicator_follow_signal_validation_visualization import (
    FAMILY_MACD_SIGNAL,
    FAMILY_OCR_OSC,
    LOWER_AXIS,
    ValidationFilterDescriptor,
    ValidationIndicatorSeriesCache,
    indicator_transition_indexes,
)


class IndicatorFollowTransitionLineTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_transition_indexes_use_confirmed_turn_bar_and_cross_bar_for_zero(self):
        values = (10.0, 20.0, 15.0, -5.0, 5.0)
        self.assertEqual((2,), indicator_transition_indexes(values, "TURN_DOWN"))
        self.assertEqual((4,), indicator_transition_indexes(values, "TURN_UP"))
        self.assertEqual((3,), indicator_transition_indexes(values, "ZERO_CROSS_DOWN"))
        self.assertEqual((4,), indicator_transition_indexes(values, "ZERO_CROSS_UP"))

    def test_transition_records_remain_but_lower_pane_does_not_paint_vertical_lines(self):
        values = (10.0, 20.0, 15.0, -5.0, 5.0)
        descriptors = (
            ValidationFilterDescriptor(
                identity="ocr-turn-down", family=FAMILY_OCR_OSC, label="OCR",
                axis=LOWER_AXIS, sides=("SELL",), series_keys=("OSC",),
                parameter_json=json.dumps({"condition": {"target": "OSC", "operator": "TURN_DOWN"}}),
                evidence_keys=("ocr-turn-down",),
            ),
            ValidationFilterDescriptor(
                identity="ocr-zero-down", family=FAMILY_OCR_OSC, label="OCR",
                axis=LOWER_AXIS, sides=("BUY",), series_keys=("OSC",),
                parameter_json=json.dumps({"condition": {"target": "OSC", "operator": "ZERO_CROSS_DOWN"}}),
                evidence_keys=("ocr-zero-down",),
            ),
            ValidationFilterDescriptor(
                identity="macd-turn-up", family=FAMILY_MACD_SIGNAL, label="MACD",
                axis=LOWER_AXIS, sides=("BUY",), series_keys=("MACD",),
                parameter_json=json.dumps({"condition": {"target": "MACD", "operator": "TURN_UP"}}),
                evidence_keys=("macd-turn-up",),
            ),
        )
        cache = ValidationIndicatorSeriesCache(
            candle_count=len(values),
            series=(
                ("ocr-turn-down", "OSC", values),
                ("ocr-zero-down", "OSC", values),
                ("macd-turn-up", "MACD", values),
            ),
        )
        candles = [
            {"time": f"2026092315{index:02d}00", "open": 100.0, "high": 101.0, "low": 99.0, "close": 100.0, "volume": 1}
            for index in range(len(values))
        ]
        canvas = IndicatorFollowSignalValidationChartCanvas(
            candles, [], visualization_descriptors=descriptors, visualization_cache=cache
        )
        try:
            canvas.resize(900, 560)
            records = canvas.lower_transition_line_records(FAMILY_OCR_OSC)
            by_operator = {record["operators"][0]: record for record in records}
            self.assertEqual(2, by_operator["TURN_DOWN"]["index"])
            self.assertEqual(
                "TRANSITION_VERTICAL_LINE",
                by_operator["TURN_DOWN"]["render_mode"],
            )
            self.assertEqual(3, by_operator["ZERO_CROSS_DOWN"]["index"])
            self.assertEqual(
                "TRANSITION_VERTICAL_LINE",
                by_operator["ZERO_CROSS_DOWN"]["render_mode"],
            )
            self.assertEqual(4, by_operator["TURN_UP"]["index"])
            self.assertEqual(
                "TRANSITION_VERTICAL_LINE",
                by_operator["TURN_UP"]["render_mode"],
            )
            self.assertAlmostEqual(
                canvas._x_for_index(2),
                by_operator["TURN_DOWN"]["x"],
            )
            with patch.object(
                canvas,
                "lower_transition_line_records",
                side_effect=AssertionError(
                    "transition vertical lines must not be painted"
                ),
            ) as transition_records:
                canvas.render(QPixmap(canvas.size()))
            transition_records.assert_not_called()
        finally:
            canvas.close()
            canvas.deleteLater()
            self.app.processEvents()

    def test_v4_visible_start_turn_keeps_two_predecessors(self):
        values = (10.0, 20.0, 15.0, 10.0)
        descriptor = ValidationFilterDescriptor(
            identity="ocr-turn-down", family=FAMILY_OCR_OSC, label="OCR",
            axis=LOWER_AXIS, sides=("BUY",), series_keys=("OSC",),
            parameter_json=json.dumps({"condition": {"target": "OSC", "operator": "TURN_DOWN"}}),
            evidence_keys=("ocr-turn-down",),
        )
        cache = ValidationIndicatorSeriesCache(
            candle_count=len(values), series=(("ocr-turn-down", "OSC", values),)
        )
        candles = [
            {"time": f"2026092315{index:02d}00", "open": 100.0, "high": 101.0, "low": 99.0, "close": 100.0, "volume": 1}
            for index in range(len(values))
        ]
        canvas = V4IndicatorFollowSignalValidationChartCanvas(
            candles, [], visualization_descriptors=(descriptor,), visualization_cache=cache
        )
        try:
            canvas.resize(900, 560)
            canvas.set_time_view(2, 2)
            self.assertEqual(
                [2],
                [record["index"] for record in canvas.lower_transition_line_records(FAMILY_OCR_OSC)],
            )
            canvas.set_valid_filter_identities({("BUY", descriptor.identity)})
            self.assertEqual(
                "#22c55e",
                canvas._histogram_valid_signal_color(2, (descriptor,)).name(),
            )
            self.assertIsNone(canvas._histogram_valid_signal_color(1, (descriptor,)))
        finally:
            canvas.close()
            canvas.deleteLater()
            self.app.processEvents()

    def test_v4_buy_ocr_valid_histogram_uses_configured_delay_only_for_turns(self):
        values = (3.0, 2.0, 3.0, 4.0, 3.0, 2.0, 3.0, 4.0, 3.0)
        zero_values = (-2.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0)
        descriptors = (
            ValidationFilterDescriptor(
                identity="ocr-turn-up-zero", family=FAMILY_OCR_OSC, label="OCR",
                axis=LOWER_AXIS, sides=("BUY",), series_keys=("OSC",),
                parameter_json=json.dumps({"condition": {"target": "OSC", "operator": "TURN_UP"}}),
                evidence_keys=("ocr-turn-up-zero",),
            ),
            ValidationFilterDescriptor(
                identity="ocr-turn-up-two", family=FAMILY_OCR_OSC, label="OCR",
                axis=LOWER_AXIS, sides=("BUY",), series_keys=("OSC",),
                parameter_json=json.dumps({"condition": {"target": "OSC", "operator": "TURN_UP"}}),
                evidence_keys=("ocr-turn-up-two",),
            ),
            ValidationFilterDescriptor(
                identity="ocr-turn-down-four", family=FAMILY_OCR_OSC, label="OCR",
                axis=LOWER_AXIS, sides=("BUY",), series_keys=("OSC",),
                parameter_json=json.dumps({"condition": {"target": "OSC", "operator": "TURN_DOWN"}}),
                evidence_keys=("ocr-turn-down-four",),
            ),
            ValidationFilterDescriptor(
                identity="ocr-zero-cross", family=FAMILY_OCR_OSC, label="OCR",
                axis=LOWER_AXIS, sides=("BUY",), series_keys=("OSC",),
                parameter_json=json.dumps({"condition": {"target": "OSC", "operator": "ZERO_CROSS_UP"}}),
                evidence_keys=("ocr-zero-cross",),
            ),
        )
        cache = ValidationIndicatorSeriesCache(
            candle_count=len(values),
            series=tuple(
                (descriptor.identity, "OSC", zero_values if descriptor.identity == "ocr-zero-cross" else values)
                for descriptor in descriptors
            ),
        )
        candles = [
            {"time": f"2026092315{index:02d}00", "open": 100.0, "high": 101.0, "low": 99.0, "close": 100.0, "volume": 1}
            for index in range(len(values))
        ]
        canvas = V4IndicatorFollowSignalValidationChartCanvas(
            candles, [], visualization_descriptors=descriptors, visualization_cache=cache
        )
        try:
            canvas.set_valid_filter_identities(
                {("BUY", descriptor.identity) for descriptor in descriptors},
                delay_ranges={
                    ("BUY", "ocr-turn-up-zero"): ((0, 8, 0),),
                    ("BUY", "ocr-turn-up-two"): ((0, 8, 2),),
                    ("BUY", "ocr-turn-down-four"): ((0, 8, 4),),
                    ("BUY", "ocr-zero-cross"): ((0, 8, 4),),
                },
            )
            by_identity = {descriptor.identity: descriptor for descriptor in descriptors}
            self.assertEqual("#22c55e", canvas._histogram_valid_signal_color(2, (by_identity["ocr-turn-up-zero"],)).name())
            self.assertEqual("#22c55e", canvas._histogram_valid_signal_color(4, (by_identity["ocr-turn-up-two"],)).name())
            self.assertEqual("#22c55e", canvas._histogram_valid_signal_color(8, (by_identity["ocr-turn-down-four"],)).name())
            self.assertIsNone(canvas._histogram_valid_signal_color(2, (by_identity["ocr-turn-up-two"],)))
            self.assertIsNone(canvas._histogram_valid_signal_color(4, (by_identity["ocr-turn-down-four"],)))
            self.assertEqual("#22c55e", canvas._histogram_valid_signal_color(2, (by_identity["ocr-zero-cross"],)).name())
            self.assertIsNone(canvas._histogram_valid_signal_color(6, (by_identity["ocr-zero-cross"],)))
        finally:
            canvas.close()
            canvas.deleteLater()
            self.app.processEvents()


if __name__ == "__main__":
    unittest.main()
