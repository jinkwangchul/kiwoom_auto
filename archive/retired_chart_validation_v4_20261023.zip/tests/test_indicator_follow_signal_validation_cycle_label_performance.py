# -*- coding: utf-8 -*-
from __future__ import annotations

import math
import json
import os
import unittest
from pathlib import Path
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PyQt5.QtCore import QRectF
from PyQt5.QtGui import QFont, QFontMetrics
from PyQt5.QtWidgets import QApplication

import gui_indicator_follow_signal_validation_window as window
import gui_indicator_follow_signal_validation_v4_window as v4


def _reference_label_records(canvas, scale=None, *, sell_local=False):
    """Frozen global oracle by default; V4 can restrict only candidate eligibility."""
    resolved_scale = scale if scale is not None else canvas.price_scale()
    if resolved_scale is None:
        return []
    line_records = canvas.completed_cycle_average_line_records(resolved_scale)
    if not line_records:
        return []

    metrics = QFontMetrics(canvas.font())
    line_height = max(14, metrics.height() + 1)
    block_height = float(line_height * 3)
    plot_left = float(canvas.plot_left) + 4.0
    plot_right = float(canvas.width() - canvas._RIGHT) - 4.0
    plot_top = float(resolved_scale.plot_top) + 4.0
    plot_bottom = float(resolved_scale.plot_bottom) - 4.0
    blockers = canvas._completed_cycle_label_blockers(resolved_scale)
    labels = []

    for record in sorted(
        line_records,
        key=lambda item: (float(item["x2"]), int(item["cycle_number"])),
    ):
        texts = (
            f"평단 {window._validation_price_text(record['average_buy_price'])}",
            f"매도 {window._validation_price_text(record['sell_price'])}",
            (
                f"손익 {window._format_summary_return_percent(record['estimated_return_percent'])}/"
                f"{window._format_summary_amount(record['profit_amount'], signed=True)}"
            ),
        )
        label_width = float(
            max(metrics.horizontalAdvance(text) for text in texts) + 4
        )
        max_left = plot_right - label_width
        max_top = plot_bottom - block_height
        if max_left < plot_left or max_top < plot_top:
            continue

        anchor_x = float(record["x2"])
        anchor_y = float(record["y"])
        preferred_left = anchor_x + 16.0

        x_candidates = []
        if preferred_left <= max_left:
            x_candidates.append(preferred_left)
            grid_start = max(preferred_left, plot_left)
        else:
            grid_start = plot_left
        x_candidates.extend((max_left, plot_left))
        x_step = max(36.0, min(90.0, label_width * 0.45))
        cursor_x = grid_start
        while cursor_x <= max_left + 0.5:
            x_candidates.append(cursor_x)
            cursor_x += x_step

        if preferred_left <= max_left:
            x_candidates = [
                value for value in x_candidates
                if value >= preferred_left - 0.5
            ]
        if not x_candidates:
            x_candidates = [plot_left, max_left]

        y_candidates = [
            min(max(plot_top, anchor_y - block_height / 2.0), max_top),
            plot_top,
            max_top,
        ]
        y_step = max(12.0, float(line_height))
        cursor_y = plot_top
        while cursor_y <= max_top + 0.5:
            y_candidates.append(cursor_y)
            cursor_y += y_step

        x_candidates = list(dict.fromkeys(round(v, 3) for v in x_candidates))
        y_candidates = list(dict.fromkeys(round(v, 3) for v in y_candidates))

        best = None
        for label_left in x_candidates:
            if sell_local and max(label_left - anchor_x,
                                  anchor_x - label_left - label_width, 0.) > label_width:
                continue
            for label_top in y_candidates:
                rect = QRectF(
                    float(label_left),
                    float(label_top),
                    label_width,
                    block_height,
                )
                expanded = rect.adjusted(-4.0, -4.0, 4.0, 4.0)
                overlaps = [
                    canvas._rect_overlap_area(expanded, blocker)
                    for blocker in blockers
                ]
                collision_count = float(sum(area > 0.0 for area in overlaps))
                overlap_area = float(sum(overlaps))
                center = rect.center()
                distance = math.hypot(
                    float(center.x()) - anchor_x,
                    float(center.y()) - anchor_y,
                )
                right_penalty = (
                    0.0 if rect.left() >= anchor_x + 8.0 else 120.0
                )
                score = (
                    1.0 if collision_count else 0.0,
                    overlap_area,
                    collision_count,
                    distance + right_penalty,
                )
                if best is None or score < best[0]:
                    best = (score, rect)

        if best is None:
            continue
        label_rect = best[1]
        blockers.append(label_rect.adjusted(-6.0, -6.0, 6.0, 6.0))

        label_left = float(label_rect.left())
        label_top = float(label_rect.top())
        if label_left >= anchor_x:
            leader_end_x = label_left - 4.0
        else:
            leader_end_x = float(label_rect.right()) + 4.0
        leader_end_y = label_top + line_height / 2.0
        placement = "TOP" if label_rect.center().y() < anchor_y else "BOTTOM"

        labels.append({
            **record,
            "texts": texts,
            "label_left": label_left,
            "label_top": label_top,
            "label_width": label_width,
            "label_height": block_height,
            "line_height": float(line_height),
            "placement": placement,
            "collision_count": int(best[0][2]),
            "overlap_area": float(best[0][1]),
            "leader_x1": anchor_x,
            "leader_y1": anchor_y,
            "leader_x2": leader_end_x,
            "leader_y2": leader_end_y,
        })
    return labels


def _candles(count):
    return [
        {
            "time": f"20261002{9 + index // 60:02d}{index % 60:02d}00",
            "open": 100.0 + index % 5,
            "high": 103.25 + index % 5,
            "low": 97.75 + index % 5,
            "close": 101.0 + index % 5,
            "volume": 1,
        }
        for index in range(count)
    ]


def _cycle(number, start, sell, price):
    return window.IndicatorFollowValidationCompletedCycle(
        cycle_number=number,
        buy_indexes=(start,),
        buy_start_index=start,
        buy_end_index=start,
        buy_count=1,
        average_buy_price=price,
        sell_index=sell,
        sell_price=price + number * 0.125,
        estimated_return_percent=number * 0.03125,
    )


class CompletedCycleLabelPerformanceRegressionTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.widgets = []

    def tearDown(self):
        for widget in self.widgets:
            widget.close()

    def _canvas(self, *, markers=()):
        canvas = window.IndicatorFollowSignalValidationChartCanvas(
            _candles(28), list(markers)
        )
        canvas.resize(741, 463)
        canvas.set_time_view(1.25, 17.5)
        canvas.set_validation_range(0, 27)
        canvas.set_completed_cycle_average_lines((
            _cycle(1, 2, 9, 100.125),
            _cycle(2, 3, 10, 100.25),
            _cycle(3, 4, 11, 100.375),
            _cycle(4, 5, 12, 100.5),
        ))
        self.widgets.append(canvas)
        return canvas

    def test_matches_frozen_reference_for_overlaps_fractional_edges_and_ties(self):
        canvas = self._canvas(markers=(
            {"evaluation_index": 9, "side": "BUY"},
            {"evaluation_index": 10, "side": "SELL"},
        ))
        self.assertEqual(_reference_label_records(canvas),
                         canvas.completed_cycle_average_label_records())

        synthetic = self._canvas()
        scale = window._ValidationPriceScale(90.0, 110.0, 42, 301)
        records = [
            {
                "cycle_number": number,
                "buy_start_index": 0,
                "sell_index": number,
                "average_buy_price": 100.0 + number / 8,
                "sell_price": 101.0 + number / 8,
                "estimated_return_percent": 1.0,
                "profit_amount": 1.0,
                "x1": 20.25,
                "x2": 211.125,
                "y": 151.375,
            }
            for number in (1, 2, 3)
        ]
        blockers = [
            QRectF(227.125, 130.25, 31.5, 42.75),
            QRectF(258.625, 130.25, 20.0, 42.75),  # touches the prior edge
            QRectF(120.5, 42.0, 400.25, 34.0),
            QRectF(430.75, 214.125, 51.5, 44.5),
        ]
        with (
            patch.object(synthetic, "completed_cycle_average_line_records",
                         return_value=records),
            patch.object(synthetic, "_completed_cycle_label_blockers",
                         side_effect=lambda *_: list(blockers)),
        ):
            self.assertEqual(
                _reference_label_records(synthetic, scale),
                synthetic.completed_cycle_average_label_records(scale),
            )

    def test_empty_and_no_room_match_reference(self):
        empty = window.IndicatorFollowSignalValidationChartCanvas(_candles(3), [])
        self.widgets.append(empty)
        self.assertEqual([], empty.completed_cycle_average_label_records())

        canvas = self._canvas()
        no_room_scale = window._ValidationPriceScale(90.0, 110.0, 42, 70)
        self.assertEqual(
            _reference_label_records(canvas, no_room_scale),
            canvas.completed_cycle_average_label_records(no_room_scale),
        )
        self.assertEqual([], canvas.completed_cycle_average_label_records(no_room_scale))

    def test_repeated_call_reuses_blockers_and_returns_fresh_records(self):
        canvas = self._canvas()
        original = canvas._completed_cycle_label_blockers
        with patch.object(
            canvas, "_completed_cycle_label_blockers", wraps=original
        ) as blockers:
            first = canvas.completed_cycle_average_label_records()
            second = canvas.completed_cycle_average_label_records()
            self.assertEqual(1, blockers.call_count)
            self.assertEqual(first, second)
            self.assertIsNot(first, second)
            self.assertIsNot(first[0], second[0])
            first[0]["texts"] = ("mutated",)
            self.assertEqual(second, canvas.completed_cycle_average_label_records())
            self.assertEqual(1, blockers.call_count)

    def test_cache_invalidates_for_all_layout_inputs_and_same_length_changes(self):
        canvas = self._canvas()
        original = canvas._completed_cycle_label_blockers
        with patch.object(
            canvas, "_completed_cycle_label_blockers", wraps=original
        ) as blockers:
            canvas.completed_cycle_average_label_records()
            expected_calls = 1

            changes = []
            changes.append(lambda: canvas.set_time_view(2.25, 17.5))
            changes.append(lambda: canvas.resize(743, 467))
            changes.append(lambda: canvas.setFont(QFont("Arial", 11)))
            changes.append(lambda: canvas.set_price_view(94.0, 112.0))
            changes.append(lambda: canvas.set_visualization_projection(
                (), None, {}, [{"evaluation_index": 9, "side": "BUY"}]
            ))
            changes.append(lambda: canvas.set_visualization_projection(
                (), None, {}, []
            ))
            changes.append(lambda: canvas.set_completed_cycle_average_lines((
                _cycle(1, 2, 9, 100.125),
                _cycle(2, 3, 10, 100.25),
                _cycle(3, 4, 11, 100.375),
            )))
            changes.append(lambda: canvas.set_completed_cycle_average_lines((
                _cycle(1, 2, 9, 100.125),
                _cycle(2, 3, 10, 100.25),
                _cycle(3, 4, 11, 100.375),
                _cycle(5, 5, 12, 100.625),
            )))
            changes.append(lambda: canvas._candles[9].update(high=109.875))

            for change in changes:
                change()
                canvas.completed_cycle_average_label_records()
                expected_calls += 1
                self.assertEqual(expected_calls, blockers.call_count)

            with patch.object(canvas, "_price_legend_rows", return_value=[("A",)]):
                canvas.completed_cycle_average_label_records()
                expected_calls += 1
                self.assertEqual(expected_calls, blockers.call_count)

            explicit_scale = window._ValidationPriceScale(93.5, 113.25, 43, 399)
            canvas.completed_cycle_average_label_records(explicit_scale)
            self.assertEqual(expected_calls + 1, blockers.call_count)

            # DPI participates even when the logical layout happens to be unchanged.
            with patch.object(canvas, "devicePixelRatioF", return_value=1.25):
                canvas.completed_cycle_average_label_records(explicit_scale)
                self.assertEqual(expected_calls + 2, blockers.call_count)


    def test_optional_array_unavailable_keeps_exact_spatial_result(self):
        import sys
        canvas = self._canvas(markers=(
            {"evaluation_index": 9, "side": "BUY"},
            {"evaluation_index": 10, "side": "SELL"},
        ))
        expected = _reference_label_records(canvas)
        with patch.dict(sys.modules, {"numpy": None}):
            actual = canvas.completed_cycle_average_label_records()
        self.assertEqual(expected, actual)

    def test_no_blockers_keeps_exact_candidate_ties(self):
        canvas = self._canvas()
        with patch.object(canvas, "_completed_cycle_label_blockers", side_effect=lambda *_: []):
            self.assertEqual(_reference_label_records(canvas),
                             canvas.completed_cycle_average_label_records())


    def test_boolean_marker_index_cannot_share_integer_cache_entry(self):
        canvas = self._canvas()
        for index in (True, 1, True, 1.0, 1):
            canvas.set_visualization_projection((), None, {}, [
                {"evaluation_index": index, "side": "BUY"},
            ])
            expected = _reference_label_records(canvas)
            with patch.object(canvas, "_completed_cycle_label_blockers",
                              wraps=canvas._completed_cycle_label_blockers) as blockers:
                actual = canvas.completed_cycle_average_label_records()
                self.assertEqual(1, blockers.call_count)
                self.assertEqual(expected, actual)


class V4LocalLabelParityTest(CompletedCycleLabelPerformanceRegressionTest):
    def setUp(self):
        super().setUp()
        module = patch(__name__ + ".window", v4)
        module.start()
        self.addCleanup(module.stop)
        self.frozen_reference = _reference_label_records
        # The synthetic overlapping cycles' global winner can be too far from SELL.
        # V2 keeps the frozen default; V4 changes only the eligible candidate domain.
        reference = patch(__name__ + '._reference_label_records',
                          side_effect=lambda c, s=None: self.frozen_reference(c, s, sell_local=True))
        reference.start()
        self.addCleanup(reference.stop)

    def test_already_local_labels_keep_unbounded_oracle_outcome(self):
        canvas = self._canvas(markers=({'evaluation_index': 9, 'side': 'BUY'},
                                       {'evaluation_index': 10, 'side': 'SELL'}))
        self.assertEqual(self.frozen_reference(canvas), canvas.completed_cycle_average_label_records())


class V4ArchivedM3LabelTest(unittest.TestCase):
    setUpClass = classmethod(CompletedCycleLabelPerformanceRegressionTest.setUpClass.__func__)
    setUp = CompletedCycleLabelPerformanceRegressionTest.setUp
    tearDown = CompletedCycleLabelPerformanceRegressionTest.tearDown

    def _m3_canvas(self, count=5900):
        path = Path(__file__).resolve().parents[1] / "runtime/signal_validation_v2_history_cache/005930_3_5900.json"
        archive = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(("KRX", "M3"), (archive["market_source"], archive["timeframe_key"]))
        rows = archive["candles"]
        self.assertEqual(5900, len(rows))
        self.assertEqual("20260921090000", rows[3601]["time"])
        self.assertEqual("20261008115700", rows[5750]["time"])
        self.assertEqual("20261008135400", rows[5789]["time"])
        offset = 5900 - count
        markers = [{"evaluation_index": i - offset, "evaluation_time": rows[i]["time"],
                    "side": "BUY" if n % 2 == 0 else "SELL"}
                   for n, i in enumerate(range(3601, 5900, 7))]
        # Known endpoints and displayed economics from the operator's investigation;
        # this is a geometry fixture, not a reconstruction of the four fill events.
        markers += [{"evaluation_index": i - offset, "evaluation_time": rows[i]["time"], "side": side}
                    for i, side in ((5750, "BUY"), (5789, "SELL"))]
        canvas = v4.IndicatorFollowSignalValidationChartCanvas(rows[offset:], markers)
        self.widgets.append(canvas)
        canvas.resize(1400, 210)
        canvas.setFont(QFont("Malgun Gothic", 9))
        canvas.set_time_view(3601 - offset, 2299)
        canvas.set_validation_range(3601 - offset, 5899 - offset)
        canvas.set_completed_cycle_average_lines((v4.IndicatorFollowValidationCompletedCycle(
            cycle_number=1, buy_indexes=(5750 - offset,), buy_start_index=5750 - offset,
            buy_end_index=5750 - offset, buy_count=4, average_buy_price=264442.,
            sell_index=5789 - offset, sell_price=rows[5789]["close"],
            estimated_return_percent=(rows[5789]["close"] / 264442. - 1.) * 100.,
        ),))
        original = canvas.completed_cycle_average_line_records
        supplied_pnl = patch.object(canvas, "completed_cycle_average_line_records",
            side_effect=lambda *args: [dict(r, profit_amount=30000.) for r in original(*args)])
        supplied_pnl.start()
        self.addCleanup(supplied_pnl.stop)
        return canvas

    def assert_local(self, canvas, record):
        rect = QRectF(record['label_left'], record['label_top'],
                      record['label_width'], record['label_height'])
        self.assertTrue(canvas._price_plot_rect(canvas.price_scale()).contains(rect), record)
        dx = max(rect.left() - record['x2'], record['x2'] - rect.right(), 0.)
        dy = max(rect.top() - record['y'], record['y'] - rect.bottom(), 0.)
        self.assertLessEqual(math.hypot(dx, dy), record['label_width'] + .001, record)
        leader = math.hypot(record['leader_x2'] - record['x2'], record['leader_y2'] - record['y'])
        self.assertLessEqual(abs(record['leader_x2'] - record['x2']), record['label_width'] + 4.)
        scale = canvas.price_scale()
        self.assertLessEqual(leader, math.hypot(record['label_width'] + 4,
                                             scale.plot_bottom - scale.plot_top), record)

    def test_settled_m3_label_stays_near_oct8_sell(self):
        canvas = self._m3_canvas()
        records = canvas._cycle_label_records_for_paint(canvas.price_scale())
        self.assertEqual(1, len(records))
        self.assert_local(canvas, records[0])
        for key, value in canvas.completed_cycle_average_line_records()[0].items():
            self.assertEqual(value, records[0][key])

    def test_m3_preview_repairs_remote_prior_label_without_exact_search(self):
        canvas = self._m3_canvas()
        saved = canvas._cycle_label_records_for_paint(canvas.price_scale())[0]
        from tests.test_indicator_follow_cycle_label_deferred import Owner
        owner = Owner(canvas)
        canvas._input_frame_owner = owner
        # A stale global placement may be onscreen but remote, or transform offscreen.
        for start, span, left, top in ((3602, 2298, 106., saved['label_top']),
                                      (4100, 1800, 106., saved['label_top']),
                                      (4100, 1800, 1134., -100.)):
            with self.subTest(start=start, top=top):
                canvas._cancel_cycle_label_preview()
                owner.busy = False
                canvas.set_time_view(3601, 2299)
                canvas._cycle_label_last_records = (dict(saved, label_left=left, label_top=top),)
                canvas._cycle_label_last_affine = canvas._cycle_label_view_affine(canvas.price_scale())
                canvas._cycle_label_last_context = canvas._cycle_label_preview_context()
                owner.busy = True
                with patch.object(canvas, 'completed_cycle_average_label_records',
                                  side_effect=AssertionError('preview ran exact search')):
                    canvas.set_time_view(start, span)
                    self.assertTrue(canvas._cycle_label_preview_active)
                    record = canvas._cycle_label_records_for_paint(canvas.price_scale())[0]
                    self.assert_local(canvas, record)
                    self.assertEqual(saved['texts'], record['texts'])
                    self.assertEqual(30000., record['profit_amount'])

    def test_m3_preview_no_room_omits_text_just_like_exact_layout(self):
        canvas = self._m3_canvas()
        canvas._cycle_label_records_for_paint(canvas.price_scale())
        from tests.test_indicator_follow_cycle_label_deferred import Owner
        canvas._input_frame_owner = Owner(canvas)
        canvas.set_time_view(4100, 1800)
        scale = v4._ValidationPriceScale(240000., 280000., 42, 70)
        self.assertEqual([], canvas._cycle_label_records_for_paint(scale))
        self.assertEqual([], canvas.completed_cycle_average_label_records(scale))

    def test_m3_offscreen_cycle_and_unselected_range_have_no_labels(self):
        canvas = self._m3_canvas()
        canvas._cycle_label_records_for_paint(canvas.price_scale())
        from tests.test_indicator_follow_cycle_label_deferred import Owner
        canvas._input_frame_owner = Owner(canvas)
        canvas.set_time_view(3601, 1000)
        self.assertEqual([], canvas._cycle_label_records_for_paint(canvas.price_scale()))
        self.assertEqual([], canvas.completed_cycle_average_label_records())
        canvas.set_time_view(4100, 1800)
        canvas.set_validation_range(None, None)
        self.assertEqual([], canvas._cycle_label_records_for_paint(canvas.price_scale()))

    def test_m3_prefix_5000_to_5900_keeps_time_geometry_and_handoff(self):
        old, new = self._m3_canvas(5000), self._m3_canvas()
        before = old._cycle_label_records_for_paint(old.price_scale())[0]
        handoff = old.capture_cycle_label_handoff()
        self.assertIsNotNone(handoff)
        self.assertTrue(new.install_cycle_label_handoff(handoff))
        after = new._cycle_label_records_for_paint(new.price_scale())[0]
        new._completed_cycle_label_cache_key = None
        exact = new.completed_cycle_average_label_records()
        self.assertEqual([after], exact)
        for key in ('buy_start_index', 'sell_index'):
            self.assertEqual(before[key] + 900, after[key])
            self.assertEqual(old._candles[before[key]]['time'], new._candles[after[key]]['time'])
        for key in ('x1', 'x2', 'y', 'label_left', 'label_top', 'texts', 'profit_amount'):
            self.assertEqual(before[key], after[key])
        self.assert_local(new, after)

    def test_m3_changed_marker_rejects_handoff(self):
        old, new = self._m3_canvas(5000), self._m3_canvas()
        old._cycle_label_records_for_paint(old.price_scale())
        new._markers[0]['side'] = 'SELL'
        self.assertFalse(new.install_cycle_label_handoff(old.capture_cycle_label_handoff()))
        self.assert_local(new, new._cycle_label_records_for_paint(new.price_scale())[0])

    def test_m3_navigation_preview_then_single_settle_keeps_anchor_and_text(self):
        from PyQt5.QtTest import QTest
        from tests.test_indicator_follow_cycle_label_deferred import Owner
        canvas = self._m3_canvas()
        before = canvas._cycle_label_records_for_paint(canvas.price_scale())[0]
        owner = Owner(canvas)
        canvas._input_frame_owner = owner
        with patch.object(canvas, 'completed_cycle_average_label_records',
                          wraps=canvas.completed_cycle_average_label_records) as exact:
            for start, span in ((3700, 2200), (4000, 1900), (4100, 1800)):
                canvas.set_time_view(start, span)
                current = canvas._cycle_label_records_for_paint(canvas.price_scale())[0]
                self.assert_local(canvas, current)
                self.assertEqual(before['texts'], current['texts'])
                for key, value in canvas.completed_cycle_average_line_records()[0].items():
                    self.assertEqual(value, current[key])
            self.assertEqual(0, exact.call_count)
            owner.busy = False
            QTest.qWait(250)
            settled = canvas._cycle_label_records_for_paint(canvas.price_scale())[0]
            self.assertEqual(1, exact.call_count)
            self.assert_local(canvas, settled)
            self.assertEqual(current['texts'], settled['texts'])
            self.assertEqual(current['x2'], settled['x2'])


if __name__ == "__main__":
    unittest.main()
