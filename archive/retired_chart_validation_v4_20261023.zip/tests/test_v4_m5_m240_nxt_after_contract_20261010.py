# -*- coding: utf-8 -*-
"""V4 selected M5-M240 direct NXT AFTER source; isolated, no broker IO."""
from copy import deepcopy
from datetime import datetime

import pytest

from tests.test_indicator_follow_signal_validation_v4_normal_base import case, legacy
from tests.test_indicator_follow_signal_validation_v4_warmup_legend import flow_case
from indicator_follow_validation_timeframe import normalize_validation_timeframe
from gui_indicator_follow_signal_validation_v4_window import (
    _calculation_indexes_for_mixed_display, _build_validation_projection_data,
)


MINUTES = (5, 10, 15, 30, 60, 120, 240)


def bars(*times):
    return [
        dict(time=t, open=100., high=102., low=99., close=101., volume=2.)
        for t in times
    ]


def setup(case, minutes, regular):
    raw = bars(
        "20260921090000", "20260921130000", "20260922090000",
        "20260922153000", "20260922160000",
    )
    window, flow, _session, _pool, rules, _ = flow_case(
        case, raw, count=len(raw), regular=regular,
    )
    rules["bar"]["bar_minutes"] = minutes
    rules["validation_timeframe"] = normalize_validation_timeframe(minutes)
    rules["validation_market_scope"] = {"regular_market_only": regular}
    settings = legacy.ValidationSettingsSnapshot(rules)
    session = legacy.ValidationSession(
        legacy.ValidationRequest(case.stock, settings, minutes),
        operation_active_reader=lambda: False,
    )
    pool = flow._pool_from_candles(
        session, raw, requested_count=len(raw), request_id="DIRECT_KRX",
        market_data_identity=case.stock.code, market_source="KRX",
    )
    return window, flow, session, pool, rules


def sidecar(case, minutes, *stamps, as_of="2026-09-22T20:00:00+09:00"):
    return dict(
        stock_code=case.stock.code, timeframe_key=f"M{minutes}",
        timeframe_minutes=minutes,
        market_data_identity=case.stock.code + "_AL",
        market_source="INTEGRATED", display_only=True,
        verified_nxt_eligible=True, request_as_of=as_of,
        candles=bars(*stamps),
    )


@pytest.mark.parametrize("minutes", MINUTES)
@pytest.mark.parametrize("regular", (False, True))
def test_after_calculation_and_osc_use_direct_selected_frame(
    case, minutes, regular,
):
    window, flow, session, pool, rules = setup(case, minutes, regular)
    original = deepcopy(pool["candles"])
    after_stamps = ("20260922170000",)
    flow._integrated_display_sidecars[
        flow._integrated_display_sidecar_key(session)
    ] = sidecar(case, minutes, *after_stamps)
    view = flow._validation_pool_for_session(session, pool, target_count=30)
    assert view["market_source"] == "VALIDATION_COMPOSITE"
    assert view["snapshot"].market_source == "VALIDATION_COMPOSITE"
    assert view["snapshot"].timeframe_key == f"M{minutes}"
    assert view["validation_aftermarket_calculation"] is True
    assert all(t in {r["time"] for r in view["candles"]} for t in after_stamps)
    assert pool["market_source"] == "KRX"
    assert pool["candles"] == original

    if regular:
        assert "20260922170000" not in {
            r["time"] for r in view["display_candles"]
        }
    else:
        display = view["display_candles"]
        indexes = _calculation_indexes_for_mixed_display(view["candles"], display)
        after_index = next(
            i for i, row in enumerate(display) if row["time"] == after_stamps[0]
        )
        assert indexes[after_index] is not None
        descriptors = tuple(window._filter_display_descriptors(rules))
        cache, _ = _build_validation_projection_data(
            view["candles"], [], [], indexes, rules, descriptors,
        )
        assert any(
            channel == "OSC" and values[after_index] is not None
            for _, channel, values in cache.series
        )


@pytest.mark.parametrize("minutes", MINUTES)
def test_live_open_after_bucket_is_not_calculation_input(case, minutes):
    window, flow, session, pool, rules = setup(case, minutes, False)
    # Last available broker target has a truncated bucket ending at 20:00,
    # including M120 19:00 and M240 17:00.
    stamp = "20260922170000" if minutes == 240 else "20260922190000"
    flow._integrated_display_sidecars[
        flow._integrated_display_sidecar_key(session)
    ] = sidecar(
        case, minutes, stamp, as_of="2026-09-22T19:59:59+09:00"
        if minutes >= 120 else "2026-09-22T19:00:01+09:00",
    )
    view = flow._validation_pool_for_session(session, pool, target_count=20)
    assert stamp not in {row["time"] for row in view["candles"]}
    assert stamp in {row["time"] for row in view["display_candles"]}


@pytest.mark.parametrize("minutes", MINUTES)
def test_unverified_after_rejected_and_krx_raw_stable(case, minutes):
    window, flow, session, pool, rules = setup(case, minutes, False)
    s = sidecar(case, minutes, "20260922170000")
    s["verified_nxt_eligible"] = False
    flow._integrated_display_sidecars[
        flow._integrated_display_sidecar_key(session)
    ] = s
    before = deepcopy(pool)
    view = flow._validation_pool_for_session(session, pool, target_count=30)
    assert view["market_source"] == "KRX"
    assert "20260922170000" not in {
        row["time"] for row in view["candles"]
    }
    assert pool["candles"] == before["candles"]
