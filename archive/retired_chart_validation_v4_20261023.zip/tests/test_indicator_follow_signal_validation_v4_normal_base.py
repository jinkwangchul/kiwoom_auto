"""V4 Phase 1: real normal chart readiness without signal evidence."""
from copy import deepcopy
from dataclasses import replace
from datetime import datetime, timedelta
import json
import time
from unittest.mock import Mock, patch

import pytest
from PyQt5.QtCore import Qt, QPoint, QPointF, QEvent, QSignalBlocker, QRectF
from PyQt5.QtGui import QColor, QWheelEvent, QMouseEvent, QKeyEvent, QFocusEvent, QPixmap, QFont, QFontMetrics, QPen, QImage, QPainter
from PyQt5.QtWidgets import QApplication
from PyQt5.QtTest import QTest

from engines.condition_engine import evaluate_group
import gui_indicator_follow_signal_validation_v4_window as wm
import gui_indicator_follow_signal_validation_v4_flow as fm
from tests import test_indicator_follow_signal_validation_v2 as legacy
from tests.test_indicator_follow_signal_validation_persistent_history_flow import _candles, _result
from tests.test_indicator_follow_signal_validation_visualization import (
    _realistic_lower_presentation_rules,
)


@pytest.fixture
def case():
    cls = legacy.IndicatorFollowSignalValidationV2Test
    cls.setUpClass()
    obj = cls(methodName="runTest")
    obj.setUp()
    fm._SHARED_SIGNAL_VALIDATION_HISTORICAL_POOLS.clear()
    try:
        yield obj
    finally:
        obj.tearDown()
        fm._SHARED_SIGNAL_VALIDATION_HISTORICAL_POOLS.clear()


def window_for(case):
    with patch.object(legacy.dialog_module.QTimer, "singleShot"):
        window = wm.IndicatorFollowSignalValidationV4Window(case.stock, case._seed())
    case.widgets.append(window)
    return window


def candles(count=600):
    rows = []
    stamp = datetime(2026, 10, 7, 15, 30)
    while len(rows) < count:
        rows.extend(_candles(1, 1, stamp, base=100_000 + len(rows)))
        stamp -= timedelta(minutes=1)
        if stamp.hour < 9:
            stamp = (stamp - timedelta(days=1)).replace(hour=15, minute=30)
    return list(reversed(rows))


def install(window, rows=None):
    rows = candles() if rows is None else rows
    window.set_historical_candle_pool(rows, chart_candle_count=len(rows))
    window.install_normal_base(window._signal_validation_seed.settings_snapshot, "M1")


def wait_for(case, predicate):
    deadline = time.monotonic() + 30
    while not predicate() and time.monotonic() < deadline:
        case.app.processEvents()
        QTest.qWait(10)
    assert predicate()


def execution_refresh_flow(case, count=100, *, evaluator_calls=None):
    window = window_for(case)
    window.validation_first_buy_quantity_line.setText("2")
    window.validation_repeat_mode_combo.setCurrentIndex(1)
    window.validation_budget_ratio_line.setText("2.0")
    window.validation_trading_cost_percent_line.setText("1.0")
    settings = window._marking_current_settings()
    timeframe_key = fm.validation_timeframe_from_rules(settings.to_dict())["key"]
    warmup = fm.required_validation_history_context_bars(settings.to_dict())
    rows = candles(count + warmup)
    window.set_historical_candle_pool(rows, chart_candle_count=count)
    window.install_normal_base(settings, timeframe_key)

    def evaluator(prefix, rules, context):
        if evaluator_calls is not None:
            evaluator_calls.append((
                len(prefix),
                context["_indicator_follow_evaluate_side"],
            ))
        index = len(prefix) - 1
        side = context["_indicator_follow_evaluate_side"]
        signal = (
            side
            if (side == "BUY" and index in (warmup + 5, warmup + 10))
            or (side == "SELL" and index == warmup + 15)
            else None
        )
        return legacy.RoutineSignal(
            signal,
            "execution refresh fixture",
            [],
            [],
            index if signal else -1,
            0,
        )

    session = legacy.ValidationSession(legacy.ValidationRequest(
        case.stock,
        settings,
        settings.to_dict()["bar"]["bar_minutes"],
    ), operation_active_reader=lambda: False)
    flow = fm.IndicatorFollowSignalValidationV4Flow(
        object(),
        host=legacy._FakeHost(case.stock),
        replay_factory=lambda value: legacy.ValidationHistoricalReplay(
            value,
            evaluator=evaluator,
        ),
        historical_cache=case.default_history_cache,
        historical_count=count,
    )
    fixed_now = datetime.now(fm.SEOUL_TIMEZONE).replace(second=0, microsecond=0)
    flow._now_factory = lambda: fixed_now
    key = id(window)
    flow._open_windows[key] = window
    flow._request_generation[key] = 0
    flow._history_targets[key] = count
    flow._validation_sessions[key] = session
    flow._historical_pools[key] = flow._pool_from_candles(
        session,
        rows,
        requested_count=count + warmup,
        request_id="EXECUTION-REFRESH",
        market_data_identity=case.stock.code,
        market_source="KRX",
    )
    failures = []
    flow.validation_failed.connect(failures.append)
    window.chart_input_invalidated.connect(
        lambda: flow._invalidate_window_input(window)
    )
    window.validation_run_requested.connect(
        lambda request: flow._run_validation(window, request)
    )
    window.validation_range_evaluation_requested.connect(
        lambda start, end: flow._run_cached_range_replay(window, start, end)
    )
    window.validation_range_changed.connect(
        lambda value: flow._invalidate_window_range(window, value)
    )
    return window, flow, failures


def set_execution_checkbox(window, name, checked):
    checkbox = getattr(window, name)
    checkbox.setChecked(checked)
    return checkbox


def wait_for_idle_policy_refresh(case, window, flow, failures, expected):
    def ready():
        settings = window._result_settings_snapshot
        if settings is None:
            return False
        rules = settings.to_dict()
        execution = rules["validation_execution"]
        return (
            execution[expected[0]] is expected[1]
            and window.replay_snapshot is None
            and window._normal_base_ready
            and id(window) not in flow._prepare_active
        )

    wait_for(case, lambda: ready() or failures)
    assert not failures
    assert ready()


def wait_for_full_validation(case, window, flow, failures, expected):
    def ready():
        snapshot = window.replay_snapshot
        settings = window._result_settings_snapshot
        if snapshot is None or settings is None:
            return False
        execution = settings.to_dict()["validation_execution"]
        return (
            execution[expected[0]] is expected[1]
            and snapshot.settings_hash == settings.rules_hash
            and id(window) not in flow._prepare_active
        )

    wait_for(case, lambda: ready() or failures)
    assert not failures
    assert ready()


def test_initial_pool_never_constructs_replay_and_manual_range_can_replay(case):
    window = window_for(case)
    replay = Mock(side_effect=AssertionError("initial replay is forbidden"))
    flow = fm.IndicatorFollowSignalValidationV4Flow(
        object(), host=legacy._FakeHost(case.stock), replay_factory=replay,
        historical_cache=case.default_history_cache,
        historical_count=600,
    )
    key = id(window)
    flow._open_windows[key] = window
    flow._request_generation[key] = 0
    flow._history_targets[key] = 600
    requests = []
    window.validation_run_requested.connect(requests.append)
    window.request_initial_validation()
    assert len(requests) == 1
    session = legacy.ValidationSession(legacy.ValidationRequest(
        case.stock, requests[0].settings_snapshot, requests[0].settings_snapshot.to_dict()["bar"]["bar_minutes"],
    ), operation_active_reader=lambda: False)
    pool = flow._pool_from_candles(session, candles(), requested_count=600,
                                   request_id="PHASE1", market_data_identity="005930", market_source="KRX")
    flow._last_run_requests[key] = requests[0]
    flow._use_pool_for_window(window, session, pool, evaluation_count=100)
    wait_for(case, lambda: getattr(window, "canvas", None) is not None or replay.called)
    replay.assert_not_called()
    assert window.replay_snapshot is None
    assert window.canvas.isEnabled()
    assert window.visualization_cache.series
    assert not window._entries and not window._calculation_signal_marker_entries
    assert not window.completed_cycles
    assert window._validated_ui_fingerprint is None
    assert "미계산" in window.validation_status_label.text()
    flow._replay_factory = legacy.ValidationHistoricalReplay
    window.validation_range_evaluation_requested.connect(
        lambda start, end: flow._run_cached_range_replay(window, start, end))
    window._complete_validation_range_drag(450, 480)
    wait_for(case, lambda: window._range_replay_entries_available)
    assert window.replay_snapshot is not None
    assert window.validation_range == (450, 480)


def test_confirmed_filter_line_edit_invalidates_once_without_replay_or_canvas_rebuild(case):
    window = window_for(case)
    install(window)
    wait_for(case, lambda: window._visualization_projection_active is None)
    canvas = window.canvas
    view = window._current_chart_view_state()
    before = tuple(window.visualization_descriptors)
    invalidations = []
    window.chart_input_invalidated.connect(lambda: invalidations.append(None))
    line = window.buy_rsi_value_line
    with patch.object(
        window,
        "_install_normal_chart_canvas",
        side_effect=AssertionError("draft display must reuse the current canvas"),
    ), patch.object(
        window,
        "_refresh_filter_display_projection",
        wraps=window._refresh_filter_display_projection,
    ) as refresh:
        line.setText("39")
        assert invalidations == []
        assert window.canvas is canvas
        assert window.replay_snapshot is None
        QApplication.sendEvent(
            line, QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier)
        )
        wait_for(
            case,
            lambda: (
                window._visualization_projection_active is None
                and tuple(window.visualization_descriptors) != before
            ),
        )
        assert len(invalidations) == 1
        refresh.assert_called_once()
        QApplication.sendEvent(
            line, QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier)
        )
        case.app.processEvents()
        assert len(invalidations) == 1
    assert window.canvas is canvas
    assert window._current_chart_view_state() == view
    assert window.replay_snapshot is None
    assert window.visualization_descriptors
    assert window.visualization_descriptors != before


def test_filter_operator_confirms_once_and_mark_uses_focused_line_value(case):
    window = window_for(case)
    install(window)
    invalidations = []
    marking_requests = []
    window.chart_input_invalidated.connect(lambda: invalidations.append(None))
    window.marking_evaluation_requested.connect(marking_requests.append)
    line = window.buy_rsi_value_line
    combo = window.buy_rsi_compare_combo
    line.setText("39")
    QApplication.sendEvent(
        line, QFocusEvent(QEvent.FocusOut)
    )
    window.marking_display_check.setChecked(True)
    case.app.processEvents()
    assert len(invalidations) == 1
    assert len(marking_requests) == 1
    assert marking_requests[0]["settings"].rules_hash == window._marking_current_settings().rules_hash
    assert window.replay_snapshot is None
    assert window.canvas is not None

    window._disable_marking(clear_cache=True)
    invalidations.clear()
    combo.setCurrentIndex((combo.currentIndex() + 1) % combo.count())
    assert invalidations == []
    QApplication.sendEvent(
        combo, QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier)
    )
    case.app.processEvents()
    assert len(invalidations) == 1
    QApplication.sendEvent(combo, QFocusEvent(QEvent.FocusOut))
    case.app.processEvents()
    assert len(invalidations) == 1


def test_invalid_filter_draft_keeps_confirmed_marking_and_cannot_request_replay(case):
    window = window_for(case)
    install(window)
    marking_requests = []
    validation_requests = []
    window.marking_evaluation_requested.connect(marking_requests.append)
    window.validation_run_requested.connect(validation_requests.append)
    window.marking_display_check.setChecked(True)
    case.app.processEvents()
    assert len(marking_requests) == 1
    prior_times = window._marking_times
    line = window.buy_rsi_value_line
    line.setText("invalid")
    QApplication.sendEvent(
        line, QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier)
    )
    case.app.processEvents()
    assert window._marking_times == prior_times
    assert window.request_validation() is None
    assert validation_requests == []


def test_period_selection_flushes_focused_filter_draft_without_auto_validation(case):
    window, _flow = range_signal_flow(case)
    validation_requests = []
    window.validation_run_requested.connect(validation_requests.append)
    line = window.buy_rsi_value_line
    line.setText("39")
    assert validation_requests == []
    QApplication.sendEvent(
        line, QFocusEvent(QEvent.FocusOut)
    )
    expected = window._marking_current_settings()
    window._complete_validation_range_drag(40, 60)
    wait_for(case, lambda: window._range_replay_entries_available)
    assert validation_requests == []
    assert (
        window._range_replay_settings_snapshot.to_dict()["buy"]["filters"]["rsi"]
        == expected.to_dict()["buy"]["filters"]["rsi"]
    )


@pytest.mark.parametrize("confirmation", ["enter", "focus_out"])
def test_confirmed_filter_edit_clears_marking_and_period_without_auto_replay(
    case,
    confirmation,
):
    window, flow = range_signal_flow(case)
    window.marking_display_check.setChecked(True)
    assert window._marking_times is not None
    window._complete_validation_range_drag(40, 60)
    wait_for(case, lambda: window._range_replay_entries_available)
    assert window.marking_display_check.isChecked()
    assert marker_keys(window) == {(42, "BUY"), (55, "SELL")}
    assert window.completed_cycles
    canvas = window.canvas
    view = window._current_chart_view_state()
    candles_before = deepcopy(window._candles)
    previous_settings = window._range_replay_settings_snapshot
    assert previous_settings is not None

    payloads = []
    with patch.object(flow, "_emit_range_replay_completed", side_effect=payloads.append):
        flow._run_cached_range_replay(window, *window.validation_range)
        wait_for(case, lambda: bool(payloads))
        line = window.buy_rsi_value_line
        line.setText("39")
        if confirmation == "enter":
            QApplication.sendEvent(
                line, QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier),
            )
        else:
            QApplication.sendEvent(line, QFocusEvent(QEvent.FocusOut))
        wait_for(case, lambda: window.validation_range is None)

    assert not window.marking_display_check.isChecked()
    assert window._marking_times is None
    assert window.replay_snapshot is None
    assert not window._range_replay_entries_available
    assert not window._range_replay_entries
    assert window._range_replay_settings_snapshot is None
    assert marker_keys(window) == set()
    assert not window.completed_cycles
    assert window.completed_cycle_table.rowCount() == 0
    assert window.canvas is canvas
    assert window._current_chart_view_state() == replace(
        view,
        selected_evaluation_index=None,
    )
    assert window._candles == candles_before

    flow._on_range_replay_completed(payloads[0])
    case.app.processEvents()

    assert not flow._range_replay_active and not flow._range_replay_pending
    assert window.validation_range is None
    assert window.replay_snapshot is None

    window._complete_validation_range_drag(40, 60)
    wait_for(case, lambda: window._range_replay_entries_available)
    current_settings = window._range_replay_settings_snapshot
    assert current_settings is not None
    assert current_settings.rules_hash != previous_settings.rules_hash
    assert (
        current_settings.to_dict()["buy"]["filters"]["rsi"]
        != previous_settings.to_dict()["buy"]["filters"]["rsi"]
    )

    selected_range = window.validation_range
    QApplication.sendEvent(
        line, QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier),
    )
    line.setText("invalid")
    QApplication.sendEvent(
        line, QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier),
    )
    for control in (
        window.filter_display_check,
        window.filter_display_valid_check,
    ):
        control.setChecked(not control.isChecked())
    case.app.processEvents()
    assert window.validation_range == selected_range
    assert window._range_replay_entries_available


@pytest.mark.parametrize("side", ["buy", "sell"])
def test_expression_operator_click_confirms_and_retires_completed_evidence(case, side):
    window, _flow = range_signal_flow(case)
    window.marking_display_check.setChecked(True)
    window._complete_validation_range_drag(40, 60)
    wait_for(case, lambda: window._range_replay_entries_available)
    line = getattr(window, f"{side}_signal_expr_line")
    line.setCursorPosition(line.text().lower().index("and") + 1)
    QTest.mouseClick(getattr(window, f"{side}_expr_operator_button"), Qt.LeftButton)
    wait_for(case, lambda: window.validation_range is None)
    assert not window.marking_display_check.isChecked()
    assert marker_keys(window) == set()
    assert not window.completed_cycles


def test_expression_outside_nofocus_button_confirms_but_display_only_checkbox_does_not(case):
    window, _flow = range_signal_flow(case)
    window.marking_display_check.setChecked(True)
    window._complete_validation_range_drag(40, 60)
    wait_for(case, lambda: window._range_replay_entries_available)
    line = window.buy_signal_expr_line
    line.setText("A or B and C and D")
    line.setFocus()
    window.filter_display_check.setChecked(not window.filter_display_check.isChecked())
    case.app.processEvents()
    assert window.validation_range == (40, 60)
    QTest.mouseClick(window.buy_expr_operator_button, Qt.LeftButton)
    wait_for(case, lambda: window.validation_range is None)
    assert not window.marking_display_check.isChecked()


@pytest.mark.parametrize("target_name", [
    "buy_header_widget",
    "buy_overview_filter",
    "sell_header_widget",
    "sell_signal_condition_1",
])
def test_expression_control_background_click_confirms_and_retires_completed_evidence(
    case,
    target_name,
):
    window, _flow = range_signal_flow(case)
    window.marking_display_check.setChecked(True)
    window._complete_validation_range_drag(40, 60)
    wait_for(case, lambda: window._range_replay_entries_available)
    canvas = window.canvas
    view = window._current_chart_view_state()
    line = window.buy_signal_expr_line
    line.setText("A or B and C and D")
    line.setFocus()

    QTest.mouseClick(getattr(window, target_name), Qt.LeftButton)
    case.app.processEvents()

    assert window.validation_range is None
    assert marker_keys(window) == set()
    assert not window.completed_cycles
    assert window.canvas is canvas
    assert window._current_chart_view_state() == replace(
        view,
        selected_evaluation_index=None,
    )


def test_invalid_expression_blocks_mark_and_period_with_visible_feedback(case):
    window, _flow = range_signal_flow(case)
    window.buy_signal_expr_line.setText("A and")
    window.buy_signal_expr_line.setFocus()
    QApplication.sendEvent(
        window.buy_signal_expr_line,
        QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier),
    )
    case.app.processEvents()
    window.marking_display_check.setChecked(True)
    window._complete_validation_range_drag(40, 60)
    assert not window.marking_display_check.isChecked()
    assert window.validation_range is None
    assert "신호 조합식" in window.validation_status_label.text()
    assert window.buy_signal_expr_line.toolTip() == window.validation_status_label.text()


@pytest.mark.parametrize("side", ["buy", "sell"])
def test_expression_repair_clears_owned_error_and_confirms_changed_setting(case, side):
    window, _flow = range_signal_flow(case)
    line = getattr(window, f"{side}_signal_expr_line")
    line.setText("A and")
    line.setFocus()
    QApplication.sendEvent(
        line, QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier),
    )
    case.app.processEvents()
    warning = window.validation_status_label.text()
    assert "신호 조합식" in warning
    assert "CONDITION_EXPRESSION" not in warning
    assert line.toolTip() == warning

    line.setText("A")
    QApplication.sendEvent(
        line, QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier),
    )
    case.app.processEvents()
    assert window._current_signal_ui_fingerprint() == window._confirmed_signal_ui_fingerprint
    assert "설정이 적용되었습니다" in window.validation_status_label.text()
    assert line.toolTip() == ""

    status = window.validation_status_label.text()
    QApplication.sendEvent(
        line, QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier),
    )
    case.app.processEvents()
    assert window.validation_status_label.text() == status


def test_mark_after_expression_edit_stays_on_after_later_enter(case):
    window, _flow = range_signal_flow(case)
    window.buy_signal_expr_line.setText("A or B and C and D")
    window.marking_display_check.setChecked(True)
    assert window.marking_display_check.isChecked()
    assert window._marking_times is not None
    QApplication.sendEvent(
        window.buy_signal_expr_line,
        QKeyEvent(QEvent.KeyPress, Qt.Key_Return, Qt.NoModifier),
    )
    case.app.processEvents()
    assert window.marking_display_check.isChecked()
    assert window._marking_times is not None


def range_signal_flow(case):
    window = window_for(case)
    rows = candles(100)
    install(window, rows)
    settings = window._signal_validation_seed.settings_snapshot
    session = legacy.ValidationSession(legacy.ValidationRequest(
        case.stock, settings, settings.to_dict()["bar"]["bar_minutes"],
    ), operation_active_reader=lambda: False)

    def evaluator(prefix, rules, context):
        index = len(prefix) - 1
        side = context["_indicator_follow_evaluate_side"]
        signal = (side if (side == "BUY" and index in (5, 42, 72))
                  or (side == "SELL" and index in (15, 55, 85)
                      and context.get("average_price") is not None) else None)
        return legacy.RoutineSignal(signal, "range fixture", [], [], index if signal else -1, 0)

    flow = fm.IndicatorFollowSignalValidationV4Flow(
        object(), host=legacy._FakeHost(case.stock), historical_count=100,
        historical_cache=case.default_history_cache,
        replay_factory=lambda s: legacy.ValidationHistoricalReplay(s, evaluator=evaluator),
    )
    key = id(window)
    flow._open_windows[key] = window
    flow._request_generation[key] = 0
    flow._history_targets[key] = 100
    flow._validation_sessions[key] = session
    flow._historical_pools[key] = flow._pool_from_candles(
        session, rows, requested_count=100, request_id="RANGE-ISOLATION",
        market_data_identity=case.stock.code, market_source="KRX",
    )
    window.validation_range_evaluation_requested.connect(
        lambda a, b: flow._run_cached_range_replay(window, a, b))
    window.validation_range_changed.connect(
        lambda value: flow._invalidate_window_range(window, value))
    window.chart_input_invalidated.connect(lambda: flow._invalidate_window_input(window))
    return window, flow


def marker_keys(window):
    return {(record["evaluation_index"], record["side"])
            for record in window.canvas.marker_records()}


@pytest.mark.parametrize("control, field", [
    ("validation_averaging_enabled_check", "enabled"),
    ("validation_trading_cost_enabled_check", "trading_cost_enabled"),
])
def test_execution_checkbox_keeps_ready_chart_visible_while_refresh_starts(
    case,
    control,
    field,
):
    window, flow, failures = execution_refresh_flow(case)
    window.resize(1400, 800)
    window.show()  # Offscreen fixture window, never the production GUI.
    canvas = window.canvas
    case.app.processEvents()
    QTest.qWait(10)
    window._set_time_view(30.25, 35.5, manually_adjusted=True)
    lower, upper = window.current_price_bounds
    window._apply_pan_chart_target(("price", lower + 100.0, upper + 100.0))
    descriptor = next(
        item
        for item in window.visualization_descriptors
        if item.axis == wm.PRICE_AXIS and item.sides
    )
    legend_key = (descriptor.sides[0], descriptor.identity)
    canvas.set_highlighted_price_filter_identities({legend_key}, emit=True)
    expected_view = window._current_chart_view_state()
    expected_legend = canvas.highlighted_price_filter_identities
    expected_candles = deepcopy(window._candles)
    expected_descriptors = window.visualization_descriptors
    expected_series = window.visualization_cache.series
    scan = Mock(side_effect=AssertionError("idle policy refresh scanned signals"))
    replay = Mock(side_effect=AssertionError("idle policy refresh ran detailed replay"))

    with patch.object(
        fm.ValidationHistoricalReplay,
        "scan_signal_entries",
        scan,
    ), patch.object(
        fm.ValidationHistoricalReplay,
        "evaluate_with_context",
        replay,
    ):
        set_execution_checkbox(window, control, True)

        assert not failures
        assert window.chart_stack.currentWidget() is window.chart_view
        assert window.canvas is canvas
        assert window._pending_result_settings_snapshot.to_dict()[
            "validation_execution"
        ][field] is True
        wait_for_idle_policy_refresh(case, window, flow, failures, (field, True))
    scan.assert_not_called()
    replay.assert_not_called()
    assert window.canvas is canvas
    assert window._current_chart_view_state() == expected_view
    assert canvas.highlighted_price_filter_identities == expected_legend
    assert window._candles == expected_candles
    assert window.visualization_descriptors == expected_descriptors
    assert window.visualization_cache.series == expected_series


@pytest.mark.parametrize("control", [
    "validation_averaging_enabled_check",
    "validation_trading_cost_enabled_check",
])
def test_execution_checkbox_failure_keeps_existing_source_chart(case, control):
    window, _flow, _failures = execution_refresh_flow(case)
    canvas = window.canvas
    jobs = []

    class HeldThread:
        def __init__(self, *, target, **_kwargs):
            jobs.append(target)

        def start(self):
            pass

    with patch.object(fm, "Thread", HeldThread):
        set_execution_checkbox(window, control, True)
    assert jobs

    window.show_validation_error("EXECUTION_REFRESH_FAILED")

    assert window.chart_stack.currentWidget() is window.chart_view
    assert window.canvas is canvas


@pytest.mark.parametrize("control, field", [
    ("validation_averaging_enabled_check", "enabled"),
    ("validation_trading_cost_enabled_check", "trading_cost_enabled"),
])
def test_execution_checkbox_clears_stale_range_evidence_without_losing_selection(
    case,
    control,
    field,
):
    window, flow, failures = execution_refresh_flow(case)
    set_execution_checkbox(window, control, True)
    wait_for_idle_policy_refresh(case, window, flow, failures, (field, True))
    window._complete_validation_range_drag(0, 20)
    wait_for(case, lambda: window._range_replay_entries_available or failures)
    assert not failures
    assert window.completed_cycles
    assert window.canvas.marker_records()
    assert window.estimated_return_label.text()
    canvas = window.canvas
    selected_range = window.validation_range

    set_execution_checkbox(window, control, False)

    assert window.chart_stack.currentWidget() is window.chart_view
    assert window.canvas is canvas
    assert window.validation_range == selected_range
    assert not window.canvas.marker_records()
    assert not window.completed_cycles
    assert window.estimated_return_label.text() == ""
    wait_for_idle_policy_refresh(case, window, flow, failures, (field, False))
    wait_for(case, lambda: window._range_replay_entries_available or failures)
    assert not failures


@pytest.mark.parametrize("control, field", [
    ("validation_averaging_enabled_check", "enabled"),
    ("validation_trading_cost_enabled_check", "trading_cost_enabled"),
])
def test_execution_checkbox_rebinds_success_to_same_canvas_and_new_accounting(
    case,
    control,
    field,
):
    window, flow, failures = execution_refresh_flow(case)
    base_canvas = window.canvas
    set_execution_checkbox(window, control, True)
    wait_for_idle_policy_refresh(case, window, flow, failures, (field, True))
    canvas_after_true = window.canvas
    window._complete_validation_range_drag(0, 20)
    wait_for(case, lambda: window._range_replay_entries_available or failures)
    assert not failures
    true_cycle, = window.completed_cycles
    true_entries = [
        entry.to_dict() for entry in window.replay_snapshot.to_entries()
    ]
    true_tooltips = dict(window._signal_tooltips)

    window._set_time_view(30.25, 35.5, manually_adjusted=True)
    lower, upper = window.current_price_bounds
    window._apply_pan_chart_target(("price", lower + 100.0, upper + 100.0))
    price_descriptor = next(
        descriptor
        for descriptor in window.visualization_descriptors
        if descriptor.axis == wm.PRICE_AXIS and descriptor.sides
    )
    legend_key = (price_descriptor.sides[0], price_descriptor.identity)
    window.canvas.set_highlighted_price_filter_identities(
        {legend_key},
        emit=True,
    )
    expected_view = window._current_chart_view_state()
    expected_scroll = window.time_navigation_scrollbar.value()
    expected_range = window.validation_range
    expected_legend = window.canvas.highlighted_price_filter_identities

    set_execution_checkbox(window, control, False)
    wait_for_idle_policy_refresh(case, window, flow, failures, (field, False))
    wait_for(case, lambda: window._range_replay_entries_available or failures)
    assert not failures
    false_cycle, = window.completed_cycles
    false_entries = [
        entry.to_dict() for entry in window.replay_snapshot.to_entries()
    ]
    false_tooltips = dict(window._signal_tooltips)

    assert canvas_after_true is base_canvas
    assert window.canvas is base_canvas
    assert window.chart_stack.currentWidget() is window.chart_view
    assert window._current_chart_view_state() == expected_view
    assert window.time_navigation_scrollbar.value() == expected_scroll
    assert window.validation_range == expected_range
    assert window.canvas.validation_range == expected_range
    assert window.canvas.highlighted_price_filter_identities == expected_legend
    assert window.time_scale_manually_adjusted
    assert window.price_scale_manually_adjusted
    assert window.replay_snapshot.settings_hash == (
        window._result_settings_snapshot.rules_hash
    )

    buy_prices = [float(window._candles[index]["close"]) for index in (5, 10)]
    sell_price = float(window._candles[15]["close"])
    if field == "enabled":
        assert true_cycle.buy_quantity == 6
        assert true_cycle.buy_cost == pytest.approx(
            buy_prices[0] * 2 + buy_prices[1] * 4
        )
        assert true_cycle.average_buy_price == pytest.approx(
            (buy_prices[0] * 2 + buy_prices[1] * 4) / 6
        )
        assert false_cycle.buy_quantity == 2
        assert false_cycle.buy_cost == pytest.approx(sum(buy_prices))
        assert false_cycle.average_buy_price == pytest.approx(sum(buy_prices) / 2)
    else:
        assert true_entries == false_entries
        assert true_tooltips.keys() == false_tooltips.keys()
        assert true_tooltips[(15, "SELL")] != false_tooltips[(15, "SELL")]
        assert true_cycle.trading_cost_amount == pytest.approx(
            true_cycle.buy_cost * 0.01
        )
        assert true_cycle.estimated_return_percent == pytest.approx(
            (sell_price - true_cycle.average_buy_price)
            / true_cycle.average_buy_price
            * 100.0
            - 1.0
        )
        assert false_cycle.trading_cost_amount == 0.0
        assert false_cycle.estimated_return_percent == pytest.approx(
            (sell_price - false_cycle.average_buy_price)
            / false_cycle.average_buy_price
            * 100.0
        )


def test_apply_uses_current_working_ui_without_replay_and_explicit_validate_still_runs(case):
    window, flow, failures = execution_refresh_flow(case)
    flow._replay_factory = fm.ValidationHistoricalReplay
    calls = {"scan": 0, "replay": 0}
    applied = []
    window.settings_apply_requested.connect(applied.append)
    original_scan = fm.ValidationHistoricalReplay.scan_signal_entries
    original_replay = fm.ValidationHistoricalReplay.evaluate_with_context

    def counted_scan(replay, *args, **kwargs):
        calls["scan"] += 1
        return original_scan(replay, *args, **kwargs)

    def counted_replay(replay, *args, **kwargs):
        calls["replay"] += 1
        return original_replay(replay, *args, **kwargs)

    with patch.object(
        fm.ValidationHistoricalReplay,
        "scan_signal_entries",
        counted_scan,
    ), patch.object(
        fm.ValidationHistoricalReplay,
        "evaluate_with_context",
        counted_replay,
    ):
        set_execution_checkbox(
            window,
            "validation_trading_cost_enabled_check",
            True,
        )
        wait_for_idle_policy_refresh(
            case,
            window,
            flow,
            failures,
            ("trading_cost_enabled", True),
        )
        assert not failures
        assert calls == {"scan": 0, "replay": 0}
        assert window.replay_snapshot is None

        canvas = window.canvas
        view = window._current_chart_view_state()
        assert window._handle_primary_validation_action() is not None
        assert not failures
        assert len(applied) == 1
        assert calls == {"scan": 0, "replay": 0}
        assert window.replay_snapshot is None
        assert window.canvas is canvas
        assert window._current_chart_view_state() == view
        cold_calls = dict(calls)

        set_execution_checkbox(
            window,
            "validation_trading_cost_enabled_check",
            False,
        )
        wait_for_idle_policy_refresh(
            case,
            window,
            flow,
            failures,
            ("trading_cost_enabled", False),
        )
        assert not failures
        assert calls == cold_calls
        assert window._request_validation() is not None
        wait_for_full_validation(
            case,
            window,
            flow,
            failures,
            ("trading_cost_enabled", False),
        )
        assert not failures
        assert calls["scan"] > cold_calls["scan"]
        assert calls["replay"] > cold_calls["replay"]
        cost_cached_calls = dict(calls)

        set_execution_checkbox(
            window,
            "validation_averaging_enabled_check",
            True,
        )
        wait_for_idle_policy_refresh(
            case,
            window,
            flow,
            failures,
            ("enabled", True),
        )
        assert not failures
        assert calls == cost_cached_calls
        assert window._request_validation() is not None
        wait_for_full_validation(
            case,
            window,
            flow,
            failures,
            ("enabled", True),
        )
        assert calls["scan"] > cost_cached_calls["scan"]
        assert calls["replay"] > cost_cached_calls["replay"]


def test_idle_cost_refresh_skips_custom_evaluator_until_manual_range(case):
    evaluator_calls = []
    window, flow, failures = execution_refresh_flow(
        case,
        evaluator_calls=evaluator_calls,
    )

    set_execution_checkbox(
        window,
        "validation_trading_cost_enabled_check",
        True,
    )
    wait_for_idle_policy_refresh(
        case,
        window,
        flow,
        failures,
        ("trading_cost_enabled", True),
    )
    assert evaluator_calls == []

    window._complete_validation_range_drag(0, 20)
    wait_for(case, lambda: window._range_replay_entries_available or failures)
    assert not failures
    range_count = len(evaluator_calls)
    assert range_count > 0

    set_execution_checkbox(
        window,
        "validation_trading_cost_enabled_check",
        False,
    )
    wait_for_idle_policy_refresh(
        case,
        window,
        flow,
        failures,
        ("trading_cost_enabled", False),
    )
    wait_for(case, lambda: window._range_replay_entries_available or failures)
    assert not failures
    assert len(evaluator_calls) > range_count


def test_trading_cost_reuse_gate_rejects_mixed_or_incomplete_source(case):
    window, flow, _failures = execution_refresh_flow(case)
    session = flow._validation_sessions[id(window)]
    pool = flow._historical_pools[id(window)]
    assert flow._trading_cost_reuse_prefix(session, pool) is None

    flow._replay_factory = fm.ValidationHistoricalReplay
    assert flow._trading_cost_reuse_prefix(session, pool) is not None
    assert flow._trading_cost_reuse_prefix(
        session,
        dict(pool, display_only_integrated=True),
    ) is None
    assert flow._trading_cost_reuse_prefix(
        session,
        dict(pool, source_coverage_sufficient=False),
    ) is None
    assert flow._trading_cost_reuse_prefix(
        session,
        dict(pool, market_source="VALIDATION_COMPOSITE"),
    ) is None


@pytest.mark.parametrize("averaging_enabled", [False, True])
def test_trading_cost_is_signal_neutral_for_position_profit_sell(
    case,
    averaging_enabled,
):
    from tests import test_indicator_follow_validation_batch as batch

    rules = batch._rules()
    rules["buy"]["groups"][0]["conditions"] = [
        {"target": "CLOSE", "operator": ">", "value": 0.0}
    ]
    rules["sell"]["signals"]["macd_sell"]["enabled"] = False
    rules["sell"]["signals"]["profit_rate_sell"] = {
        "enabled": True,
        "profit_rate_percent": 0.5,
    }
    source_candles = batch._candles(180)
    historical = fm.ValidationHistoricalSnapshot(
        stock=case.stock,
        timeframe_minutes=3,
        timeframe_key="M3",
        requested_count=len(source_candles),
        request_id="TRADING-COST-PROFIT-PARITY",
        rows=fm.IndicatorFollowSignalValidationV4Flow._historical_rows_from_candles(
            source_candles
        ),
        market_data_identity=case.stock.code,
        market_source="KRX",
    )
    runs = []
    for cost_enabled, cost_percent in (
        (False, 0.2),
        (True, 0.2),
        (True, 2.5),
    ):
        current_rules = deepcopy(rules)
        policy = {
            "enabled": averaging_enabled,
            "first_buy_quantity": 2,
            "repeat_mode": "ROUND",
            "round_operator": "ADD",
            "round_budget_value": 1.0,
            "budget_ratio": 2.0,
            "active_direction": "UP",
            "active_ratio": 0.45,
            "active_compare": ">=",
            "trading_cost_enabled": cost_enabled,
            "trading_cost_percent": cost_percent,
        }
        current_rules["validation_execution"] = policy
        settings = fm.ValidationSettingsSnapshot(current_rules)
        session = fm.ValidationSession(
            fm.ValidationRequest(case.stock, settings, 3),
            operation_active_reader=lambda: False,
        )
        result = fm.ValidationHistoricalReplay(session).evaluate_with_context(
            historical,
            context_provider=fm.ValidationVirtualPositionTracker(policy),
        )
        assert result.ok, result
        entries = tuple(fm.emitted_signal_entries(result.snapshot.to_entries()))
        simulation = wm.simulate_validation_execution(
            result.snapshot.to_candles(),
            entries,
            policy,
        )
        runs.append((cost_enabled, cost_percent, entries, simulation))

    baseline_entries = [entry.to_dict() for entry in runs[0][2]]
    baseline_cycles = runs[0][3].cycles
    assert any(entry.signal == "BUY" for entry in runs[0][2])
    assert any(entry.signal == "SELL" for entry in runs[0][2])
    assert len(baseline_cycles) >= 2

    def cycle_identity(cycle):
        return (
            cycle.buy_indexes,
            cycle.buy_start_index,
            cycle.buy_end_index,
            cycle.buy_count,
            cycle.buy_quantity,
            cycle.buy_cost,
            cycle.average_buy_price,
            cycle.sell_index,
            cycle.sell_price,
            cycle.sell_quantity,
        )

    baseline_identity = [cycle_identity(cycle) for cycle in baseline_cycles]
    for cost_enabled, cost_percent, entries, simulation in runs[1:]:
        assert [entry.to_dict() for entry in entries] == baseline_entries
        assert [cycle_identity(cycle) for cycle in simulation.cycles] == (
            baseline_identity
        )
        for baseline_cycle, cycle in zip(baseline_cycles, simulation.cycles):
            expected_cost = baseline_cycle.buy_cost * cost_percent / 100.0
            baseline_net = (
                baseline_cycle.sell_price * baseline_cycle.sell_quantity
                - baseline_cycle.buy_cost
            )
            actual_net = (
                cycle.sell_price * cycle.sell_quantity
                - cycle.buy_cost
                - cycle.trading_cost_amount
            )
            assert cost_enabled is True
            assert cycle.trading_cost_amount == pytest.approx(expected_cost)
            assert actual_net == pytest.approx(baseline_net - expected_cost)
            assert cycle.estimated_return_percent == pytest.approx(
                baseline_cycle.estimated_return_percent - cost_percent
            )


@pytest.mark.parametrize("with_baseline", [False, True])
def test_period_signals_are_local_and_clearing_keeps_baseline_unshown(case, with_baseline):
    window, flow = range_signal_flow(case)
    assert not window._entries and not window._calculation_entries
    assert marker_keys(window) == set()
    baseline_markers = set()
    if with_baseline:
        result = flow._prepare_replay_result_from_pool(
            flow._validation_sessions[id(window)], flow._historical_pools[id(window)],
            history_target=100, chart_range=(0, 20),
        )
        assert result.ok, result
        window.set_replay_snapshot(result.snapshot)
        baseline_markers = {(5, "BUY"), (15, "SELL")}
        assert {
            (entry.evaluation_index, entry.signal)
            for entry in window._marker_entries_for_calculation()
            if entry.signal in {"BUY", "SELL"}
        } == baseline_markers
        assert marker_keys(window) == set()
    baseline = deepcopy((window._calculation_entries, window._entries))
    failures = []
    flow.validation_failed.connect(failures.append)

    def select(bounds, expected):
        window._complete_validation_range_drag(*bounds)
        wait_for(case, lambda: window._range_replay_entries_available or failures)
        assert not failures
        assert marker_keys(window) == expected
        assert (window._calculation_entries, window._entries) == baseline
        assert len(window.completed_cycles) == window.completed_cycle_table.rowCount() == 1
        assert all(record["tooltip"] for record in window.canvas.marker_records())

    def assert_cleared():
        assert window.validation_range is None
        assert not window._range_replay_entries_available
        assert not window._range_replay_entries and not window._range_replay_calculation_entries
        assert marker_keys(window) == set()
        assert (window._calculation_entries, window._entries) == baseline
        assert not window.completed_cycles
        assert window.completed_cycle_table.rowCount() == 0

    select((40, 60), {(42, "BUY"), (55, "SELL")})
    select((70, 90), {(72, "BUY"), (85, "SELL")})
    window._clear_validation_range_interaction()
    assert_cleared()
    assert window.reset_chart_view()
    assert_cleared()
    select((40, 60), {(42, "BUY"), (55, "SELL")})
    assert window.reset_chart_view()
    assert_cleared()


@pytest.mark.parametrize("clear_action", ["_clear_validation_range_interaction", "reset_chart_view"])
def test_period_clear_rejects_late_completion_and_pending_range(case, clear_action):
    window, flow = range_signal_flow(case)
    payloads = []
    failures = []
    flow.validation_failed.connect(failures.append)
    with patch.object(flow, "_emit_range_replay_completed", side_effect=payloads.append):
        window._complete_validation_range_drag(40, 60)
        wait_for(case, lambda: bool(payloads))
    assert payloads[0]["snapshot"] is not None and not payloads[0]["error"]
    window._complete_validation_range_drag(70, 90)
    assert id(window) in flow._range_replay_pending
    getattr(window, clear_action)()
    flow._on_range_replay_completed(payloads[0])
    case.app.processEvents()
    assert not failures
    assert not flow._range_replay_active and not flow._range_replay_pending
    assert window.validation_range is None and window.replay_snapshot is None
    assert not window._range_replay_entries_available
    assert not window._entries and not window._calculation_entries
    assert marker_keys(window) == set()


def test_selected_period_uses_current_ui_rules_and_rejects_stale_base_result(case):
    window, flow = range_signal_flow(case)
    base_settings = flow._validation_sessions[id(window)].request.settings_snapshot
    canvas = window.canvas
    initial_candles = deepcopy(window._candles)

    def evaluator(prefix, rules, context):
        index = len(prefix) - 1
        side = context["_indicator_follow_evaluate_side"]
        current = rules["validation_execution"]["trading_cost_enabled"]
        signal = (
            side
            if (
                (current and side == "BUY" and index == 42)
                or (not current and side == "BUY" and index == 45)
                or (
                    side == "SELL"
                    and index == 55
                    and context.get("average_price") is not None
                )
            )
            else None
        )
        return legacy.RoutineSignal(
            signal, "current range fixture", [], [], index if signal else -1, 0,
        )

    flow._replay_factory = lambda session: legacy.ValidationHistoricalReplay(
        session, evaluator=evaluator,
    )
    payloads = []
    with patch.object(flow, "_emit_range_replay_completed", side_effect=payloads.append):
        window._complete_validation_range_drag(40, 60)
        wait_for(case, lambda: bool(payloads))

    stale_settings_hash = payloads[0]["snapshot"].settings_hash
    blocker = QSignalBlocker(window.validation_trading_cost_enabled_check)
    window.validation_trading_cost_enabled_check.setChecked(True)
    del blocker
    flow._on_range_replay_completed(payloads[0])
    assert not window._range_replay_entries_available

    flow._run_cached_range_replay(window, 40, 60)
    wait_for(case, lambda: window._range_replay_entries_available)
    range_settings = window._range_replay_settings_snapshot
    assert range_settings is not None
    assert range_settings.rules_hash != stale_settings_hash
    assert window.replay_snapshot.settings_hash == range_settings.rules_hash
    assert marker_keys(window) == {(42, "BUY"), (55, "SELL")}
    assert window.completed_cycles[0].trading_cost_amount > 0.0
    assert window._result_settings_snapshot.rules_hash == base_settings.rules_hash
    assert window.canvas is canvas
    assert window._candles == initial_candles

    window._clear_validation_range_interaction()
    assert window._range_replay_settings_snapshot is None
    assert window._result_settings_snapshot.rules_hash == base_settings.rules_hash


def test_normal_layers_restore_v2_all_all_universe_and_no_selection_modes(case):
    window = window_for(case)
    base = case._window()
    install(window)
    expected = base._all_filter_display_descriptors(case.rules)
    assert window.visualization_descriptors == expected
    assert window._all_filter_display_descriptors(case.rules) == expected
    comparison_ids = {d.identity for d in window.visualization_descriptors
                      if d.family == wm.FAMILY_PRICE_COMPARISON}
    assert not window._visualization_active_by_marker
    assert all(all(v is None for v in values) for identity, channel, values
               in window.visualization_cache.series if identity in comparison_ids or channel == "AVG_PRICE")
    assert window._filter_display_descriptors_for_selection(
        case.rules, True
    ) == expected
    assert window._filter_display_descriptors_for_selection(
        case.rules, False
    ) == ()
    from PyQt5.QtWidgets import QCheckBox
    actual = sorted(w.text() for w in window.findChildren(QCheckBox))
    expected = sorted(
        w.text() for w in base.findChildren(QCheckBox)
        if w.objectName() != "signalValidationFilterDisplayEnabled"
    )
    assert actual == expected
    assert not hasattr(window, "filter_display_side_combo")
    assert not hasattr(window, "filter_display_scope_combo")
    assert not hasattr(window, "_filter_display_side")
    assert not hasattr(window, "_on_price_legend_side_clicked")
    assert not hasattr(window.canvas, "price_legend_side_clicked")
    assert not hasattr(window.canvas, "set_price_legend_navigation_enabled")
    assert not hasattr(window.canvas, "_price_legend_navigation_enabled")


def test_ocr_numeric_criteria_draw_at_owned_y_without_turn_zero_labels(case):
    rows = candles(4)
    turn_buy = wm.ValidationFilterDescriptor(
        "ocr-turn-buy", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("BUY",), ("OSC",),
        '{"condition":{"operator":"TURN_UP","target":"OSC"}}', (),
    )
    turn_sell = wm.ValidationFilterDescriptor(
        "ocr-turn-sell", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("SELL",), ("OSC",),
        '{"condition":{"operator":"TURN_DOWN","target":"OSC"}}', (),
    )
    osc_values = (-2.0, -1.0, -2.0, -1.0)
    turn_only = wm.IndicatorFollowSignalValidationChartCanvas(
        rows, [], visualization_descriptors=(turn_buy, turn_sell),
        visualization_cache=wm.ValidationIndicatorSeriesCache(4, (
            (turn_buy.identity, "OSC", osc_values),
            (turn_sell.identity, "OSC", osc_values),
        )),
    )
    case.widgets.append(turn_only)
    turn_pane, = turn_only.lower_pane_records()
    turn_scale = turn_only._lower_scale(
        wm.FAMILY_OCR_OSC, int(turn_pane["top"]), int(turn_pane["bottom"]),
    )
    assert turn_scale is not None
    assert turn_only.lower_reference_line_records(
        wm.FAMILY_OCR_OSC, turn_scale,
    ) == []
    turn_painter = Mock()
    turn_only._draw_lower_panes(turn_painter)
    zero_y = int(turn_scale.y_for_price(0.0))
    assert any(
        len(call.args) == 4
        and call.args[1] == zero_y
        and call.args[3] == zero_y
        for call in turn_painter.drawLine.call_args_list
    )
    assert any(
        call.args[0].style() == Qt.DashLine
        for call in turn_painter.setPen.call_args_list
        if call.args and isinstance(call.args[0], QPen)
    )

    buy_criterion = wm.ValidationFilterDescriptor(
        "ocr-buy-minus-ten", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("BUY",), ("CRITERION_BUY",),
        '{"condition":{"operator":"LESS_THAN_OR_EQUAL","threshold":-10}}', (),
    )
    sell_criterion = wm.ValidationFilterDescriptor(
        "ocr-sell-zero", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("SELL",), ("CRITERION_SELL",),
        '{"condition":{"operator":"GREATER_THAN_OR_EQUAL","threshold":0}}', (),
    )
    canvas = wm.IndicatorFollowSignalValidationChartCanvas(
        rows, [], visualization_descriptors=(
            turn_buy, turn_sell, buy_criterion, sell_criterion,
        ), visualization_cache=wm.ValidationIndicatorSeriesCache(4, (
            (turn_buy.identity, "OSC", osc_values),
            (turn_sell.identity, "OSC", osc_values),
            (buy_criterion.identity, "CRITERION_BUY", (-10.0,) * 4),
            (sell_criterion.identity, "CRITERION_SELL", (0.0,) * 4),
        )),
    )
    case.widgets.append(canvas)
    pane, = canvas.lower_pane_records()
    scale = canvas._lower_scale(
        wm.FAMILY_OCR_OSC, int(pane["top"]), int(pane["bottom"]),
    )
    assert scale is not None
    records = canvas.lower_reference_line_records(wm.FAMILY_OCR_OSC, scale)
    assert [(record["value"], record["sides"], record["text"]) for record in records] == [
        (-10.0, ("BUY",), "\uB9E4\uC218 -10"),
        (0.0, ("SELL",), "\uB9E4\uB3C4 0"),
    ]
    assert records[0]["y"] == pytest.approx(scale.y_for_price(-10.0))
    assert records[1]["y"] == pytest.approx(scale.y_for_price(0.0))

    painter = Mock()
    canvas._draw_lower_panes(painter)
    paths = [call.args[0] for call in painter.drawPath.call_args_list]
    assert len(paths) == 2
    expected_path_y = sorted((
        scale.y_for_price(-10.0),
        scale.y_for_price(0.0),
    ))
    actual_path_y = sorted(path.boundingRect().center().y() for path in paths)
    assert actual_path_y == pytest.approx(expected_path_y)
    assert all(path.boundingRect().height() == pytest.approx(0.0) for path in paths)
    dotted_pens = [
        call.args[0]
        for call in painter.setPen.call_args_list
        if call.args
        and isinstance(call.args[0], QPen)
        and call.args[0].style() == Qt.DotLine
    ]
    assert len(dotted_pens) == 2
    assert all(pen.width() == 1 for pen in dotted_pens)


def _ocr_turn_descriptor(identity, side, operator):
    return wm.ValidationFilterDescriptor(
        identity, wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        (side,), ("OSC",),
        '{"condition":{"operator":"%s","target":"OSC"}}' % operator,
        (),
    )


def _ocr_threshold_descriptor(identity, side, operator, threshold, *, bar_offset=0):
    return wm.ValidationFilterDescriptor(
        identity, wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        (side,), ("OSC", "CRITERION"),
        json.dumps({"condition": {
            "operator": operator,
            "target": "OSC",
            "threshold": threshold,
            "bar_offset": bar_offset,
        }}),
        (),
    )


def _ocr_filter_presentation(side, criterion, turn):
    identities = (criterion.identity, turn.identity)
    return wm.ValidationLowerFilterPresentation(
        key=f"{side}:ocr",
        side=side,
        source_path=f"{side.lower()}.ocr",
        filter_token="OCR",
        pane_family=wm.FAMILY_OCR_OSC,
        display_order=(0,),
        descriptor_identities=identities,
        component_descriptor_identities=identities,
        component_labels=("OCR threshold", "OCR turn"),
    )


def test_not_identities_do_not_change_price_or_lower_line_pixels(case):
    price = wm.ValidationFilterDescriptor(
        "price-not", wm.FAMILY_MOVING_AVERAGE, "MA", wm.PRICE_AXIS,
        ("BUY",), ("MA5",), "{}", (),
    )
    rsi = wm.ValidationFilterDescriptor(
        "rsi-not", wm.FAMILY_RSI, "RSI", wm.LOWER_AXIS,
        ("BUY",), ("RSI",), "{}", (),
    )
    macd = wm.ValidationFilterDescriptor(
        "macd-not", wm.FAMILY_MACD_SIGNAL, "MACD", wm.LOWER_AXIS,
        ("SELL",), ("MACD", "SIGNAL"),
        '{"condition":{"target":"MACD","compare_target":"SIGNAL"}}', (),
    )
    rows = candles(4)
    canvas = wm.IndicatorFollowSignalValidationChartCanvas(
        rows,
        [],
        visualization_descriptors=(price, rsi, macd),
        visualization_cache=wm.ValidationIndicatorSeriesCache(4, (
            (price.identity, "MA5", tuple(row["close"] for row in rows)),
            (rsi.identity, "RSI", (35.0, 45.0, 55.0, 65.0)),
            (macd.identity, "MACD", (-2.0, -1.0, 1.0, 2.0)),
            (macd.identity, "SIGNAL", (-1.5, -0.5, 0.5, 1.5)),
        )),
    )
    case.widgets.append(canvas)
    canvas.resize(420, 320)
    canvas.set_time_view(0, len(rows))
    scale = canvas.price_scale()
    assert scale is not None

    def render_pixels():
        image = QImage(canvas.size(), QImage.Format_ARGB32)
        image.fill(Qt.transparent)
        painter = QPainter(image)
        canvas._draw_price_overlays(painter, scale)
        canvas._draw_lower_panes(painter)
        painter.end()
        return tuple(
            image.pixel(x, y)
            for y in range(image.height())
            for x in range(image.width())
        )

    ordinary_pixels = render_pixels()
    canvas.set_not_filter_identities(
        {
            ("BUY", price.identity),
            ("BUY", rsi.identity),
            ("SELL", macd.identity),
        },
        {("SELL", macd.identity)},
    )

    assert render_pixels() == ordinary_pixels


def test_not_identities_do_not_change_ocr_histogram_pixels(case):
    threshold = _ocr_threshold_descriptor(
        "ocr-threshold-buy", "BUY", "GREATER_THAN_OR_EQUAL", 0,
        bar_offset=1,
    )
    turn = _ocr_turn_descriptor("ocr-turn-buy", "BUY", "TURN_UP")
    values = (3.0, 1.0, 2.0, 4.0)
    owners = (threshold, turn)
    canvas = _ocr_turn_canvas(
        case, values, threshold, turn,
        presentations=(_ocr_filter_presentation("BUY", threshold, turn),),
    )
    canvas.resize(260, 140)
    canvas.set_time_view(0, len(values))
    canvas.set_ocr_turn_delays({("BUY", turn.identity): 1})
    scale = wm._ValidationPriceScale(-3.0, 3.0, 10, 120)

    def render_pixels():
        image = QImage(260, 140, QImage.Format_ARGB32)
        image.fill(Qt.transparent)
        image_painter = QPainter(image)
        canvas._draw_series_histogram(
            image_painter, values, scale, QPen(QColor("#ffffff")), owners,
        )
        image_painter.end()
        return image, tuple(
            image.pixel(x, y)
            for y in range(image.height())
            for x in range(image.width())
        )

    _ordinary_image, ordinary_pixels = render_pixels()
    canvas.set_not_filter_identities({
        ("BUY", threshold.identity), ("BUY", turn.identity),
    })
    assert render_pixels()[1] == ordinary_pixels

    canvas.set_not_filter_identities(
        {("BUY", threshold.identity), ("BUY", turn.identity)},
        {("BUY", threshold.identity), ("BUY", turn.identity)},
    )
    assert render_pixels()[1] == ordinary_pixels


def _ocr_turn_canvas(case, values, *descriptors, presentations=()):
    series = []
    for descriptor in descriptors:
        for channel in descriptor.series_keys:
            condition = descriptor.parameters["condition"]
            series.append((
                descriptor.identity,
                channel,
                values if channel == "OSC" else (
                    condition.get("threshold", condition.get("value")),
                ) * len(values),
            ))
    canvas = wm.IndicatorFollowSignalValidationChartCanvas(
        candles(len(values)), [], visualization_descriptors=descriptors,
        visualization_cache=wm.ValidationIndicatorSeriesCache(
            len(values), tuple(series),
        ),
        lower_filter_presentations=presentations,
    )
    case.widgets.append(canvas)
    return canvas


@pytest.mark.parametrize(("value", "expected"), [
    (-0.0, "0"),
    (-0.00001, "0"),
    (-1.23456, "-1.2346"),
    (1.23456, "1.2346"),
    (1234.5, "1,234.5"),
])
def test_crosshair_number_text_normalizes_only_rendered_negative_zero(value, expected):
    assert wm.IndicatorFollowSignalValidationChartCanvas._crosshair_number_text(value) == expected


def test_lower_reference_label_normalizes_negative_zero_without_changing_value(case):
    threshold = -0.00001
    descriptor = _ocr_threshold_descriptor(
        "ocr-negative-zero", "BUY", "LESS_THAN_OR_EQUAL", threshold,
    )
    canvas = _ocr_turn_canvas(case, (0.0,) * 4, descriptor)
    pane, = canvas.lower_pane_records()
    scale = canvas._lower_scale(
        wm.FAMILY_OCR_OSC, int(pane["top"]), int(pane["bottom"]),
    )
    assert scale is not None

    record, = canvas.lower_reference_line_records(wm.FAMILY_OCR_OSC, scale)
    assert record["value"] == threshold
    assert record["text"] == "\uB9E4\uC218 0"
    assert record["y"] == pytest.approx(scale.y_for_price(threshold))


def _histogram_display_color(canvas, index, values, owners):
    signal_color = canvas._histogram_valid_signal_color(index, owners)
    if signal_color is not None:
        return signal_color
    if values[index] > 0:
        return wm._OSC_POSITIVE
    if values[index] < 0:
        return wm._OSC_NEGATIVE
    return QColor()


def test_ocr_histogram_turn_colors_ignore_valid_and_trade_markers(case):
    buy = _ocr_turn_descriptor("ocr-turn-buy", "BUY", "TURN_UP")
    sell = _ocr_turn_descriptor("ocr-turn-sell", "SELL", "TURN_DOWN")
    buy_threshold = _ocr_threshold_descriptor(
        "ocr-threshold-buy", "BUY", "LESS_THAN_OR_EQUAL", 0,
    )
    sell_threshold = _ocr_threshold_descriptor(
        "ocr-threshold-sell", "SELL", "GREATER_THAN_OR_EQUAL", 0,
    )
    values = (3.0, -2.0, -1.0, 2.0, 1.0, 0.0, 1.0)
    canvas = _ocr_turn_canvas(
        case, values, buy_threshold, buy, sell_threshold, sell,
        presentations=(
            _ocr_filter_presentation("BUY", buy_threshold, buy),
            _ocr_filter_presentation("SELL", sell_threshold, sell),
        ),
    )
    canvas.set_ocr_turn_delays({
        ("BUY", buy.identity): 0,
        ("SELL", sell.identity): 0,
    })
    canvas.set_valid_filter_identities(())

    assert canvas._markers == []
    assert wm._BUY.name() == "#22c55e"
    assert wm._SELL.name() == "#f59e0b"
    owners = (buy_threshold, buy, sell_threshold, sell)
    assert _histogram_display_color(canvas, 2, values, owners) == wm._BUY
    assert _histogram_display_color(canvas, 4, values, owners) == wm._SELL
    assert _histogram_display_color(canvas, 0, values, owners) == wm._OSC_POSITIVE
    assert _histogram_display_color(canvas, 1, values, owners) == wm._OSC_NEGATIVE


def test_valid_mode_filters_disabled_ui_ocr_events_by_complete_logical_filter(case):
    window = window_for(case)
    buy = _ocr_turn_descriptor("ocr-turn-buy", "BUY", "TURN_UP")
    sell = _ocr_turn_descriptor("ocr-turn-sell", "SELL", "TURN_DOWN")
    buy_threshold = _ocr_threshold_descriptor(
        "ocr-threshold-buy", "BUY", "LESS_THAN_OR_EQUAL", 0,
    )
    sell_threshold = _ocr_threshold_descriptor(
        "ocr-threshold-sell", "SELL", "GREATER_THAN_OR_EQUAL", 0,
        bar_offset=1,
    )
    values = (3.0, -2.0, -1.0, 2.0, 1.0, 0.0, 1.0)
    canvas = _ocr_turn_canvas(
        case, values, buy_threshold, buy, sell_threshold, sell,
        presentations=(
            _ocr_filter_presentation("BUY", buy_threshold, buy),
            _ocr_filter_presentation("SELL", sell_threshold, sell),
        ),
    )
    ui_state = window.collect_indicator_follow_ui_state()
    ui_state["buy_ui"]["signal_filter"].update({
        "buy_ocr_enabled": False,
        "buy_ocr_bar_line": "0",
    })
    ui_state["sell_ui"]["signal_conditions"]["condition_a"].update({
        "ocr_check": False,
        "ocr_convert_line": "2",
    })
    canvas.set_ocr_turn_delays(window._ocr_turn_delays_from_ui_state(
        ui_state, (buy_threshold, buy, sell_threshold, sell),
    ))
    owners = (buy_threshold, buy, sell_threshold, sell)
    legend_captions = tuple(
        (side, tuple(block["caption"] for block in blocks))
        for side, _label, blocks in canvas._price_legend_rows()
    )

    assert canvas._configured_ocr_turn_delays == {
        ("BUY", buy.identity): 0,
        ("SELL", sell.identity): 2,
    }
    assert canvas._histogram_valid_signal_color(2, owners) == wm._BUY
    assert canvas._histogram_valid_signal_color(6, owners) == wm._SELL

    canvas.set_valid_filter_identities(
        {("SELL", sell_threshold.identity), ("SELL", sell.identity)},
        valid_mode_enabled=True,
    )
    assert canvas._histogram_valid_signal_color(2, owners) is None
    assert canvas._histogram_valid_signal_color(6, owners) == wm._SELL
    assert tuple(
        (side, tuple(block["caption"] for block in blocks))
        for side, _label, blocks in canvas._price_legend_rows()
    ) == legend_captions

    canvas.set_valid_filter_identities((), valid_mode_enabled=True)
    assert canvas._histogram_valid_signal_color(2, owners) is None
    assert canvas._histogram_valid_signal_color(6, owners) is None

    canvas.set_valid_filter_identities((), valid_mode_enabled=False)
    assert canvas._histogram_valid_signal_color(2, owners) == wm._BUY
    assert canvas._histogram_valid_signal_color(6, owners) == wm._SELL


def test_ocr_histogram_draws_turn_colors_over_inactive_state_pens(case):
    cases = (
        ("BUY", "TURN_UP", (3.0, 1.0, 2.0), wm._INACTIVE_SERIES, wm._BUY),
        ("SELL", "TURN_DOWN", (1.0, 3.0, 2.0), wm._UNSUPPORTED_SERIES, wm._SELL),
    )
    for side, operator, values, base_color, turn_color in cases:
        descriptor = _ocr_turn_descriptor("ocr-turn-" + side.lower(), side, operator)
        threshold = _ocr_threshold_descriptor(
            "ocr-threshold-" + side.lower(),
            side,
            "GREATER_THAN_OR_EQUAL",
            0,
        )
        canvas = _ocr_turn_canvas(
            case,
            values,
            threshold,
            descriptor,
            presentations=(_ocr_filter_presentation(side, threshold, descriptor),),
        )
        canvas.set_ocr_turn_delays({(side, descriptor.identity): 0})
        canvas.set_valid_filter_identities(())
        painter = Mock()

        assert canvas._markers == []
        assert canvas._valid_lower_filter_identities == set()
        owners = (threshold, descriptor)
        assert canvas._histogram_valid_signal_color(2, owners) == turn_color

        canvas._draw_series_histogram(
            painter,
            values,
            wm._ValidationPriceScale(-3.0, 3.0, 0, 100),
            QPen(base_color),
            owners,
        )

        assert [call.args[0].color() for call in painter.setBrush.call_args_list] == [
            base_color,
            turn_color,
        ]
        assert [call.args[0].color() for call in painter.setPen.call_args_list] == [
            base_color,
            turn_color,
        ]
        assert [len(call.args[0]) for call in painter.drawRects.call_args_list] == [2, 1]


def test_valid_ocr_histogram_emphasis_paints_stronger_same_rgb_outline(case):
    threshold = _ocr_threshold_descriptor(
        "ocr-threshold-buy", "BUY", "GREATER_THAN_OR_EQUAL", 0,
    )
    turn = _ocr_turn_descriptor("ocr-turn-buy", "BUY", "TURN_UP")
    values = (3.0, 1.0, 2.0)
    owners = (threshold, turn)
    canvas = _ocr_turn_canvas(
        case, values, threshold, turn,
        presentations=(_ocr_filter_presentation("BUY", threshold, turn),),
    )
    canvas.resize(260, 140)
    canvas.set_time_view(0, len(values))
    canvas.set_ocr_turn_delays({("BUY", turn.identity): 0})

    def buy_pixel_count():
        image = QImage(260, 140, QImage.Format_ARGB32)
        image.fill(Qt.transparent)
        painter = QPainter(image)
        canvas._draw_series_histogram(
            painter,
            values,
            wm._ValidationPriceScale(-3.0, 3.0, 10, 120),
            QPen(QColor("#ffffff")),
            owners,
        )
        painter.end()
        return sum(
            image.pixelColor(x, y).name() == wm._BUY.name()
            for x in range(image.width())
            for y in range(image.height())
        )

    ordinary_pixels = buy_pixel_count()
    canvas.set_valid_filter_identities(
        {("BUY", threshold.identity), ("BUY", turn.identity)},
        valid_mode_enabled=True,
    )
    emphasized_pixels = buy_pixel_count()

    assert canvas._histogram_valid_signal_color(2, owners) == wm._BUY
    assert ordinary_pixels > 0
    assert emphasized_pixels > ordinary_pixels


def test_valid_zero_cross_keeps_ordinary_histogram_outline(case):
    descriptor = wm.ValidationFilterDescriptor(
        "ocr-zero-cross-buy", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("BUY",), ("OSC",),
        '{"condition":{"operator":"ZERO_CROSS_UP","target":"OSC"}}',
        (),
    )
    values = (-2.0, -1.0, 1.0)
    canvas = _ocr_turn_canvas(case, values, descriptor)
    canvas.resize(260, 140)
    canvas.set_time_view(0, len(values))

    def buy_pixel_count():
        image = QImage(260, 140, QImage.Format_ARGB32)
        image.fill(Qt.transparent)
        painter = QPainter(image)
        canvas._draw_series_histogram(
            painter,
            values,
            wm._ValidationPriceScale(-3.0, 3.0, 10, 120),
            QPen(QColor("#ffffff")),
            (descriptor,),
        )
        painter.end()
        return sum(
            image.pixelColor(x, y).name() == wm._BUY.name()
            for x in range(image.width())
            for y in range(image.height())
        )

    canvas.set_valid_filter_identities(
        {("BUY", descriptor.identity)}, valid_mode_enabled=False,
    )
    ordinary_pixels = buy_pixel_count()
    canvas.set_valid_filter_identities(
        {("BUY", descriptor.identity)}, valid_mode_enabled=True,
    )

    assert canvas._histogram_valid_signal_color(2, (descriptor,)) == wm._BUY
    assert buy_pixel_count() == ordinary_pixels


@pytest.mark.parametrize("delay", (1, 4, 100))
def test_buy_ocr_histogram_turn_delay_has_no_artificial_limit(case, delay):
    buy = _ocr_turn_descriptor("ocr-turn-buy", "BUY", "TURN_UP")
    threshold = _ocr_threshold_descriptor(
        "ocr-threshold-buy", "BUY", "GREATER_THAN_OR_EQUAL", 0,
    )
    values = (3.0, 1.0, 2.0) + tuple(float(index) for index in range(3, 110))
    canvas = _ocr_turn_canvas(
        case, values, threshold, buy,
        presentations=(_ocr_filter_presentation("BUY", threshold, buy),),
    )
    canvas.set_ocr_turn_delays({("BUY", buy.identity): delay})
    target = 2 + delay

    owners = (threshold, buy)
    assert canvas._histogram_valid_signal_color(target, owners) == wm._BUY
    assert canvas._histogram_valid_signal_color(target - 1, owners) is None
    assert canvas._histogram_valid_signal_color(target + 1, owners) is None


@pytest.mark.parametrize(
    ("values", "delay"),
    (((3.0, 1.0, 2.0, None), 1), ((3.0, 1.0, 2.0, 3.0), 1000)),
)
def test_ocr_histogram_does_not_draw_incomplete_or_outside_target(
    case, values, delay,
):
    buy = _ocr_turn_descriptor("ocr-turn-buy", "BUY", "TURN_UP")
    threshold = _ocr_threshold_descriptor(
        "ocr-threshold-buy", "BUY", "GREATER_THAN_OR_EQUAL", 0,
    )
    canvas = _ocr_turn_canvas(
        case, values, threshold, buy,
        presentations=(_ocr_filter_presentation("BUY", threshold, buy),),
    )
    canvas.set_ocr_turn_delays({("BUY", buy.identity): delay})
    painter = Mock()
    canvas._draw_series_histogram(
        painter,
        values,
        wm._ValidationPriceScale(-3.0, 3.0, 0, 100),
        QPen(QColor("#ffffff")),
        (threshold, buy),
    )

    drawn_colors = [call.args[0].color() for call in painter.setPen.call_args_list]
    assert wm._BUY not in drawn_colors


def test_ocr_histogram_same_index_buy_sell_stays_ordinary(case):
    buy = _ocr_turn_descriptor("ocr-turn-buy", "BUY", "TURN_UP")
    sell = _ocr_turn_descriptor("ocr-turn-sell", "SELL", "TURN_DOWN")
    buy_threshold = _ocr_threshold_descriptor(
        "ocr-threshold-buy", "BUY", "GREATER_THAN_OR_EQUAL", 0,
    )
    sell_threshold = _ocr_threshold_descriptor(
        "ocr-threshold-sell", "SELL", "GREATER_THAN_OR_EQUAL", 0,
    )
    values = (3.0, 1.0, 2.0)
    canvas = _ocr_turn_canvas(
        case, values, buy_threshold, buy, sell_threshold, sell,
        presentations=(
            _ocr_filter_presentation("BUY", buy_threshold, buy),
            _ocr_filter_presentation("SELL", sell_threshold, sell),
        ),
    )
    sell_values = (1.0, 3.0, 2.0)
    canvas._series_values_by_key[(sell.identity, "OSC")] = sell_values
    canvas._series_values_by_key[(sell_threshold.identity, "OSC")] = sell_values
    canvas.set_ocr_turn_delays({
        ("BUY", buy.identity): 0,
        ("SELL", sell.identity): 0,
    })

    owners = (buy_threshold, buy, sell_threshold, sell)
    assert canvas._histogram_valid_signal_color(2, owners) is None
    assert _histogram_display_color(canvas, 2, values, owners) == wm._OSC_POSITIVE

    canvas.set_valid_filter_identities(
        {("BUY", buy_threshold.identity), ("BUY", buy.identity)},
        valid_mode_enabled=True,
    )
    assert canvas._histogram_valid_signal_color(2, owners) == wm._BUY

    canvas.set_valid_filter_identities((), valid_mode_enabled=False)
    assert canvas._histogram_valid_signal_color(2, owners) is None


@pytest.mark.parametrize(
    ("values", "delay", "target", "expected"),
    (
        ((1.0, 3.0, -1.0), 0, 2, wm._SELL),
        ((-3.0, -1.0, 0.0), 0, 2, None),
        ((1.0, 3.0, -1.0, -1.0), 1, 3, wm._SELL),
    ),
)
def test_sell_ocr_histogram_requires_threshold_turn_and_delay(
    case, values, delay, target, expected,
):
    threshold = _ocr_threshold_descriptor(
        "ocr-threshold-sell", "SELL", "GREATER_THAN_OR_EQUAL", 0,
        bar_offset=1,
    )
    turn = _ocr_turn_descriptor("ocr-turn-sell", "SELL", "TURN_DOWN")
    canvas = _ocr_turn_canvas(
        case, values, threshold, turn,
        presentations=(_ocr_filter_presentation("SELL", threshold, turn),),
    )
    canvas.set_ocr_turn_delays({("SELL", turn.identity): delay})

    assert canvas._markers == []
    assert canvas._histogram_valid_signal_color(
        target, (threshold, turn),
    ) == expected
    ordinary = (
        wm._OSC_NEGATIVE if values[target] < 0
        else wm._OSC_POSITIVE if values[target] > 0
        else QColor()
    )
    assert _histogram_display_color(canvas, target, values, (threshold, turn)) == (
        expected
        if expected is not None
        else ordinary
    )


@pytest.mark.parametrize("delay", (0, 2))
@pytest.mark.parametrize(
    ("values", "engine_passed", "expected_color"),
    (
        ((1.0, 3.0, -1.0), True, wm._SELL),
        ((-3.0, -1.0, 0.0), False, None),
    ),
)
def test_sell_ocr_histogram_matches_mapper_bar_offset_and_engine_group(
    case, delay, values, engine_passed, expected_color,
):
    window = window_for(case)
    mapper = window._load_indicator_follow_rule_mapper()
    warnings = []
    candidate = mapper._build_sell_condition_a_signal_candidate({
        "ocr_check": True,
        "ocr_direction_combo": "TURN_DOWN",
        "ocr_convert_line": str(delay),
        "ocr_compare_combo": ">=",
        "ocr_sign_combo": "+",
        "ocr_value_line": "0",
        "ocr_logic_combo": "AND",
        "gap_check": True,
        "gap_left_combo": "AVG_PRICE",
        "gap_right_combo": "CURRENT_PRICE",
        "gap_direction_combo": "UP",
        "gap_compare_combo": "GTE",
        "gap_value_line": "0.5",
        "gap_logic_combo": "AND",
        "rsi_check": False,
    }, warnings)

    assert warnings == []
    assert candidate["value"]["order_delay_bars"] == delay
    group = candidate["value"]["groups"][0]
    conditions = group["conditions"]
    threshold_condition = next(
        condition for condition in conditions
        if condition["target"] == "OSC" and condition["operator"] == ">="
    )
    turn_condition = next(
        condition for condition in conditions
        if condition["target"] == "OSC" and condition["operator"] == "TURN_DOWN"
    )
    assert threshold_condition["bar_offset"] == 1

    display_values = values + (values[-1],) * delay
    series_map = {
        "OSC": list(display_values),
        "CURRENT_PRICE": [101.0] * len(display_values),
        "AVG_PRICE": [100.0] * len(display_values),
    }
    group_result = evaluate_group(group, series_map, index=2)
    assert group_result.passed is engine_passed
    if engine_passed:
        assert all(detail.startswith("PASS ") for detail in group_result.details)

    threshold = wm.ValidationFilterDescriptor(
        "mapped-ocr-threshold-sell", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("SELL",), ("OSC", "CRITERION"),
        json.dumps({"condition": threshold_condition}), (),
    )
    turn = wm.ValidationFilterDescriptor(
        "mapped-ocr-turn-sell", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("SELL",), ("OSC",),
        json.dumps({"condition": turn_condition}), (),
    )
    canvas = _ocr_turn_canvas(
        case, display_values, threshold, turn,
        presentations=(_ocr_filter_presentation("SELL", threshold, turn),),
    )
    canvas.set_ocr_turn_delays({("SELL", turn.identity): delay})

    assert canvas._histogram_valid_signal_color(
        2 + delay, (threshold, turn),
    ) == expected_color


def test_projection_refreshes_ocr_delays_for_replaced_descriptor_identities(case):
    window = window_for(case)
    install(window)
    old_buy = _ocr_turn_descriptor("projection-buy-old", "BUY", "TURN_UP")
    old_sell = _ocr_turn_descriptor("projection-sell-old", "SELL", "TURN_DOWN")
    buy = _ocr_turn_descriptor("projection-buy-new", "BUY", "TURN_UP")
    sell = _ocr_turn_descriptor("projection-sell-new", "SELL", "TURN_DOWN")
    values = tuple(1.0 for _ in window._candles)
    old_cache = wm.ValidationIndicatorSeriesCache(len(values), (
        (old_buy.identity, "OSC", values),
        (old_sell.identity, "OSC", values),
    ))
    cache = wm.ValidationIndicatorSeriesCache(len(values), (
        (buy.identity, "OSC", values),
        (sell.identity, "OSC", values),
    ))
    buy_blocker = QSignalBlocker(window.buy_ocr_bar_line)
    sell_check_blocker = QSignalBlocker(window.sell_signal_condition_a_ocr_check)
    sell_delay_blocker = QSignalBlocker(window.sell_signal_condition_a_ocr_convert_line)
    window.buy_ocr_bar_line.setText("4")
    window.sell_signal_condition_a_ocr_check.setChecked(True)
    window.sell_signal_condition_a_ocr_convert_line.setText("2")
    del buy_blocker, sell_check_blocker, sell_delay_blocker
    window.canvas.set_visualization_projection(
        (old_buy, old_sell), old_cache, {}, [],
    )
    window.canvas.set_ocr_turn_delays({
        ("BUY", old_buy.identity): 4,
        ("SELL", old_sell.identity): 2,
    })

    window._apply_visualization_projection((buy, sell), cache, {})

    assert window.canvas._configured_ocr_turn_delays == {
        ("BUY", buy.identity): 4,
        ("SELL", sell.identity): 2,
    }


def test_valid_emphasis_does_not_create_unconfigured_ocr_turn_color(case):
    turn = _ocr_turn_descriptor("valid-only-ocr-turn", "SELL", "TURN_DOWN")
    values = (1.0, 3.0, 2.0)
    canvas = _ocr_turn_canvas(case, values, turn)

    assert canvas._histogram_valid_signal_color(2, (turn,)) is None
    canvas.set_valid_filter_identities({("SELL", turn.identity)})
    assert canvas._histogram_valid_signal_color(2, (turn,)) is None

    canvas.set_valid_filter_identities(
        {("SELL", turn.identity)},
        index_ranges={("SELL", turn.identity): ((0, 2),)},
        delay_ranges={("SELL", turn.identity): ((0, 2, 0),)},
    )
    assert canvas._histogram_valid_signal_color(2, (turn,)) == wm._SELL


def test_sell_ocr_histogram_ignores_unconfigured_buy_filter(case):
    sell_threshold = _ocr_threshold_descriptor(
        "ocr-threshold-sell", "SELL", "GREATER_THAN_OR_EQUAL", 0,
    )
    sell_turn = _ocr_turn_descriptor("ocr-turn-sell", "SELL", "TURN_DOWN")
    buy_threshold = _ocr_threshold_descriptor(
        "ocr-threshold-buy", "BUY", "GREATER_THAN_OR_EQUAL", 0,
    )
    buy_turn = _ocr_turn_descriptor("ocr-turn-buy", "BUY", "TURN_UP")
    values = (1.0, 3.0, 2.0)
    canvas = _ocr_turn_canvas(
        case,
        values,
        sell_threshold,
        sell_turn,
        buy_threshold,
        buy_turn,
        presentations=(
            _ocr_filter_presentation("SELL", sell_threshold, sell_turn),
            _ocr_filter_presentation("BUY", buy_threshold, buy_turn),
        ),
    )
    buy_values = (3.0, 1.0, 2.0)
    canvas._series_values_by_key[(buy_threshold.identity, "OSC")] = buy_values
    canvas._series_values_by_key[(buy_turn.identity, "OSC")] = buy_values
    canvas.set_ocr_turn_delays({("SELL", sell_turn.identity): 0})

    assert canvas._markers == []
    assert canvas._histogram_valid_signal_color(
        2,
        (sell_threshold, sell_turn, buy_threshold, buy_turn),
    ) == wm._SELL


def test_ocr_histogram_turn_without_logical_threshold_filter_is_ordinary(case):
    turn = _ocr_turn_descriptor("ocr-turn-sell", "SELL", "TURN_DOWN")
    values = (1.0, 3.0, 2.0)
    canvas = _ocr_turn_canvas(case, values, turn)
    canvas.set_ocr_turn_delays({("SELL", turn.identity): 0})

    assert canvas._histogram_valid_signal_color(2, (turn,)) is None
    assert _histogram_display_color(canvas, 2, values, (turn,)) == wm._OSC_POSITIVE


def test_settings_apply_refreshes_retained_ocr_turn_metadata_without_chart_reload(case):
    window = window_for(case)
    install(window)
    canvas = window.canvas
    window.filter_display_valid_check.setChecked(False)
    window.buy_ocr_bar_line.setText("4")
    window.sell_signal_condition_a_ocr_convert_line.setText("1")
    window.sell_signal_condition_a_ocr_check.setChecked(False)
    window.settings_apply_requested.connect(
        lambda _payload: window.show_settings_apply_result("", success=True)
    )

    assert window._request_settings_apply() is not None
    buy_turn_ids = {
        descriptor.identity
        for descriptor in canvas._visualization_descriptors
        if descriptor.family == wm.FAMILY_OCR_OSC
        and "BUY" in descriptor.sides
        and descriptor.parameters.get("condition", {}).get("operator")
        in {"TURN_UP", "TURN_DOWN"}
    }
    sell_turn_ids = {
        descriptor.identity
        for descriptor in canvas._visualization_descriptors
        if descriptor.family == wm.FAMILY_OCR_OSC
        and "SELL" in descriptor.sides
        and descriptor.parameters.get("condition", {}).get("operator")
        in {"TURN_UP", "TURN_DOWN"}
    }

    assert window.canvas is canvas
    assert buy_turn_ids
    assert sell_turn_ids
    assert {
        delay for (side, identity), delay in canvas._configured_ocr_turn_delays.items()
        if side == "BUY" and identity in buy_turn_ids
    } == {4}
    assert {
        delay for (side, identity), delay in canvas._configured_ocr_turn_delays.items()
        if side == "SELL" and identity in sell_turn_ids
    } == {1}


@pytest.mark.parametrize("raw_delay", ("-1", "NaN", "1.5"))
def test_invalid_buy_ocr_turn_delay_is_ignored(case, raw_delay):
    window = window_for(case)
    buy = _ocr_turn_descriptor("ocr-turn-buy", "BUY", "TURN_UP")
    ui_state = window.collect_indicator_follow_ui_state()
    ui_state["buy_ui"]["signal_filter"]["buy_ocr_bar_line"] = raw_delay

    assert window._ocr_turn_delays_from_ui_state(ui_state, (buy,)) == {}


def test_explicitly_disabled_buy_ocr_turn_retains_configured_display_delay(case):
    window = window_for(case)
    buy = _ocr_turn_descriptor("ocr-turn-buy", "BUY", "TURN_UP")
    ui_state = window.collect_indicator_follow_ui_state()
    signal_filter = ui_state["buy_ui"]["signal_filter"]
    signal_filter["buy_ocr_enabled"] = False

    assert window._ocr_turn_delays_from_ui_state(ui_state, (buy,)) == {
        ("BUY", buy.identity): 0,
    }


def test_same_value_lower_criteria_deduplicate_only_identical_visible_series(case):
    rows = candles(10)
    buy_criterion = wm.ValidationFilterDescriptor(
        "ocr-buy-100", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("BUY",), ("CRITERION_BUY",), "{}", (),
    )
    sell_criterion = wm.ValidationFilterDescriptor(
        "ocr-sell-100", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("SELL",), ("CRITERION_SELL",), "{}", (),
    )

    def drawn_path_count(buy_values, sell_values):
        canvas = wm.IndicatorFollowSignalValidationChartCanvas(
            rows, [], visualization_descriptors=(buy_criterion, sell_criterion),
            visualization_cache=wm.ValidationIndicatorSeriesCache(10, (
                (buy_criterion.identity, "CRITERION_BUY", buy_values),
                (sell_criterion.identity, "CRITERION_SELL", sell_values),
            )),
        )
        case.widgets.append(canvas)
        painter = Mock()
        canvas._draw_lower_panes(painter)
        return painter.drawPath.call_count

    assert drawn_path_count(
        (100.0,) * 5 + (None,) * 5,
        (None,) * 5 + (100.0,) * 5,
    ) == 2
    assert drawn_path_count((100.0,) * 10, (100.0,) * 10) == 1


def test_shared_numeric_lower_labels_two_lines_and_fixed_price_axis_width(case):
    window = window_for(case)
    axis = window.fixed_price_axis
    fixed_width = axis.width()
    assert fixed_width == (
        QFontMetrics(axis.font()).horizontalAdvance(axis._FIXED_WIDTH_REFERENCE_PRICE)
        + axis._HORIZONTAL_PADDING * 2
    )
    install(window)
    descriptors = (
        wm.ValidationFilterDescriptor(
            "ocr-buy-zero", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
            ("BUY",), ("CRITERION",),
            '{"condition":{"operator":"LESS_THAN_OR_EQUAL","threshold":0}}', (),
        ),
        wm.ValidationFilterDescriptor(
            "ocr-sell-zero", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
            ("SELL",), ("CRITERION",),
            '{"condition":{"operator":"GREATER_THAN_OR_EQUAL","threshold":0}}', (),
        ),
        wm.ValidationFilterDescriptor(
            "rsi-buy-45", wm.FAMILY_RSI, "RSI", wm.LOWER_AXIS,
            ("BUY",), ("CRITERION",), "{}", (),
        ),
        wm.ValidationFilterDescriptor(
            "rsi-sell-45", wm.FAMILY_RSI, "RSI", wm.LOWER_AXIS,
            ("SELL",), ("CRITERION",), "{}", (),
        ),
        wm.ValidationFilterDescriptor(
            "rsi-buy-30", wm.FAMILY_RSI, "RSI", wm.LOWER_AXIS,
            ("BUY",), ("CRITERION_LOWER",), "{}", (),
        ),
    )
    count = len(window._candles)
    cache = wm.ValidationIndicatorSeriesCache(count, (
        (descriptors[0].identity, "CRITERION", (0.0,) * count),
        (descriptors[1].identity, "CRITERION", (0.0,) * count),
        (descriptors[2].identity, "CRITERION", (45.0,) * count),
        (descriptors[3].identity, "CRITERION", (45.0,) * count),
        (descriptors[4].identity, "CRITERION_LOWER", (30.0,) * count),
    ))
    window.canvas.set_visualization_projection(descriptors, cache, {}, [])
    records = axis.lower_reference_axis_records()
    zero, = [record for record in records if record["value"] == 0.0]
    assert zero["sides"] == ("SELL", "BUY")
    assert zero["text"] == "\uB9E4\uB3C4 0\n\uB9E4\uC218 0"
    shared = [record for record in records if record["value"] == 45.0]
    assert len(shared) == 1
    assert shared[0]["sides"] == ("SELL", "BUY")
    assert shared[0]["text"] == "\uB9E4\uB3C4 45\n\uB9E4\uC218 45"
    assert [
        (record["sides"], record["text"])
        for record in records
        if record["value"] == 45.0
    ] == [(("SELL", "BUY"), "\uB9E4\uB3C4 45\n\uB9E4\uC218 45")]
    assert [
        (record["sides"], record["text"])
        for record in records
        if record["value"] == 30.0
    ] == [(("BUY",), "\uB9E4\uC218 30")]
    assert all("/" not in record["text"] for record in records)
    painter = Mock()
    painter.font.return_value = axis.font()
    with patch.object(wm, "QPainter", return_value=painter), patch.object(
        axis, "price_axis_records", return_value=[]
    ), patch.object(axis, "lower_reference_axis_records", return_value=[zero]):
        axis.paintEvent(None)
    calls = painter.drawText.call_args_list
    assert [call.args[2] for call in calls] == ["\uB9E4\uB3C4 0", "\uB9E4\uC218 0"]
    assert calls[0].args[0].bottom() <= calls[1].args[0].top()
    pens = [
        call.args[0] for call in painter.setPen.call_args_list
        if call.args and isinstance(call.args[0], QPen)
    ]
    assert [pen.color() for pen in pens] == [wm._SELL, wm._BUY]
    assert axis.width() == fixed_width
    with patch.object(axis, "_labels", return_value=["X" * 200]):
        axis.refresh_scale()
        assert axis.width() == fixed_width
    axis.refresh_scale()
    assert axis.width() == fixed_width


def test_lower_reference_text_layout_uses_columns_without_moving_source_y(case):
    window = window_for(case)
    install(window)
    window.show()
    case.app.processEvents()
    axis = window.fixed_price_axis
    viewport_top = window.chart_scroll_area.viewport().geometry().top()
    pane = next(
        pane for pane in window.canvas.lower_pane_records()
        if pane["family"] == wm.FAMILY_OCR_OSC
    )
    anchor = viewport_top + pane["top"] + 40.0
    records = [
        {
            "family": wm.FAMILY_OCR_OSC,
            "value": 99.0,
            "y": anchor,
            "sides": ("BUY",),
            "text": "\uB9E4\uC218 99",
        },
        {
            "family": wm.FAMILY_OCR_OSC,
            "value": 100.0,
            "y": anchor + 1.0,
            "sides": ("SELL",),
            "text": "\uB9E4\uB3C4 100",
        },
    ]
    source_y = [record["y"] for record in records]
    metrics = QFontMetrics(axis.font())
    layouts = axis._lower_reference_text_layout(metrics, records)

    expected = [
        (id(record), line)
        for record in records
        for line in (str(record["text"]).splitlines() or [""])
    ]
    assert [(id(layout["record"]), layout["text"]) for layout in layouts] == expected
    assert [record["y"] for record in records] == source_y

    assert [layout["rect"].center().y() for layout in layouts] == source_y
    assert all(
        metrics.horizontalAdvance(layout["text"]) <= layout["rect"].width()
        for layout in layouts
    )
    assert not layouts[0]["rect"].intersects(layouts[1]["rect"])
    assert {layout["column_count"] for layout in layouts} == {2}
    assert {layout["column"] for layout in layouts} == {0, 1}

    painter = Mock()
    painter.font.return_value = axis.font()
    with patch.object(wm, "QPainter", return_value=painter), patch.object(
        axis, "price_axis_records", return_value=[]
    ), patch.object(axis, "lower_reference_axis_records", return_value=records):
        axis.paintEvent(None)
    assert [
        (call.args[0], call.args[2]) for call in painter.drawText.call_args_list
    ] == [(layout["rect"], layout["text"]) for layout in layouts]


def test_macd_and_ocr_zero_criteria_share_real_line_with_rsi_unchanged(case):
    window = window_for(case)
    install(window, candles(4))
    window.filter_display_check.setChecked(True)
    window.filter_display_valid_check.setChecked(False)
    assert window.filter_display_check.isChecked()
    assert not window.filter_display_valid_check.isChecked()

    macd_zero = wm.ValidationFilterDescriptor(
        "macd-buy-zero", wm.FAMILY_MACD_SIGNAL, "MACD", wm.LOWER_AXIS,
        ("BUY",), ("CRITERION",),
        '{"condition":{"operator":"LESS_THAN_OR_EQUAL","threshold":0}}', (),
    )
    ocr_zero = wm.ValidationFilterDescriptor(
        "ocr-sell-zero", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("SELL",), ("CRITERION",),
        '{"condition":{"operator":"GREATER_THAN_OR_EQUAL","threshold":0}}', (),
    )
    ocr_turn = wm.ValidationFilterDescriptor(
        "ocr-turn-buy", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("BUY",), ("OSC",),
        '{"condition":{"operator":"TURN_UP","target":"OSC"}}', (),
    )
    rsi_45 = wm.ValidationFilterDescriptor(
        "rsi-buy-45", wm.FAMILY_RSI, "RSI", wm.LOWER_AXIS,
        ("BUY",), ("CRITERION",),
        '{"condition":{"operator":"GREATER_THAN_OR_EQUAL","threshold":45}}', (),
    )
    count = len(window._candles)
    window.canvas.set_valid_filter_identities(())
    window.canvas.set_visualization_projection(
        (macd_zero, ocr_zero, ocr_turn, rsi_45),
        wm.ValidationIndicatorSeriesCache(count, (
            (macd_zero.identity, "CRITERION", (0.0,) * count),
            (ocr_zero.identity, "CRITERION", (0.0,) * count),
            (ocr_turn.identity, "OSC", (-2.0, -1.0, -2.0, -1.0)),
            (rsi_45.identity, "CRITERION", (45.0,) * count),
        )),
        {},
        [],
    )

    records = window.fixed_price_axis.lower_reference_axis_records()
    assert [(record["family"], record["value"], record["sides"], record["text"])
            for record in records] == [
        (wm.FAMILY_RSI, 45.0, ("BUY",), "\uB9E4\uC218 45"),
        (wm.FAMILY_OCR_OSC, 0.0, ("SELL", "BUY"), "\uB9E4\uB3C4 0\n\uB9E4\uC218 0"),
    ]

    panes = {pane["family"]: pane for pane in window.canvas.lower_pane_records()}
    ocr_scale = window.canvas._lower_scale(
        wm.FAMILY_OCR_OSC,
        int(panes[wm.FAMILY_OCR_OSC]["top"]),
        int(panes[wm.FAMILY_OCR_OSC]["bottom"]),
    )
    rsi_scale = window.canvas._lower_scale(
        wm.FAMILY_RSI,
        int(panes[wm.FAMILY_RSI]["top"]),
        int(panes[wm.FAMILY_RSI]["bottom"]),
    )
    assert ocr_scale is not None and rsi_scale is not None
    painter = Mock()
    window.canvas._draw_lower_panes(painter)
    path_y = sorted(
        call.args[0].boundingRect().center().y()
        for call in painter.drawPath.call_args_list
    )
    assert path_y == pytest.approx(sorted((
        ocr_scale.y_for_price(0.0),
        rsi_scale.y_for_price(45.0),
    )))


def test_sell_100_reference_stays_on_line_and_shared_color_order(case):
    window = window_for(case)
    install(window, candles(4))
    osc = wm.ValidationFilterDescriptor(
        "ocr-large-range", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("BUY", "SELL"), ("OSC",), "{}", (),
    )
    buy_zero = wm.ValidationFilterDescriptor(
        "ocr-buy-zero-anchor", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("BUY",), ("CRITERION_BUY",), "{}", (),
    )
    sell_100 = wm.ValidationFilterDescriptor(
        "ocr-sell-100-anchor", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("SELL",), ("CRITERION_SELL",), "{}", (),
    )
    buy_100 = wm.ValidationFilterDescriptor(
        "ocr-buy-100-anchor", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("BUY",), ("CRITERION_BUY_100",), "{}", (),
    )
    count = len(window._candles)
    window.canvas.set_visualization_projection(
        (osc, buy_zero, sell_100, buy_100),
        wm.ValidationIndicatorSeriesCache(count, (
            (osc.identity, "OSC", (-10_000.0, 10_000.0) * (count // 2)),
            (buy_zero.identity, "CRITERION_BUY", (0.0,) * count),
            (sell_100.identity, "CRITERION_SELL", (100.0,) * count),
            (buy_100.identity, "CRITERION_BUY_100", (100.0,) * count),
        )),
        {},
        [],
    )
    window.show()
    case.app.processEvents()
    pane, = window.canvas.lower_pane_records()
    scale = window.canvas._lower_scale(
        wm.FAMILY_OCR_OSC, int(pane["top"]), int(pane["bottom"]),
    )
    assert scale is not None
    axis = window.fixed_price_axis
    records = axis.lower_reference_axis_records()
    zero, = [record for record in records if record["value"] == 0.0]
    assert zero["sides"] == ("BUY",)
    assert zero["text"] == "\uB9E4\uC218 0"
    viewport_top = window.chart_scroll_area.viewport().geometry().top()
    assert zero["y"] == pytest.approx(viewport_top + scale.y_for_price(0.0))
    shared, = [record for record in records if record["value"] == 100.0]
    assert shared["sides"] == ("SELL", "BUY")
    assert shared["text"] == "\uB9E4\uB3C4 100\n\uB9E4\uC218 100"
    assert shared["y"] == pytest.approx(viewport_top + scale.y_for_price(100.0))
    assert abs(scale.y_for_price(100.0) - scale.y_for_price(0.0)) < QFontMetrics(axis.font()).height()

    metrics = QFontMetrics(axis.font())
    layouts = axis._lower_reference_text_layout(metrics, [shared])
    assert [layout["text"] for layout in layouts] == ["\uB9E4\uB3C4 100", "\uB9E4\uC218 100"]
    assert (layouts[0]["rect"].top() + layouts[-1]["rect"].bottom()) / 2.0 == pytest.approx(shared["y"])

    canvas_painter = Mock()
    window.canvas._draw_lower_panes(canvas_painter)
    path_y = sorted(
        call.args[0].boundingRect().center().y()
        for call in canvas_painter.drawPath.call_args_list
    )
    assert path_y == pytest.approx(sorted((
        scale.y_for_price(0.0), scale.y_for_price(100.0),
    )))
    zero_y = int(scale.y_for_price(0.0))
    assert any(
        len(call.args) == 4
        and call.args[1] == zero_y
        and call.args[3] == zero_y
        for call in canvas_painter.drawLine.call_args_list
    )

    painter = Mock()
    painter.font.return_value = axis.font()
    with patch.object(wm, "QPainter", return_value=painter), patch.object(
        axis, "price_axis_records", return_value=[]
    ), patch.object(axis, "lower_reference_axis_records", return_value=[shared]):
        axis.paintEvent(None)
    assert [call.args[2] for call in painter.drawText.call_args_list] == [
        "\uB9E4\uB3C4 100", "\uB9E4\uC218 100",
    ]
    pens = [
        call.args[0] for call in painter.setPen.call_args_list
        if call.args and isinstance(call.args[0], QPen)
    ]
    assert [pen.color() for pen in pens] == [wm._SELL, wm._BUY]


def test_lower_reference_text_layout_keeps_clear_labels_at_source_y(case):
    window = window_for(case)
    install(window)
    window.show()
    case.app.processEvents()
    axis = window.fixed_price_axis
    metrics = QFontMetrics(axis.font())
    viewport_top = window.chart_scroll_area.viewport().geometry().top()
    pane = next(
        pane for pane in window.canvas.lower_pane_records()
        if pane["family"] == wm.FAMILY_OCR_OSC
    )
    top = viewport_top + pane["top"]
    records = [
        {
            "family": wm.FAMILY_OCR_OSC,
            "value": value,
            "y": top + offset,
            "sides": ("BUY",),
            "text": text,
        }
        for value, offset, text in ((1.0, 20.0, "BUY 1"), (2.0, 60.0, "BUY 2"))
    ]
    layouts = axis._lower_reference_text_layout(metrics, records)
    assert {layout["column_count"] for layout in layouts} == {1}
    assert {layout["column"] for layout in layouts} == {0}
    assert [layout["rect"].center().y() for layout in layouts] == [
        record["y"] for record in records
    ]


def test_lower_reference_text_layout_keeps_wide_nearby_rsi_labels_on_source_y(case):
    window = window_for(case)
    install(window)
    axis = window.fixed_price_axis
    viewport_top = window.chart_scroll_area.viewport().geometry().top()
    pane = next(
        pane for pane in window.canvas.lower_pane_records()
        if pane["family"] == wm.FAMILY_RSI
    )
    pane_top = viewport_top + pane["top"]
    records = [
        {
            "family": wm.FAMILY_RSI,
            "value": 45.0,
            "y": pane_top + 30.0,
            "sides": ("BUY",),
            "text": "\uB9E4\uC218 45",
        },
        {
            "family": wm.FAMILY_RSI,
            "value": 30.0,
            "y": pane_top + 31.0,
            "sides": ("BUY",),
            "text": "\uB9E4\uC218 30",
        },
    ]
    source_y = [record["y"] for record in records]
    metrics = Mock()
    metrics.height.return_value = 14
    metrics.horizontalAdvance.side_effect = lambda text: {
        "\uB9E4\uC218 45": 221,
        "\uB9E4\uC218 30": 50,
    }[text]
    painter = Mock()
    painter.font.return_value = axis.font()

    with patch.object(axis, "width", return_value=240):
        layouts = axis._lower_reference_text_layout(metrics, records)
        with patch.object(wm, "QPainter", return_value=painter), patch.object(
            wm, "QFontMetrics", return_value=metrics,
        ), patch.object(axis, "price_axis_records", return_value=[]), patch.object(
            axis, "lower_reference_axis_records", return_value=records,
        ):
            axis.paintEvent(None)

    assert [record["y"] for record in records] == source_y
    assert [layout["text"] for layout in layouts] == [record["text"] for record in records]
    assert {layout["column_count"] for layout in layouts} == {1}
    assert [layout["rect"].center().y() for layout in layouts] == source_y
    assert layouts[0]["rect"].intersects(layouts[1]["rect"])
    assert all(metrics.horizontalAdvance(layout["text"]) <= layout["rect"].width() for layout in layouts)
    assert [call.args[2] for call in painter.drawText.call_args_list] == [
        record["text"] for record in records
    ]


def test_lower_reference_text_layout_dense_impossible_falls_back_without_loss(case):
    window = window_for(case)
    install(window)
    axis = window.fixed_price_axis
    viewport_top = window.chart_scroll_area.viewport().geometry().top()
    pane = {"family": wm.FAMILY_RSI, "top": 0.0, "bottom": 40.0}
    records = [
        {
            "family": wm.FAMILY_RSI,
            "value": float(index),
            "y": viewport_top + 20.0,
            "sides": ("BUY",),
            "text": f"BUY {index}",
        }
        for index in range(5)
    ]
    metrics = Mock()
    metrics.height.return_value = 20
    metrics.horizontalAdvance.return_value = 40
    painter = Mock()
    painter.font.return_value = axis.font()

    with patch.object(window.canvas, "lower_pane_records", return_value=[pane]):
        layouts = axis._lower_reference_text_layout(metrics, records)
        with patch.object(wm, "QPainter", return_value=painter), patch.object(
            wm, "QFontMetrics", return_value=metrics,
        ), patch.object(axis, "price_axis_records", return_value=[]), patch.object(
            axis, "lower_reference_axis_records", return_value=records,
        ):
            axis.paintEvent(None)

    assert [layout["text"] for layout in layouts] == [record["text"] for record in records]
    assert [layout["rect"].center().y() for layout in layouts] == [
        record["y"] for record in records
    ]
    assert {layout["column_count"] for layout in layouts} == {1}
    assert [call.args[2] for call in painter.drawText.call_args_list] == [
        record["text"] for record in records
    ]


def test_fixed_price_axis_width_recomputes_only_for_font_change(case):
    window = window_for(case)
    install(window)
    axis = window.fixed_price_axis
    original_width = axis.width()
    font = QFont(axis.font())
    font.setPointSize(font.pointSize() + 3)
    axis.setFont(font)
    case.app.processEvents()
    expected_width = (
        QFontMetrics(font).horizontalAdvance(axis._FIXED_WIDTH_REFERENCE_PRICE)
        + axis._HORIZONTAL_PADDING * 2
    )
    assert axis.width() == expected_width
    assert axis.width() != original_width

    arbitrary_labels = [{
        "family": wm.FAMILY_OCR_OSC,
        "value": 1.0,
        "y": 1.0,
        "sides": ("BUY",),
        "text": "X" * 500,
    }]
    with patch.object(
        window.canvas,
        "lower_reference_axis_records",
        return_value=arbitrary_labels,
    ):
        axis.refresh_scale()
        case.app.processEvents()
    assert axis.width() == expected_width


def test_fixed_axis_and_candle_viewport_stay_fixed_during_view_changes(case):
    window = window_for(case)
    install(window)
    window.show()
    case.app.processEvents()
    axis = window.fixed_price_axis
    width = axis.width()
    origin = window.chart_scroll_area.viewport().mapTo(window, QPoint(0, 0)).x()

    axis.refresh_scale()
    case.app.processEvents()
    assert axis.width() == width
    assert window.chart_scroll_area.viewport().mapTo(window, QPoint(0, 0)).x() == origin

    window._set_time_view(100.0, 250.0)
    case.app.processEvents()
    assert axis.width() == width
    assert window.chart_scroll_area.viewport().mapTo(window, QPoint(0, 0)).x() == origin

    scale = window.canvas.price_scale()
    assert scale is not None
    window.canvas.set_price_view(scale.minimum + 10.0, scale.maximum + 10.0)
    axis.refresh_scale()
    case.app.processEvents()
    assert axis.width() == width
    assert window.chart_scroll_area.viewport().mapTo(window, QPoint(0, 0)).x() == origin


def test_price_legend_adds_lower_filter_text_without_price_identity():
    app = legacy.ensure_qapplication()
    descriptor = wm.ValidationFilterDescriptor(
        "lower", wm.FAMILY_RSI, "RSI", wm.LOWER_AXIS,
        ("BUY",), ("VALUE",), "{}", (),
    )
    canvas = wm.IndicatorFollowSignalValidationChartCanvas(
        [], [], visualization_descriptors=(descriptor,),
    )
    try:
        rows = canvas._price_legend_rows()
        assert [row[0] for row in rows] == ["BUY"]
        block, = rows[0][2]
        assert block["caption"] == "하단1 RSI(14)"
        assert block["legend_role"] == "LOWER_FILTER"
        assert block["lower_descriptor_identity"] == "lower"
        assert block["descriptor_identities"] == ("lower",)
        assert block["pens"] == ()
    finally:
        canvas.close()
        canvas.deleteLater()


def test_price_legend_wraps_long_segment_text_without_elision():
    app = legacy.ensure_qapplication()
    canvas = wm.IndicatorFollowSignalValidationChartCanvas([], [])
    try:
        metrics = QFontMetrics(canvas.font())
        labels = ("very-long-first-filter-label", "very-long-second-filter-label")
        layouts = canvas._layout_price_legend_blocks(
            [{"segments": tuple((label, QPen(Qt.black)) for label in labels)}],
            QRectF(0, 0, 72, metrics.height() + 2),
            canvas.font(),
        )
        rendered = "".join(
            label.replace(", ", "")
            for layout in layouts
            for label, _pen in layout["segments"]
        )
        assert rendered == "".join(labels)
        assert len({layout["rect"].top() for layout in layouts}) > 1
        assert all(layout["rect"].right() <= 72 for layout in layouts)
    finally:
        canvas.close()
        canvas.deleteLater()
        legacy.flush_deferred_deletes(app)
        legacy.flush_deferred_deletes(app)


def test_price_legend_separator_reserves_full_padded_prefix_across_wraps():
    app = legacy.ensure_qapplication()
    canvas = wm.IndicatorFollowSignalValidationChartCanvas([], [])
    blocks = [
        {"caption": "first", "pens": (), "emphasized": False},
        {"caption": "second", "pens": (), "emphasized": True},
        {"caption": "third-caption-wraps", "pens": (), "emphasized": False},
    ]
    try:
        for point_size in (8, 14):
            font = canvas.font()
            font.setPointSize(point_size)
            metrics = QFontMetrics(font)
            layouts = canvas._layout_price_legend_blocks(
                blocks,
                QRectF(0, 0, 100, metrics.height() + 2),
                font,
            )
            assert len({layout["rect"].top() for layout in layouts}) > 1
            allocated = []
            for layout in layouts:
                separator = layout["separator"]
                prefix_width = float(separator["full_width"]) if separator else 0.0
                prefix_left = layout["rect"].left() - prefix_width
                if separator is not None:
                    assert prefix_left <= separator["rect"].left()
                    assert separator["rect"].right() <= layout["rect"].left()
                allocated.append(QRectF(
                    prefix_left,
                    layout["rect"].top(),
                    prefix_width + layout["rect"].width(),
                    layout["rect"].height(),
                ))
            assert all(
                not first.intersects(second)
                for index, first in enumerate(allocated)
                for second in allocated[index + 1:]
            )
    finally:
        canvas.close()
        canvas.deleteLater()
        legacy.flush_deferred_deletes(app)
        legacy.flush_deferred_deletes(app)


def _draw_legend_block_text(canvas, block):
    class Painter:
        def __init__(self):
            self._font = QFont(canvas.font())
            self._pen = QPen(Qt.black)
            self._stack = []
            self.text = []
            self.lines = []

        def save(self):
            self._stack.append((QFont(self._font), QPen(self._pen)))

        def restore(self):
            self._font, self._pen = self._stack.pop()

        def font(self):
            return QFont(self._font)

        def setFont(self, font):
            self._font = QFont(font)

        def setPen(self, pen):
            self._pen = QPen(pen)

        def drawText(self, _rect, _flags, text):
            self.text.append((str(text), self._pen.color().getRgb()))

        def drawLine(self, *args):
            self.lines.append((args, self._pen.color().getRgb()))

    metrics = QFontMetrics(canvas.font())
    layouts = canvas._layout_price_legend_blocks(
        [block],
        QRectF(0, 0, 4096, metrics.height() + 2),
        canvas.font(),
    )
    painter = Painter()
    canvas._draw_price_legend_block_layout(painter, layouts)
    return layouts, painter.text, painter.lines


def test_shared_lower_bundle_emphasizes_and_hits_only_filter_fragments(case):
    ocr_threshold = _ocr_threshold_descriptor(
        "ocr-threshold", "SELL", "GREATER_THAN_OR_EQUAL", 0,
    )
    ocr_turn = _ocr_turn_descriptor("ocr-turn", "SELL", "TURN_DOWN")
    macd = wm.ValidationFilterDescriptor(
        "macd-threshold", wm.FAMILY_MACD_SIGNAL, "MACD", wm.LOWER_AXIS,
        ("SELL",), ("MACD", "SIGNAL", "CRITERION"),
        '{"fast":12,"slow":26,"signal":9,'
        '"condition":{"operator":"GTE","target":"MACD","threshold":0}}',
        (),
    )
    ocr_presentation = _ocr_filter_presentation(
        "SELL", ocr_threshold, ocr_turn,
    )
    macd_presentation = wm.ValidationLowerFilterPresentation(
        key="SELL:macd",
        side="SELL",
        source_path="sell.macd",
        filter_token="MACD",
        pane_family=wm.FAMILY_MACD_SIGNAL,
        display_order=(1,),
        descriptor_identities=(macd.identity,),
        component_descriptor_identities=(macd.identity,),
        component_labels=("MACD",),
    )
    values = tuple(float(index % 5 - 2) for index in range(40))
    cache = wm.ValidationIndicatorSeriesCache(40, (
        (ocr_threshold.identity, "OSC", values),
        (ocr_threshold.identity, "CRITERION", (0.0,) * 40),
        (ocr_turn.identity, "OSC", values),
        (macd.identity, "MACD", values),
        (macd.identity, "SIGNAL", values),
        (macd.identity, "CRITERION", (0.0,) * 40),
    ))
    canvas = wm.IndicatorFollowSignalValidationChartCanvas(
        candles(40), [],
        visualization_descriptors=(ocr_threshold, ocr_turn, macd),
        visualization_cache=cache,
        lower_filter_presentations=(ocr_presentation, macd_presentation),
    )
    case.widgets.append(canvas)
    canvas.set_not_filter_identities(
        {
            ("SELL", ocr_threshold.identity),
            ("SELL", ocr_turn.identity),
            ("SELL", macd.identity),
        },
        {("SELL", macd.identity)},
    )
    canvas.set_valid_filter_identities(
        {("SELL", ocr_threshold.identity)}, valid_mode_enabled=True,
    )

    block = next(
        block
        for side, _label, blocks in canvas._price_legend_rows()
        if side == "SELL"
        for block in blocks
        if block["legend_role"] == "LOWER_FILTER"
        and len(block["filter_text_spans"]) == 2
    )
    ocr_span, macd_span = block["filter_text_spans"]
    assert ocr_span[2] == (ocr_threshold.identity, ocr_turn.identity)
    assert macd_span[2] == (macd.identity,)
    assert block["emphasized_text_spans"] == (ocr_span[:2],)
    assert " | " in block["caption"]

    layouts, text, lines = _draw_legend_block_text(canvas, block)
    red = QColor(255, 95, 95, 160).getRgb()
    yellow = QColor(255, 215, 0, 220).getRgb()
    caption = block["caption"]
    assert "".join(value for value, _color in text) == caption
    assert "".join(value for value, color in text if color == red) == (
        caption[ocr_span[0]:ocr_span[1]]
    )
    assert "".join(value for value, color in text if color == yellow) == (
        caption[macd_span[0]:macd_span[1]]
    )
    assert all(color not in {red, yellow} for _line, color in lines)
    runs = [run for layout in layouts for run in layout["caption_runs"]]
    assert "".join(run["text"] for run in runs if run["font"].bold()) == (
        caption[ocr_span[0]:ocr_span[1]]
    )
    assert all(
        not run["font"].bold()
        for run in runs
        if run["start"] < macd_span[1] and run["end"] > macd_span[0]
    )
    assert sum(run["width"] for run in runs) == pytest.approx(
        layouts[0]["rect"].width()
    )

    canvas.resize(310, 420)
    canvas._price_legend_rows = lambda: [("SELL", "SELL :", [block])]
    scale = canvas.price_scale()
    assert scale is not None
    rows = canvas._price_legend_layout(scale, canvas.font())
    block_layouts = rows[0]["blocks"]
    assert len({layout["rect"].top() for layout in block_layouts}) > 1
    targets = [
        (rect, identities)
        for layout in block_layouts
        for rect, identities in layout["fragment_targets"]
    ]
    assert {identities for _rect, identities in targets} == {
        (ocr_threshold.identity, ocr_turn.identity),
        (macd.identity,),
    }
    for rect, identities in targets:
        assert canvas._price_legend_target_at(
            rect.center().x(), rect.center().y(),
        ) == ("SELL", identities)
    assert canvas._price_legend_target_at(
        rows[0]["prefix_rect"].center().x(),
        rows[0]["prefix_rect"].center().y(),
    ) == ("SELL", ())

    canvas.set_valid_filter_identities((), valid_mode_enabled=False)
    canvas._toggle_price_legend_identities(
        "SELL", (ocr_threshold.identity, ocr_turn.identity),
    )
    assert set(canvas.highlighted_lower_filter_identities) == {
        ("SELL", ocr_threshold.identity),
        ("SELL", ocr_turn.identity),
    }
    canvas._toggle_price_legend_identities("SELL", (macd.identity,))
    assert set(canvas.highlighted_lower_filter_identities) == {
        ("SELL", ocr_threshold.identity),
        ("SELL", ocr_turn.identity),
        ("SELL", macd.identity),
    }
    assert not canvas.hidden_price_filter_identities
    assert canvas._lower_visibility_filter_active()


@pytest.mark.parametrize(
    ("expression", "array_is_red"),
    (("A NOT C", True), ("A AND C", False)),
)
def test_sell_not_legend_colors_only_checked_array_condition_text(
    case, expression, array_is_red,
):
    window = window_for(case)
    window.sell_signal_expr_line.setText(expression)
    window.sell_signal_condition_c_gap_check.setChecked(False)
    window.sell_signal_condition_c_macd_check.setChecked(False)
    window.sell_signal_condition_c_array_check.setChecked(True)
    install(window)

    descriptors = {
        descriptor.identity: descriptor
        for descriptor in window.canvas._visualization_descriptors
    }
    sell_blocks = next(
        blocks
        for side, _label, blocks in window.canvas._price_legend_rows()
        if side == "SELL"
    )

    def block_for_family(family):
        return next(
            block
            for block in sell_blocks
            if any(
                descriptors[identity].family == family
                for identity in block["descriptor_identities"]
            )
        )

    red = QColor(255, 95, 95, 160).getRgb()
    array_block = block_for_family(wm.FAMILY_MA_ARRANGEMENT)
    _layouts, array_text, array_lines = _draw_legend_block_text(
        window.canvas, array_block,
    )
    assert array_text
    assert all((color == red) is array_is_red for _text, color in array_text)
    assert array_lines
    assert all(color != red for _line, color in array_lines)

    for unchecked_family in (wm.FAMILY_MACD_SIGNAL, wm.FAMILY_PRICE_COMPARISON):
        _layouts, text, _lines = _draw_legend_block_text(
            window.canvas, block_for_family(unchecked_family),
        )
        assert text
        assert all(color != red for _text, color in text)


def test_sell_not_lower_group_colors_only_not_fragment_without_geometry_change(case):
    window = window_for(case)
    window.sell_signal_expr_line.setText("A NOT C")
    window.sell_signal_condition_c_gap_check.setChecked(False)
    window.sell_signal_condition_c_macd_check.setChecked(True)
    window.sell_signal_condition_c_array_check.setChecked(False)
    install(window)

    canvas = window.canvas
    descriptor_by_identity = {
        descriptor.identity: descriptor
        for descriptor in canvas._visualization_descriptors
    }
    macd_presentation = next(
        presentation
        for presentation in canvas._lower_filter_presentations
        if presentation.side == "SELL" and presentation.filter_token == "MACD"
    )
    expected_red_text = canvas._lower_filter_presentation_caption(
        macd_presentation,
        descriptor_by_identity,
    )
    lower_block = next(
        block
        for side, _label, blocks in canvas._price_legend_rows()
        if side == "SELL"
        for block in blocks
        if (
            block["legend_role"] == "LOWER_FILTER"
            and set(macd_presentation.descriptor_identities).issubset(
                block["descriptor_identities"]
            )
        )
    )

    styled_layouts, text, _lines = _draw_legend_block_text(canvas, lower_block)
    red = QColor(255, 95, 95, 160).getRgb()
    assert "".join(value for value, _color in text) == lower_block["caption"]
    assert "".join(value for value, color in text if color == red) == expected_red_text
    assert any(" | " in value for value, color in text if color != red)
    assert all(
        not value.startswith("[") and "MACD(12,26,9) :" not in value
        for value, color in text
        if color == red
    )

    ordinary_block = dict(lower_block)
    ordinary_block.pop("not_text_spans", None)
    ordinary_layouts, _text, _lines = _draw_legend_block_text(
        canvas, ordinary_block,
    )
    assert [layout["rect"] for layout in styled_layouts] == [
        layout["rect"] for layout in ordinary_layouts
    ]
    target_identities = tuple(dict.fromkeys(
        macd_presentation.component_descriptor_identities
    ))
    scale = canvas.price_scale()
    assert scale is not None
    actual_layouts = [
        layout
        for row in canvas._price_legend_layout(scale, canvas.font())
        if row["side"] == "SELL"
        for layout in row["blocks"]
        if (
            layout["block"]["caption"] == lower_block["caption"]
            and layout["block"]["descriptor_identities"]
            == lower_block["descriptor_identities"]
        )
    ]
    assert actual_layouts
    target_rects = [
        fragment_rect
        for layout in actual_layouts
        for fragment_rect, identities in layout["fragment_targets"]
        if identities == target_identities
    ]
    assert target_rects
    assert all(
        canvas._price_legend_target_at(
            rect.center().x(), rect.center().y(),
        ) == ("SELL", target_identities)
        for rect in target_rects
    )


@pytest.mark.parametrize(
    ("gap_logic", "macd_is_yellow"),
    (("NOT", True), ("AND", False)),
)
def test_sell_group_not_colors_only_rhs_macd_fragment(
    case, gap_logic, macd_is_yellow,
):
    window = window_for(case)
    window.sell_signal_expr_line.setText("A AND C")
    window.sell_signal_condition_c_gap_check.setChecked(True)
    window.sell_signal_condition_c_gap_logic_combo.setCurrentText(gap_logic)
    window.sell_signal_condition_c_macd_check.setChecked(True)
    window.sell_signal_condition_c_macd_logic_combo.setCurrentText("AND")
    window.sell_signal_condition_c_array_check.setChecked(False)
    install(window)

    ui_state = window.collect_indicator_follow_ui_state()
    source_rules = deepcopy(window._signal_validation_seed.settings_snapshot.to_dict())
    source_rules["sell"]["signals"] = {}
    preview = (
        window._load_indicator_follow_rule_mapper()
        .build_engine_rules_preview_from_ui_state(ui_state, source_rules)
    )
    actual_rules = wm.project_signal_validation_rules(preview["preview_rules"])
    groups = [
        group
        for signal in actual_rules["sell"]["signals"].values()
        for group in signal.get("groups", ())
        if {
            condition.get("expression_id")
            for condition in group.get("conditions", ())
        } == {"GAP_0", "MACD_0"}
    ]
    assert len(groups) == 1
    group = groups[0]
    assert group["condition_expression"] == {
        "type": "binary",
        "operator": gap_logic,
        "left": {"type": "identifier", "name": "GAP_0"},
        "right": {"type": "identifier", "name": "MACD_0"},
    }

    conditions = {
        condition["expression_id"]: condition
        for condition in group["conditions"]
    }
    macd_key = wm.canonical_validation_condition_key(conditions["MACD_0"])
    gap_key = wm.canonical_validation_condition_key(conditions["GAP_0"])
    descriptors = window.canvas._visualization_descriptors
    macd_descriptor = next(
        descriptor
        for descriptor in descriptors
        if descriptor.family == wm.FAMILY_MACD_SIGNAL
        and "SELL" in descriptor.sides
        and macd_key in descriptor.evidence_keys
    )
    gap_descriptor = next(
        descriptor
        for descriptor in descriptors
        if descriptor.family == wm.FAMILY_PRICE_COMPARISON
        and "SELL" in descriptor.sides
        and gap_key in descriptor.evidence_keys
    )
    not_identities = window._not_filter_identities
    inner_not_identities = window._inner_not_filter_identities
    assert (("SELL", macd_descriptor.identity) in not_identities) is macd_is_yellow
    assert (
        ("SELL", macd_descriptor.identity) in inner_not_identities
    ) is macd_is_yellow
    assert ("SELL", gap_descriptor.identity) not in not_identities
    assert ("SELL", gap_descriptor.identity) not in inner_not_identities
    assert not any(side == "BUY" for side, _identity in not_identities)

    canvas = window.canvas
    descriptor_by_identity = {
        descriptor.identity: descriptor
        for descriptor in descriptors
    }
    macd_presentation = next(
        presentation
        for presentation in canvas._lower_filter_presentations
        if presentation.side == "SELL"
        and macd_descriptor.identity in presentation.descriptor_identities
    )
    macd_text = canvas._lower_filter_presentation_caption(
        macd_presentation,
        descriptor_by_identity,
    )
    lower_block = next(
        block
        for side, _label, blocks in canvas._price_legend_rows()
        if side == "SELL"
        for block in blocks
        if block["legend_role"] == "LOWER_FILTER"
        and macd_descriptor.identity in block["descriptor_identities"]
    )
    styled_layouts, text, _lines = _draw_legend_block_text(canvas, lower_block)
    red = QColor(255, 95, 95, 160).getRgb()
    yellow = QColor(255, 215, 0, 220).getRgb()
    assert "".join(value for value, _color in text) == lower_block["caption"]
    assert "".join(value for value, color in text if color == yellow) == (
        macd_text if macd_is_yellow else ""
    )
    assert not any(color == red for _value, color in text)
    assert any(
        " | " in value
        for value, color in text
        if color not in {red, yellow}
    )
    assert all(
        not value.startswith("[") and "MACD(12,26,9) :" not in value
        for value, color in text
        if color == yellow
    )

    ordinary_block = dict(lower_block)
    ordinary_block.pop("not_text_spans", None)
    ordinary_block.pop("inner_not_text_spans", None)
    ordinary_layouts, _text, _lines = _draw_legend_block_text(
        canvas, ordinary_block,
    )
    assert [layout["rect"] for layout in styled_layouts] == [
        layout["rect"] for layout in ordinary_layouts
    ]


def test_sell_group_not_keeps_shared_single_condition_mapping_neutral(case):
    window = window_for(case)
    window.sell_signal_expr_line.setText("A AND C")
    window.sell_signal_condition_c_gap_check.setChecked(True)
    window.sell_signal_condition_c_gap_logic_combo.setCurrentText("NOT")
    window.sell_signal_condition_c_macd_check.setChecked(True)
    window.sell_signal_condition_c_macd_logic_combo.setCurrentText("AND")
    window.sell_signal_condition_c_array_check.setChecked(False)
    install(window)

    ui_state = window.collect_indicator_follow_ui_state()
    source_rules = deepcopy(window._signal_validation_seed.settings_snapshot.to_dict())
    source_rules["sell"]["signals"] = {}
    preview = (
        window._load_indicator_follow_rule_mapper()
        .build_engine_rules_preview_from_ui_state(ui_state, source_rules)
    )
    actual_rules = wm.project_signal_validation_rules(preview["preview_rules"])
    inner_group = next(
        group
        for signal in actual_rules["sell"]["signals"].values()
        for group in signal.get("groups", ())
        if {
            condition.get("expression_id")
            for condition in group.get("conditions", ())
        } == {"GAP_0", "MACD_0"}
    )
    macd_condition = next(
        condition
        for condition in inner_group["conditions"]
        if condition.get("expression_id") == "MACD_0"
    )
    actual_rules["sell"]["signals"]["ordinary_single_macd"] = {
        "enabled": True,
        "groups": [{
            "enabled": True,
            "conditions": [deepcopy(macd_condition)],
        }],
    }
    macd_key = wm.canonical_validation_condition_key(macd_condition)
    macd_descriptor = next(
        descriptor
        for descriptor in window.canvas._visualization_descriptors
        if descriptor.family == wm.FAMILY_MACD_SIGNAL
        and "SELL" in descriptor.sides
        and macd_key in descriptor.evidence_keys
    )
    mapper = Mock()
    mapper.build_engine_rules_preview_from_ui_state.return_value = {
        "preview_rules": {},
    }
    with (
        patch.object(window, "_load_indicator_follow_rule_mapper", return_value=mapper),
        patch.object(wm, "project_signal_validation_rules", return_value=actual_rules),
    ):
        not_identities, inner_not_identities = (
            window._current_not_filter_identities(
                window._signal_validation_seed.settings_snapshot.to_dict(),
                window.canvas._visualization_descriptors,
            )
        )

    assert ("SELL", macd_descriptor.identity) not in inner_not_identities
    assert ("SELL", macd_descriptor.identity) not in not_identities


def test_sell_double_not_keeps_outer_red_and_inner_yellow_geometry(case):
    window = window_for(case)
    window.sell_signal_expr_line.setText("A NOT C")
    window.sell_signal_condition_a_ocr_check.setChecked(False)
    window.sell_signal_condition_a_gap_check.setChecked(False)
    window.sell_signal_condition_a_rsi_check.setChecked(True)
    window.sell_signal_condition_b_price_box_check.setChecked(False)
    window.sell_signal_condition_b_bollinger_check.setChecked(False)
    window.sell_signal_condition_b_gap_check.setChecked(False)
    window.sell_signal_condition_c_gap_check.setChecked(True)
    window.sell_signal_condition_c_gap_logic_combo.setCurrentText("NOT")
    window.sell_signal_condition_c_macd_check.setChecked(True)
    window.sell_signal_condition_c_macd_logic_combo.setCurrentText("AND")
    window.sell_signal_condition_c_array_check.setChecked(False)
    install(window)

    canvas = window.canvas
    ui_state = window.collect_indicator_follow_ui_state()
    source_rules = deepcopy(window._signal_validation_seed.settings_snapshot.to_dict())
    source_rules["sell"]["signals"] = {}
    preview = (
        window._load_indicator_follow_rule_mapper()
        .build_engine_rules_preview_from_ui_state(ui_state, source_rules)
    )
    actual_rules = wm.project_signal_validation_rules(preview["preview_rules"])
    group = next(
        group
        for signal in actual_rules["sell"]["signals"].values()
        for group in signal.get("groups", ())
        if {
            condition.get("expression_id")
            for condition in group.get("conditions", ())
        } == {"GAP_0", "MACD_0"}
    )
    assert group["condition_expression"] == {
        "type": "binary",
        "operator": "NOT",
        "left": {"type": "identifier", "name": "GAP_0"},
        "right": {"type": "identifier", "name": "MACD_0"},
    }
    conditions = {
        condition["expression_id"]: condition
        for condition in group["conditions"]
    }
    gap_key = wm.canonical_validation_condition_key(conditions["GAP_0"])
    macd_key = wm.canonical_validation_condition_key(conditions["MACD_0"])
    descriptors = canvas._visualization_descriptors
    gap_descriptor = next(
        descriptor
        for descriptor in descriptors
        if descriptor.family == wm.FAMILY_PRICE_COMPARISON
        and "SELL" in descriptor.sides
        and gap_key in descriptor.evidence_keys
    )
    macd_descriptor = next(
        descriptor
        for descriptor in descriptors
        if descriptor.family == wm.FAMILY_MACD_SIGNAL
        and "SELL" in descriptor.sides
        and macd_key in descriptor.evidence_keys
    )
    assert ("SELL", gap_descriptor.identity) in window._not_filter_identities
    assert ("SELL", macd_descriptor.identity) in window._not_filter_identities
    assert ("SELL", gap_descriptor.identity) not in window._inner_not_filter_identities
    assert ("SELL", macd_descriptor.identity) in window._inner_not_filter_identities

    descriptor_by_identity = {
        descriptor.identity: descriptor
        for descriptor in descriptors
    }
    rsi_presentation = next(
        presentation
        for presentation in canvas._lower_filter_presentations
        if presentation.side == "SELL" and presentation.filter_token == "RSI"
    )
    macd_presentation = next(
        presentation
        for presentation in canvas._lower_filter_presentations
        if presentation.side == "SELL"
        and macd_descriptor.identity in presentation.descriptor_identities
    )
    rsi_text = canvas._lower_filter_presentation_caption(
        rsi_presentation, descriptor_by_identity,
    )
    macd_text = canvas._lower_filter_presentation_caption(
        macd_presentation, descriptor_by_identity,
    )
    sell_blocks = next(
        blocks
        for side, _label, blocks in canvas._price_legend_rows()
        if side == "SELL"
    )
    lower_block = next(
        block
        for block in sell_blocks
        if block["legend_role"] == "LOWER_FILTER"
        and macd_descriptor.identity in block["descriptor_identities"]
    )
    rsi_block = next(
        block
        for block in sell_blocks
        if block["legend_role"] == "LOWER_FILTER"
        and set(rsi_presentation.descriptor_identities).issubset(
            block["descriptor_identities"]
        )
    )
    gap_block = next(
        block
        for block in sell_blocks
        if gap_descriptor.identity in block["descriptor_identities"]
    )

    red = QColor(255, 95, 95, 160).getRgb()
    yellow = QColor(255, 215, 0, 220).getRgb()
    lower_layouts, lower_text, lower_lines = _draw_legend_block_text(
        canvas, lower_block,
    )
    assert "".join(value for value, _color in lower_text) == lower_block["caption"]
    assert "".join(value for value, color in lower_text if color == yellow) == macd_text
    assert not any(color == red for _value, color in lower_text)
    assert any(
        value.startswith("[") or "MACD(12,26,9) :" in value
        for value, color in lower_text
        if color not in {red, yellow}
    )
    assert all(color not in {red, yellow} for _line, color in lower_lines)

    rsi_layouts, rsi_drawn_text, rsi_lines = _draw_legend_block_text(
        canvas, rsi_block,
    )
    assert rsi_text in "".join(value for value, _color in rsi_drawn_text)
    assert all(
        color not in {red, yellow}
        for _value, color in rsi_drawn_text
    )
    assert all(color not in {red, yellow} for _line, color in rsi_lines)

    gap_layouts, gap_text, gap_lines = _draw_legend_block_text(canvas, gap_block)
    assert gap_text
    assert all(color == red for _value, color in gap_text)
    assert all(color not in {red, yellow} for _line, color in gap_lines)

    ordinary_lower = dict(lower_block)
    ordinary_lower.pop("not_text_spans", None)
    ordinary_lower.pop("inner_not_text_spans", None)
    ordinary_lower_layouts, _text, _lines = _draw_legend_block_text(
        canvas, ordinary_lower,
    )
    ordinary_gap = dict(gap_block)
    ordinary_gap.pop("not_text_spans", None)
    ordinary_gap.pop("inner_not_text_spans", None)
    ordinary_gap_layouts, _text, _lines = _draw_legend_block_text(
        canvas, ordinary_gap,
    )
    ordinary_rsi = dict(rsi_block)
    ordinary_rsi.pop("not_text_spans", None)
    ordinary_rsi.pop("inner_not_text_spans", None)
    ordinary_rsi_layouts, _text, _lines = _draw_legend_block_text(
        canvas, ordinary_rsi,
    )
    assert [layout["rect"] for layout in lower_layouts] == [
        layout["rect"] for layout in ordinary_lower_layouts
    ]
    assert [layout["rect"] for layout in gap_layouts] == [
        layout["rect"] for layout in ordinary_gap_layouts
    ]
    assert [layout["rect"] for layout in rsi_layouts] == [
        layout["rect"] for layout in ordinary_rsi_layouts
    ]

    scale = canvas.price_scale()
    assert scale is not None
    fragment_targets = {
        (
            layout["block"]["caption"],
            tuple(identities),
            canvas._price_legend_target_at(
                rect.center().x(), rect.center().y(),
            ),
        )
        for row in canvas._price_legend_layout(scale, canvas.font())
        if row["side"] == "SELL"
        for layout in row["blocks"]
        for rect, identities in layout["fragment_targets"]
        if layout["block"]["caption"] in {
            lower_block["caption"], rsi_block["caption"],
        }
    }
    macd_ids = tuple(dict.fromkeys(
        macd_presentation.component_descriptor_identities
    ))
    rsi_ids = tuple(dict.fromkeys(
        rsi_presentation.component_descriptor_identities
    ))
    assert (
        lower_block["caption"],
        macd_ids,
        ("SELL", macd_ids),
    ) in fragment_targets
    assert (
        rsi_block["caption"],
        rsi_ids,
        ("SELL", rsi_ids),
    ) in fragment_targets
    gap_layout = next(
        layout
        for row in canvas._price_legend_layout(scale, canvas.font())
        if row["side"] == "SELL"
        for layout in row["blocks"]
        if layout["block"]["caption"] == gap_block["caption"]
    )
    assert canvas._price_legend_target_at(
        gap_layout["rect"].center().x(), gap_layout["rect"].center().y(),
    ) == ("SELL", tuple(gap_block["descriptor_identities"]))


def test_price_legend_bold_korean_buy_sell_captions_use_drawn_font_geometry():
    """The offscreen painter and legend hitboxes share the bold text geometry."""
    app = legacy.ensure_qapplication()
    canvas = wm.IndicatorFollowSignalValidationChartCanvas(candles(40), [])
    buy_captions = (
        "MACD OCR 상향 전환과 평단가 대비 현재가 조건을 모두 만족하는 긴 매수 필터 설명",
        "MACD OCR 상향 전환 뒤 이동평균 배열과 거래량 조건을 모두 확인하는 긴 매수 필터 설명",
    )
    sell_captions = (
        "MACD OCR 상향 전환 이후 평단가 대비 수익률 조건을 모두 만족하는 긴 매도 필터 설명",
        "MACD OCR 상향 전환 뒤 평균 매수가 대비 손절 기준을 모두 확인하는 긴 매도 필터 설명",
    )
    rows = [
        ("BUY", "매수 :", [{
            "caption": buy_captions[0],
            "pens": (QPen(Qt.green),),
            "emphasized": True,
            "descriptor_identities": ("buy-korean-1",),
        }, {
            "caption": buy_captions[1],
            "pens": (QPen(Qt.green),),
            "emphasized": True,
            "descriptor_identities": ("buy-korean-2",),
        }]),
        ("SELL", "매도 :", [{
            "caption": sell_captions[0],
            "pens": (QPen(Qt.red),),
            "emphasized": True,
            "descriptor_identities": ("sell-korean-1",),
        }, {
            "caption": sell_captions[1],
            "pens": (QPen(Qt.red),),
            "emphasized": True,
            "descriptor_identities": ("sell-korean-2",),
        }]),
    ]
    try:
        canvas.resize(520, 420)
        canvas._price_legend_rows = lambda: rows
        scale = canvas.price_scale()
        assert scale is not None
        layouts = canvas._price_legend_layout(scale, canvas.font())
        image = QImage(canvas.size(), QImage.Format_ARGB32_Premultiplied)
        image.fill(Qt.transparent)
        painter = QPainter(image)
        try:
            canvas._draw_price_overlay_legend(painter, scale)
        finally:
            painter.end()

        expected = {"BUY": buy_captions, "SELL": sell_captions}
        right = float(canvas.plot_left + canvas._plot_width() - 4)
        rects = []
        for row in layouts:
            rendered = tuple(
                "".join(
                    layout["caption_text"]
                    for layout in row["blocks"]
                    if layout["block"] is block
                )
                for block in rows[0 if row["side"] == "BUY" else 1][2]
            )
            assert rendered == expected[row["side"]]
            for layout in row["blocks"]:
                assert layout["font"].bold()
                block_font = canvas.font()
                block_font.setBold(bool(layout["block"].get("emphasized")))
                drawn_width = (
                    len(layout["pens"]) * 16.0
                    + QFontMetrics(block_font).horizontalAdvance(
                        layout["caption_text"]
                    )
                )
                assert drawn_width <= layout["rect"].width()
                assert layout["rect"].right() <= right
                if layout["separator"] is not None:
                    assert layout["separator"]["rect"].right() <= layout["rect"].left()
                assert canvas._price_legend_target_at(
                    layout["rect"].center().x(), layout["rect"].center().y(),
                ) == (row["side"], tuple(layout["block"]["descriptor_identities"]))
                rects.append(layout["rect"])
        assert all(
            not first.intersects(second)
            for index, first in enumerate(rects)
            for second in rects[index + 1:]
        )
        assert scale.plot_top >= max(rect.bottom() for rect in rects)
        assert any(image.pixelColor(x, y).alpha() for x in range(image.width()) for y in range(image.height()))
    finally:
        canvas.close()
        canvas.deleteLater()
        legacy.flush_deferred_deletes(app)


def test_price_legend_multi_highlight_adds_and_removes_individual_keys():
    app = legacy.ensure_qapplication()
    canvas = wm.IndicatorFollowSignalValidationChartCanvas([], [])
    try:
        canvas._toggle_price_legend_identities("BUY", ("one",))
        canvas._toggle_price_legend_identities("BUY", ("two",))
        assert set(canvas.highlighted_price_filter_identities) == {
            ("BUY", "one"), ("BUY", "two"),
        }
        assert canvas.hide_unhighlighted_price_filters
        assert not canvas.hidden_price_filter_identities
        canvas._toggle_price_legend_identities("BUY", ("one",))
        assert set(canvas.highlighted_price_filter_identities) == {
            ("BUY", "two"),
        }
        assert canvas.hide_unhighlighted_price_filters
        canvas._toggle_price_legend_identities("BUY", ("two",))
        assert not canvas.highlighted_price_filter_identities
        assert not canvas.hide_unhighlighted_price_filters
    finally:
        canvas.close()
        canvas.deleteLater()
        legacy.flush_deferred_deletes(app)


def test_valid_mode_filters_price_and_lower_globally_and_zero_valid_hides_all():
    app = legacy.ensure_qapplication()
    first = wm.ValidationFilterDescriptor(
        "ma-first", wm.FAMILY_MOVING_AVERAGE, "MA", wm.PRICE_AXIS,
        ("BUY",), ("MA5",), "{}", (),
    )
    second = wm.ValidationFilterDescriptor(
        "ma-second", wm.FAMILY_MOVING_AVERAGE, "MA", wm.PRICE_AXIS,
        ("BUY",), ("MA10",), "{}", (),
    )
    rsi = wm.ValidationFilterDescriptor(
        "rsi-buy", wm.FAMILY_RSI, "RSI", wm.LOWER_AXIS,
        ("BUY",), ("RSI", "CRITERION_LOWER"), "{}", (),
    )
    ocr = wm.ValidationFilterDescriptor(
        "ocr-sell", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("SELL",), ("OSC", "CRITERION"),
        '{"condition":{"operator":"LTE","target":"OSC","threshold":0}}',
        (),
    )
    canvas = wm.IndicatorFollowSignalValidationChartCanvas(
        candles(4), [], visualization_descriptors=(first, second, rsi, ocr),
        visualization_cache=wm.ValidationIndicatorSeriesCache(4, (
            (first.identity, "MA5", (10.0, 11.0, 12.0, 13.0)),
            (second.identity, "MA10", (20.0, 21.0, 22.0, 23.0)),
            (rsi.identity, "RSI", (40.0, 45.0, 50.0, 55.0)),
            (rsi.identity, "CRITERION_LOWER", (30.0,) * 4),
            (ocr.identity, "OSC", (-2.0, -1.0, 1.0, 2.0)),
            (ocr.identity, "CRITERION", (0.0,) * 4),
        )),
    )
    try:
        lower_groups = {
            family: {
                channel: owners
                for channel, _values, owners in groups
            }
            for family, groups in canvas._lower_series_groups.items()
        }
        canvas.set_valid_filter_identities(
            {("BUY", first.identity), ("SELL", ocr.identity)},
            valid_mode_enabled=True,
        )
        assert set(canvas.hidden_price_filter_identities) == {second.identity}
        assert {
            descriptor.identity
            for _channel, _values, owners in canvas._price_series_groups
            for descriptor in owners
        } == {first.identity}
        assert not canvas._visible_lower_series_owners(
            "RSI", lower_groups[wm.FAMILY_RSI]["RSI"],
        )
        assert not canvas._visible_lower_series_owners(
            "CRITERION_LOWER",
            lower_groups[wm.FAMILY_RSI]["CRITERION_LOWER"],
        )
        assert {
            descriptor.identity
            for descriptor in canvas._visible_lower_series_owners(
                "OSC", lower_groups[wm.FAMILY_OCR_OSC]["OSC"],
            )
        } == {ocr.identity}
        assert canvas._visible_lower_series_owners(
            "CRITERION", lower_groups[wm.FAMILY_OCR_OSC]["CRITERION"],
        ) == lower_groups[wm.FAMILY_OCR_OSC]["CRITERION"]

        canvas.set_valid_filter_identities((), valid_mode_enabled=True)
        assert set(canvas.hidden_price_filter_identities) == {
            first.identity, second.identity,
        }
        assert not canvas._price_series_groups
        assert not canvas._visible_lower_series_owners(
            "OSC", lower_groups[wm.FAMILY_OCR_OSC]["OSC"],
        )

        canvas.set_valid_filter_identities((), valid_mode_enabled=False)
        assert not canvas.hidden_price_filter_identities
        assert {
            descriptor.identity
            for _channel, _values, owners in canvas._price_series_groups
            for descriptor in owners
        } == {first.identity, second.identity}
        assert canvas._visible_lower_series_owners(
            "RSI", lower_groups[wm.FAMILY_RSI]["RSI"],
        ) == lower_groups[wm.FAMILY_RSI]["RSI"]
        assert canvas._visible_lower_series_owners(
            "OSC", lower_groups[wm.FAMILY_OCR_OSC]["OSC"],
        ) == lower_groups[wm.FAMILY_OCR_OSC]["OSC"]
        assert canvas._visible_lower_series_owners(
            "CRITERION_LOWER",
            lower_groups[wm.FAMILY_RSI]["CRITERION_LOWER"],
        ) == lower_groups[wm.FAMILY_RSI]["CRITERION_LOWER"]
    finally:
        canvas.close()
        canvas.deleteLater()
        legacy.flush_deferred_deletes(app)


def test_manual_filter_selection_is_global_across_price_and_lower_axes():
    app = legacy.ensure_qapplication()
    price_buy = wm.ValidationFilterDescriptor(
        "price-buy", wm.FAMILY_MOVING_AVERAGE, "MA", wm.PRICE_AXIS,
        ("BUY",), ("MA5",), "{}", (),
    )
    price_sell = wm.ValidationFilterDescriptor(
        "price-sell", wm.FAMILY_MOVING_AVERAGE, "MA", wm.PRICE_AXIS,
        ("SELL",), ("MA10",), "{}", (),
    )
    rsi_buy = wm.ValidationFilterDescriptor(
        "rsi-buy", wm.FAMILY_RSI, "RSI", wm.LOWER_AXIS,
        ("BUY",), ("RSI", "CRITERION_LOWER"), "{}", (),
    )
    ocr_sell = wm.ValidationFilterDescriptor(
        "ocr-sell", wm.FAMILY_OCR_OSC, "OCR", wm.LOWER_AXIS,
        ("SELL",), ("OSC", "CRITERION"),
        '{"condition":{"operator":"LTE","target":"OSC","threshold":0}}',
        (),
    )
    canvas = wm.IndicatorFollowSignalValidationChartCanvas(
        candles(4), [], visualization_descriptors=(
            price_buy, price_sell, rsi_buy, ocr_sell,
        ), visualization_cache=wm.ValidationIndicatorSeriesCache(4, (
            (price_buy.identity, "MA5", (10.0, 11.0, 12.0, 13.0)),
            (price_sell.identity, "MA10", (20.0, 21.0, 22.0, 23.0)),
            (rsi_buy.identity, "RSI", (40.0, 45.0, 55.0, 60.0)),
            (rsi_buy.identity, "CRITERION_LOWER", (30.0,) * 4),
            (ocr_sell.identity, "OSC", (-2.0, -1.0, 1.0, 2.0)),
            (ocr_sell.identity, "CRITERION", (0.0,) * 4),
        )),
    )
    try:
        rsi_groups = dict(
            (channel, owners)
            for channel, _values, owners
            in canvas._lower_series_groups[wm.FAMILY_RSI]
        )
        ocr_groups = dict(
            (channel, owners)
            for channel, _values, owners
            in canvas._lower_series_groups[wm.FAMILY_OCR_OSC]
        )

        canvas._toggle_price_legend_identities("BUY", (rsi_buy.identity,))
        assert set(canvas.hidden_price_filter_identities) == {
            price_buy.identity, price_sell.identity,
        }
        assert not canvas._price_series_groups
        assert canvas._visible_lower_series_owners(
            "RSI", rsi_groups["RSI"],
        ) == rsi_groups["RSI"]
        assert canvas._visible_lower_series_owners(
            "CRITERION_LOWER", rsi_groups["CRITERION_LOWER"],
        ) == rsi_groups["CRITERION_LOWER"]
        assert not canvas._visible_lower_series_owners(
            "OSC", ocr_groups["OSC"],
        )
        assert not canvas._visible_lower_series_owners(
            "CRITERION", ocr_groups["CRITERION"],
        )
        assert {
            descriptor.identity
            for descriptor in canvas._lower_histogram_evidence_owners(
                wm.FAMILY_OCR_OSC, (),
            )
        } == {ocr_sell.identity}

        canvas._toggle_price_legend_identities("SELL", (price_sell.identity,))
        assert set(canvas.hidden_price_filter_identities) == {price_buy.identity}
        assert {
            descriptor.identity
            for _channel, _values, owners in canvas._price_series_groups
            for descriptor in owners
        } == {price_sell.identity}
        assert canvas._visible_lower_series_owners(
            "RSI", rsi_groups["RSI"],
        ) == rsi_groups["RSI"]

        canvas.reset_price_legend_visibility()
        assert not canvas.hidden_price_filter_identities
        assert not canvas.highlighted_price_filter_identities
        assert not canvas.highlighted_lower_filter_identities
        assert canvas._visible_lower_series_owners(
            "OSC", ocr_groups["OSC"],
        ) == ocr_groups["OSC"]

        canvas._toggle_price_legend_identities("BUY", (price_buy.identity,))
        assert not canvas._visible_lower_series_owners(
            "RSI", rsi_groups["RSI"],
        )
        assert not canvas._visible_lower_series_owners(
            "CRITERION_LOWER", rsi_groups["CRITERION_LOWER"],
        )
        canvas._toggle_price_legend_identities("BUY", (price_buy.identity,))
        assert canvas._visible_lower_series_owners(
            "RSI", rsi_groups["RSI"],
        ) == rsi_groups["RSI"]
    finally:
        canvas.close()
        canvas.deleteLater()
        legacy.flush_deferred_deletes(app)


def test_lower_selection_uses_required_channels_and_shared_owner_union():
    app = legacy.ensure_qapplication()
    macd = wm.ValidationFilterDescriptor(
        "macd-target", wm.FAMILY_MACD_SIGNAL, "MACD", wm.LOWER_AXIS,
        ("BUY",), ("MACD", "SIGNAL", "CRITERION"),
        '{"condition":{"operator":"GTE","target":"MACD","threshold":0}}',
        (),
    )
    signal = wm.ValidationFilterDescriptor(
        "signal-target", wm.FAMILY_MACD_SIGNAL, "MACD", wm.LOWER_AXIS,
        ("SELL",), ("MACD", "SIGNAL", "CRITERION"),
        '{"condition":{"operator":"LTE","target":"SIGNAL","threshold":0}}',
        (),
    )
    values = (-2.0, -1.0, 1.0, 2.0)
    canvas = wm.IndicatorFollowSignalValidationChartCanvas(
        candles(4), [], visualization_descriptors=(macd, signal),
        visualization_cache=wm.ValidationIndicatorSeriesCache(4, (
            (macd.identity, "MACD", values),
            (macd.identity, "SIGNAL", values),
            (macd.identity, "CRITERION", (0.0,) * 4),
            (signal.identity, "MACD", values),
            (signal.identity, "SIGNAL", values),
            (signal.identity, "CRITERION", (1.0,) * 4),
        )),
    )
    try:
        groups = {
            channel: owners
            for channel, _values, owners
            in canvas._lower_series_groups[wm.FAMILY_OCR_OSC]
            if channel in {"MACD", "SIGNAL"}
        }
        canvas._toggle_price_legend_identities("BUY", (macd.identity,))
        assert {
            descriptor.identity
            for descriptor in canvas._visible_lower_series_owners(
                "MACD", groups["MACD"],
            )
        } == {macd.identity}
        assert not canvas._visible_lower_series_owners(
            "SIGNAL", groups["SIGNAL"],
        )

        canvas._toggle_price_legend_identities("SELL", (signal.identity,))
        assert {
            descriptor.identity
            for descriptor in canvas._visible_lower_series_owners(
                "MACD", groups["MACD"],
            )
        } == {macd.identity}
        assert {
            descriptor.identity
            for descriptor in canvas._visible_lower_series_owners(
                "SIGNAL", groups["SIGNAL"],
            )
        } == {signal.identity}
    finally:
        canvas.close()
        canvas.deleteLater()
        legacy.flush_deferred_deletes(app)


def test_projection_prunes_missing_global_selection_and_restores_baseline():
    app = legacy.ensure_qapplication()
    price = wm.ValidationFilterDescriptor(
        "price", wm.FAMILY_MOVING_AVERAGE, "MA", wm.PRICE_AXIS,
        ("BUY",), ("MA5",), "{}", (),
    )
    lower = wm.ValidationFilterDescriptor(
        "lower", wm.FAMILY_RSI, "RSI", wm.LOWER_AXIS,
        ("SELL",), ("RSI",), "{}", (),
    )
    replacement = replace(price, identity="replacement")
    values = (10.0, 11.0, 12.0, 13.0)
    canvas = wm.IndicatorFollowSignalValidationChartCanvas(
        candles(4), [], visualization_descriptors=(price, lower),
        visualization_cache=wm.ValidationIndicatorSeriesCache(4, (
            (price.identity, "MA5", values),
            (lower.identity, "RSI", values),
        )),
    )
    try:
        canvas._toggle_price_legend_identities("SELL", (lower.identity,))
        assert set(canvas.hidden_price_filter_identities) == {price.identity}

        canvas.set_visualization_projection(
            (replacement,),
            wm.ValidationIndicatorSeriesCache(4, (
                (replacement.identity, "MA5", values),
            )),
            {},
            [],
        )
        assert not canvas.highlighted_lower_filter_identities
        assert not canvas.hide_unhighlighted_price_filters
        assert not canvas.hidden_price_filter_identities
        assert {
            descriptor.identity
            for _channel, _values, owners in canvas._price_series_groups
            for descriptor in owners
        } == {replacement.identity}
    finally:
        canvas.close()
        canvas.deleteLater()
        legacy.flush_deferred_deletes(app)


def test_valid_checkbox_preserves_manual_selection_then_prefix_reset_returns_default(case):
    window = window_for(case)
    install(window)
    price = next(
        descriptor for descriptor in window.visualization_descriptors
        if descriptor.axis == wm.PRICE_AXIS
    )
    lower = next(
        descriptor for descriptor in window.visualization_descriptors
        if descriptor.axis == wm.LOWER_AXIS
    )
    price_side = next(iter(price.sides))
    lower_side = next(iter(lower.sides))
    valid_identities = {
        (str(price_side).upper(), price.identity),
        (str(lower_side).upper(), lower.identity),
    }

    window.canvas._toggle_price_legend_identities(
        lower_side, (lower.identity,),
    )
    manual_lower = window.canvas.highlighted_lower_filter_identities
    assert manual_lower

    with patch.object(
        window,
        "_current_valid_filter_identities",
        return_value=valid_identities,
    ):
        window.filter_display_valid_check.setChecked(True)
    assert not window.canvas.highlighted_price_filter_identities
    assert window.canvas.highlighted_lower_filter_identities == manual_lower
    assert set(window.canvas.valid_filter_identities) == valid_identities

    window.canvas.reset_price_legend_visibility()
    window.canvas.price_legend_prefix_reset_requested.emit()
    assert not window.filter_display_valid_check.isChecked()
    assert not window.canvas.valid_filter_identities
    assert not window.canvas.highlighted_lower_filter_identities
    assert not window.canvas.hidden_price_filter_identities
    assert not window.canvas.hide_unhighlighted_price_filters
    assert not window.canvas._price_visibility_filter_active()
    assert not window.canvas._lower_visibility_filter_active()


def test_filter_off_on_restores_authoritative_window_highlights(case):
    window = window_for(case)
    install(window)
    descriptor = wm.ValidationFilterDescriptor(
        "price", wm.FAMILY_MOVING_AVERAGE, "MA", wm.PRICE_AXIS,
        ("BUY",), ("VALUE",), "{}", (),
    )
    cache = wm.ValidationIndicatorSeriesCache(len(window._candles), ())
    window._highlighted_price_filter_identities = {("BUY", "price")}
    window._hide_unhighlighted_price_filters = True
    window._apply_visualization_projection((descriptor,), cache, {})
    assert set(window.canvas.highlighted_price_filter_identities) == {
        ("BUY", "price"),
    }

    blocker = QSignalBlocker(window.filter_display_check)
    window.filter_display_check.setChecked(False)
    del blocker
    window._apply_visualization_projection((), cache, {})
    assert window._highlighted_price_filter_identities == {("BUY", "price")}
    assert not window.canvas.highlighted_price_filter_identities
    assert window._visualization_lower_filter_presentations == ()
    assert not any(
        block["legend_role"] == "LOWER_FILTER"
        for _side, _label, blocks in window.canvas._price_legend_rows()
        for block in blocks
    )

    blocker = QSignalBlocker(window.filter_display_check)
    window.filter_display_check.setChecked(True)
    del blocker
    window._apply_visualization_projection((descriptor,), cache, {})
    assert window._highlighted_price_filter_identities == {("BUY", "price")}
    assert set(window.canvas.highlighted_price_filter_identities) == {
        ("BUY", "price"),
    }
    assert window.canvas.hide_unhighlighted_price_filters
    assert not window.canvas.hidden_price_filter_identities


def test_window_supplies_phase2_bundles_and_reinstall_preserves_legend_state(case):
    window = window_for(case)
    install(window)
    presentation_rules = window._all_filter_descriptor_cache_display_rules
    assert presentation_rules is not None
    expected_presentations = wm.build_validation_lower_filter_presentations(
        presentation_rules,
        window.visualization_descriptors,
    )
    assert expected_presentations
    assert window._visualization_lower_filter_presentations == expected_presentations
    assert window.canvas._lower_filter_presentations == expected_presentations
    assert window.canvas._TOP == 58
    rows = window.canvas._price_legend_rows()
    assert [side for side, _label, _blocks in rows] == ["BUY", "SELL"]
    lower_block = next(
        block
        for _side, _label, blocks in rows
        for block in blocks
        if block["legend_role"] == "LOWER_FILTER"
    )
    price_side, price_block = next(
        (side, block)
        for side, _label, blocks in rows
        for block in blocks
        if block["legend_role"] == "PRICE_FILTER"
    )
    lower_side = next(
        side
        for side, _label, blocks in rows
        if lower_block in blocks
    )
    window.canvas._toggle_price_legend_identities(
        lower_side,
        lower_block["descriptor_identities"],
    )
    window.canvas._toggle_price_legend_identities(
        price_side,
        price_block["descriptor_identities"],
    )
    lower_state = window.canvas.highlighted_lower_filter_identities
    price_state = window.canvas.highlighted_price_filter_identities
    hidden_state = window.canvas.hidden_price_filter_identities
    hide_unhighlighted = window.canvas.hide_unhighlighted_price_filters

    previous_canvas = window.canvas
    window._install_normal_chart_canvas("M1", window._chart_marker_records())
    assert window.canvas is not previous_canvas
    assert window.canvas._lower_filter_presentations == expected_presentations
    assert window.canvas.highlighted_lower_filter_identities == lower_state
    assert window.canvas.highlighted_price_filter_identities == price_state
    assert window.canvas.hidden_price_filter_identities == hidden_state
    assert window.canvas.hide_unhighlighted_price_filters == hide_unhighlighted
    assert not hasattr(window.canvas, "selection_indicator_index")


def _working_ui_lower_presentations(window, evaluated_rules, display_rules):
    evaluated_before = deepcopy(evaluated_rules)
    snapshot_owner = window._result_settings_snapshot
    mapper = Mock()
    mapper.build_engine_rules_preview_from_ui_state.return_value = {
        "preview_rules": display_rules,
    }
    with (
        patch.object(window, "_load_indicator_follow_rule_mapper", return_value=mapper),
        patch.object(window, "_filter_display_restore_sell_gap_visualization"),
    ):
        descriptors = window._all_filter_display_descriptors(evaluated_rules)
    assert evaluated_rules == evaluated_before
    assert window._result_settings_snapshot is snapshot_owner
    assert window._all_filter_descriptor_cache_display_rules is not display_rules
    window._refresh_lower_filter_presentations(evaluated_rules, descriptors)
    return descriptors, window._visualization_lower_filter_presentations


def test_working_ui_buy_ocr_zero_threshold_and_turn_share_one_caption(case):
    window = window_for(case)
    display_rules = _realistic_lower_presentation_rules()
    display_rules["buy"]["filters"] = {
        "ocr": deepcopy(display_rules["buy"]["filters"]["ocr"]),
    }
    display_rules["buy"]["filters"]["ocr"]["conditions"][1]["value"] = -0.0
    duplicate_turn = deepcopy(
        display_rules["buy"]["filters"]["ocr"]["conditions"][0]
    )
    display_rules["buy"]["groups"] = [{
        "enabled": True,
        "conditions_logic": "AND",
        "conditions": [duplicate_turn],
    }]
    display_rules["sell"]["signals"] = {}
    evaluated_rules = deepcopy(display_rules)
    evaluated_rules["buy"]["filters"]["ocr"]["conditions"] = [
        deepcopy(display_rules["buy"]["filters"]["ocr"]["conditions"][0]),
    ]

    descriptors, presentations = _working_ui_lower_presentations(
        window,
        wm.project_signal_validation_rules(evaluated_rules),
        display_rules,
    )
    buy_ocr = [
        record
        for record in presentations
        if record.side == "BUY" and record.filter_token == "ocr"
    ]
    assert len(buy_ocr) == 1
    assert len(buy_ocr[0].component_descriptor_identities) == 2

    canvas = wm.IndicatorFollowSignalValidationChartCanvas(
        [], [],
        visualization_descriptors=descriptors,
        lower_filter_presentations=presentations,
    )
    case.widgets.append(canvas)
    captions = [
        block["caption"]
        for side, _label, blocks in canvas._price_legend_rows()
        if side == "BUY"
        for block in blocks
        if block["legend_role"] == "LOWER_FILTER"
    ]
    assert len(captions) == 1
    assert captions == ["[ MACD(12,26,9) : OCR 0 \uc774\ud558 \uc0c1\uc2b9\uc804\ud658 ]"]
    assert "|" not in captions[0]


def test_working_ui_sell_ocr_and_rsi_yield_two_captions_without_duplicate_transition(case):
    window = window_for(case)
    display_rules = _realistic_lower_presentation_rules()
    display_rules["buy"]["filters"] = {}
    display_rules["sell"]["signals"] = {
        "ui_condition_a": deepcopy(
            display_rules["sell"]["signals"]["ui_condition_a"]
        ),
    }
    evaluated_rules = deepcopy(display_rules)
    evaluated_conditions = evaluated_rules["sell"]["signals"][
        "ui_condition_a"
    ]["groups"][0]["conditions"]
    evaluated_rules["sell"]["signals"]["ui_condition_a"]["groups"][0][
        "conditions"
    ] = [
        deepcopy(evaluated_conditions[0]),
        deepcopy(evaluated_conditions[1]),
    ]

    descriptors, presentations = _working_ui_lower_presentations(
        window,
        wm.project_signal_validation_rules(evaluated_rules),
        display_rules,
    )
    sell_presentations = [
        record for record in presentations if record.side == "SELL"
    ]
    assert [record.filter_token for record in sell_presentations] == ["OCR", "RSI"]
    assert len(sell_presentations[0].component_descriptor_identities) == 2

    canvas = wm.IndicatorFollowSignalValidationChartCanvas(
        [], [],
        visualization_descriptors=descriptors,
        lower_filter_presentations=presentations,
    )
    case.widgets.append(canvas)
    captions = [
        block["caption"]
        for side, _label, blocks in canvas._price_legend_rows()
        if side == "SELL"
        for block in blocks
        if block["legend_role"] == "LOWER_FILTER"
    ]
    assert len(captions) == 2
    assert sum(caption.count("\ud558\ub77d\uc804\ud658") for caption in captions) == 1


def test_normal_canvas_selection_navigation_and_prepend_anchor(case):
    window = window_for(case)
    install(window)
    expected_filter_universe = window._all_filter_display_descriptors(case.rules)
    assert window.visualization_descriptors == expected_filter_universe
    window.show()
    case.app.processEvents()
    assert window._visible_candle_span == 250
    assert window.fixed_price_axis._canvas is window.canvas
    assert window.select_evaluation_index(410)
    assert window._selected_index == 410
    assert not hasattr(window.canvas, "selection_indicator_index")
    assert not hasattr(window.canvas, "position_indicator_selected")
    assert not hasattr(window.canvas, "position_indicator_clear_requested")
    assert not hasattr(window, "_position_indicator_index")
    assert not hasattr(window, "_position_indicator_time")
    before = window._visible_start_index
    window.canvas.pan_requested.emit(20.0, 0.0)
    assert window._visible_start_index != before
    anchor = window._capture_history_extension_view_anchor()
    install(window, candles(800))
    assert window._candles[int(window._visible_start_index)]["time"] == anchor.visible_start_time
    assert window.visualization_descriptors == expected_filter_universe
    assert window.replay_snapshot is None


def test_provider_entry_history_extension_and_cap_without_scan(case):
    window = window_for(case)
    requests = []
    failures = []
    replay = Mock(side_effect=AssertionError("base navigation must not replay"))

    class Provider:
        def __init__(self, session, broker):
            self.session = session

        def request_latest(self, count, callback):
            requests.append(count)
            callback(_result(case.stock, self.session.request.timeframe_minutes,
                             candles(count), market_data_identity="005930", market_source="KRX"))

    flow = fm.IndicatorFollowSignalValidationV4Flow(
        object(), host=legacy._FakeHost(case.stock), replay_factory=replay,
        historical_cache=case.default_history_cache, historical_provider_factory=Provider,
        historical_count=250,
    )
    key = id(window)
    flow._open_windows[key] = window
    flow._request_generation[key] = 0
    flow.validation_failed.connect(failures.append)
    window.validation_run_requested.connect(lambda req: flow._run_validation(window, req))
    window.request_initial_validation()
    wait_for(case, lambda: window._normal_base_ready or failures)
    assert not failures
    assert len(window._candles) == 250
    assert window._visible_candle_span == 250
    initial_time = window._candles[0]["time"]
    flow._request_history_extension(window)
    wait_for(case, lambda: len(window._candles) > 250 or failures)
    assert not failures
    assert window._candles[int(window._visible_start_index)]["time"] == initial_time
    assert len(requests) == 2
    assert not flow._history_extension_inflight
    assert not flow._active_providers
    minutes = flow._validation_sessions[key].request.timeframe_minutes
    assert case.default_history_cache.load(case.stock.code, minutes, requests[-1]) is not None
    assert window.replay_snapshot is None
    flow._history_targets[key] = fm.MAX_SIGNAL_VALIDATION_HISTORICAL_COUNT
    flow._request_history_extension(window)
    assert len(requests) == 2
    replay.assert_not_called()


def test_single_click_preserves_bar_selection_without_position_indicator_paint(case):
    window = window_for(case)
    install(window)
    window.show()
    case.app.processEvents()
    canvas = window.canvas
    index = 450
    x = round(canvas._x_for_index(index))
    y = round((canvas.price_scale().plot_top + canvas.price_scale().plot_bottom) / 2)
    canvas._set_crosshair_pointer(None, None)
    before_click = QPixmap(canvas.size())
    canvas.render(before_click)
    QTest.mouseClick(canvas, Qt.LeftButton, pos=QPoint(x, y))
    assert window._selected_index == index
    assert canvas.selected_index == index
    assert not hasattr(canvas, "selection_indicator_index")
    canvas._set_crosshair_pointer(None, None)
    case.app.processEvents()
    after_click = QPixmap(canvas.size())
    canvas.render(after_click)
    assert before_click.toImage() == after_click.toImage()


def test_real_mouse_wheel_scrollbar_and_range_signals_on_normal_canvas(case):
    window = window_for(case)
    install(window)
    window.show()
    case.app.processEvents()
    canvas = window.canvas
    index = 450
    x = round(canvas._x_for_index(index))
    y = round((canvas.price_scale().plot_top + canvas.price_scale().plot_bottom) / 2)
    QTest.mouseClick(canvas, Qt.LeftButton, pos=QPoint(x, y))
    assert window._selected_index == index
    assert canvas.selected_index == index
    assert not hasattr(canvas, "selection_indicator_index")
    span = window.visible_candle_span
    pos = QPoint(x, y)
    event = QWheelEvent(QPointF(pos), QPointF(canvas.mapToGlobal(pos)), QPoint(),
                        QPoint(0, 120), Qt.NoButton, Qt.NoModifier, Qt.NoScrollPhase, False)
    QApplication.sendEvent(canvas, event)
    case.app.processEvents()
    assert window.visible_candle_span < span
    window.time_navigation_scrollbar.setValue(0)
    assert window.visible_start_index == 0
    window._set_time_view(300.0, 200.0)
    ranges = []
    window.validation_range_evaluation_requested.connect(lambda a, b: ranges.append((a, b)))
    start = QPoint(round(canvas._x_for_index(350)), y)
    end = QPoint(round(canvas._x_for_index(380)), y)
    QApplication.sendEvent(canvas, QMouseEvent(QEvent.MouseButtonDblClick, QPointF(start),
                                               Qt.LeftButton, Qt.LeftButton, Qt.NoModifier))
    QApplication.sendEvent(canvas, QMouseEvent(QEvent.MouseMove, QPointF(end),
                                               Qt.NoButton, Qt.LeftButton, Qt.NoModifier))
    QTest.mouseRelease(canvas, Qt.LeftButton, pos=end)
    assert ranges == [(350, 380)]
    assert window.validation_range == (350, 380)
    assert canvas.validation_range == (350, 380)
    assert window._selected_index == 350
    assert canvas.selected_index == 350
    assert window.replay_snapshot is None


def test_saved_visibility_and_numeric_series_match_v2_normal_layers(case):
    from tests.test_indicator_follow_signal_validation_operator_ui import _MemoryValidationPreferenceStore
    window = window_for(case)
    store = _MemoryValidationPreferenceStore({
        "filter_display_enabled": False, "filter_display_side": "매도", "filter_display_scope": "유효",
    })
    window.set_validation_preferences_store(store)
    install(window)
    assert not window.visualization_descriptors
    assert not window.visualization_cache.series
    assert not store.saved
    assert not hasattr(window, "_filter_display_side")
    window.filter_display_check.setChecked(True)
    wait_for(case, lambda: bool(window.visualization_cache.series))
    base = case._window()
    base.filter_display_scope_combo.setCurrentText("전체")
    base.set_historical_candle_pool(candles(), chart_candle_count=600)
    base._result_settings_snapshot = base._signal_validation_seed.settings_snapshot
    base._rebuild_visualization_data()
    assert window.visualization_descriptors == base._all_filter_display_descriptors(
        case.rules
    )
    base_series = {(identity, channel): values for identity, channel, values in base.visualization_cache.series}
    comparison_ids = {d.identity for d in window.visualization_descriptors
                      if d.family == wm.FAMILY_PRICE_COMPARISON}
    for identity, channel, values in window.visualization_cache.series:
        if identity in comparison_ids or channel == "AVG_PRICE":
            assert all(v is None for v in values)
            continue
        assert values == base_series[(identity, channel)]
        assert any(v is not None for v in values)
    assert window._filter_display_evidence_identities_by_side == {"BUY": frozenset(), "SELL": frozenset()}


def test_stale_base_worker_cannot_publish_or_create_signal_evidence(case):
    window = window_for(case)
    flow = fm.IndicatorFollowSignalValidationV4Flow(
        object(), host=legacy._FakeHost(case.stock), historical_count=600,
        historical_cache=case.default_history_cache,
        replay_factory=Mock(side_effect=AssertionError("no replay")),
    )
    key = id(window)
    flow._open_windows[key] = window
    flow._request_generation[key] = 0
    settings = window._signal_validation_seed.settings_snapshot
    session = legacy.ValidationSession(legacy.ValidationRequest(
        case.stock, settings, settings.to_dict()["bar"]["bar_minutes"],
    ), operation_active_reader=lambda: False)
    pool = flow._pool_from_candles(session, candles(), requested_count=600,
                                   request_id="STALE", market_data_identity="005930", market_source="KRX")
    jobs = []

    class HeldThread:
        def __init__(self, *, target, **kwargs):
            jobs.append(target)

        def start(self):
            pass

    with patch.object(fm, "Thread", HeldThread):
        flow._use_pool_for_window(window, session, pool, evaluation_count=100)
    flow._invalidate_window_requests(key)
    jobs.pop()()
    case.app.processEvents()
    assert getattr(window, "canvas", None) is None
    assert not window._normal_base_ready
    assert window.replay_snapshot is None
    assert not flow._prepare_active


@pytest.mark.parametrize("method", [
    "test_chart_price_axis_is_fixed_and_uses_five_scaled_ticks",
    "test_price_axis_wheel_scales_price_with_cursor_anchor_and_preserves_time_view",
])
def test_original_replay_ui_contract_on_v4(case, method):
    with patch.object(legacy, "IndicatorFollowSignalValidationWindow", wm.IndicatorFollowSignalValidationV4Window):
        getattr(case, method)()


def test_display_only_sidecar_and_regular_toggle_need_no_replay(case):
    window = window_for(case)
    rows = candles(600)
    install(window, rows)
    original = deepcopy(window._calculation_candles)
    premarket = dict(rows[0], time="20261007080000", close=999999)
    window.validation_regular_market_only_check.setChecked(False)
    window.set_display_only_integrated_candles([premarket] + rows[-200:])
    assert window._candles[0]["time"] == premarket["time"]
    assert window._chart_calculation_indexes[0] is None
    assert window.canvas._candles[0]["time"] == premarket["time"]
    assert window._calculation_candles == original
    window.validation_regular_market_only_check.setChecked(True)
    assert all(c["time"][8:12] >= "0900" for c in window.canvas._candles)
    assert window.replay_snapshot is None


@pytest.mark.parametrize("bounds, expected_indexes", [
    ((0, 17), ((0, 1, 4, 5, 8, 9), (11, 14, 15))),
    ((4, 16), ((4, 5, 8, 9), (11, 14, 15))),
    ((5, 15), ((5, 8, 9), (11, 14))),
    ((6, 16), ((8, 9), (11, 14, 15))),
    ((8, 10), ((8, 9),)),
    ((2, 4), ()),
    ((4, 5), ((4,),)),
    ((5, 8), ((5,),)),
    ((12, 14), ()),
    ((16, 17), ()),
])
def test_sparse_series_pan_preserves_original_indexes_and_breaks(bounds, expected_indexes):
    app = legacy.ensure_qapplication()
    canvas = wm.IndicatorFollowSignalValidationChartCanvas(
        [], [], bridgeable_display_only_indexes=frozenset({2, 3, 6, 7, 12, 13, 16}),
    )
    values = (100., 101., None, None, 104., 105., None, None, 108., 109.,
              None, 111., None, None, 114., 115., None)

    def subpaths(path):
        result = []
        for index in range(path.elementCount()):
            element = path.elementAt(index)
            if element.isMoveTo():
                result.append([])
            else:
                assert element.isLineTo()
            result[-1].append((element.x, element.y))
        return result

    try:
        full_path, full_has_segment = canvas._series_line_data_path(values, 0, len(values))
        full_points = subpaths(full_path)
        assert full_has_segment
        assert full_points == [
            [(0., 100.), (1., 101.), (4., 104.), (5., 105.), (8., 108.), (9., 109.)],
            [(11., 111.), (14., 114.), (15., 115.)],
        ]
        polygons = canvas._series_polygon_cache[id(values)]
        result = canvas._series_line_data_path(values, *bounds)
        path, has_segment = result
        expected = [[(float(x), values[x]) for x in group] for group in expected_indexes]
        assert subpaths(path) == expected
        filtered_full = [[point for point in group if bounds[0] <= point[0] < bounds[1]]
                         for group in full_points]
        assert subpaths(path) == [group for group in filtered_full if group]
        assert has_segment == any(len(group) >= 2 for group in expected_indexes)
        assert canvas._series_line_data_path(values, *bounds) is result
        assert canvas._series_polygon_cache[id(values)] is polygons
        assert subpaths(canvas._series_line_data_path(values, 0, len(values))[0]) == full_points
        canvas.set_visualization_projection((), None, {}, [])
        assert not canvas._series_line_path_cache and not canvas._series_polygon_cache
        assert canvas._series_line_path_cache_bounds is None
    finally:
        canvas.close()
        canvas.deleteLater()
        legacy.flush_deferred_deletes(app)

def test_switch_m3_to_m120_rebuilds_initial_price_axis_and_reset_baseline(case):
    """Timeframe change must not carry the old price/time-scale or reset origin."""
    import json
    from pathlib import Path

    window = window_for(case)
    rules = window._signal_validation_seed.settings_snapshot.to_dict()
    rules["bar"]["bar_minutes"] = 3
    rules["validation_timeframe"] = fm.normalize_validation_timeframe(3)
    initial_settings = legacy.ValidationSettingsSnapshot(rules)
    window.set_historical_candle_pool(candles(500), chart_candle_count=500)
    window.install_normal_base(initial_settings, "M3")
    window._set_time_view(100, 180, manually_adjusted=True)
    window._apply_pan_chart_target(("price", 262000., 270698.))
    assert window.price_scale_manually_adjusted
    assert window.time_scale_manually_adjusted

    archive = Path(__file__).resolve().parents[1] / (
        "runtime/signal_validation_v2_history_cache/005930_120_5060.json"
    )
    m120 = json.loads(archive.read_text(encoding="utf-8"))["candles"]
    rules["bar"]["bar_minutes"] = 120
    rules["validation_timeframe"] = fm.normalize_validation_timeframe(120)
    settings = legacy.ValidationSettingsSnapshot(rules)
    window.set_historical_candle_pool(m120, chart_candle_count=500)
    window.install_normal_base(settings, "M120")
    lower, upper = window.current_price_bounds
    recent = window._candles[-250:]
    assert lower <= min(float(c["low"]) for c in recent)
    assert upper >= max(float(c["high"]) for c in recent)
    assert not window.price_scale_manually_adjusted
    assert not window.time_scale_manually_adjusted
    assert window.visible_candle_span == 250
    assert window.visible_start_index == len(window._candles) - 250
    assert window._entry_chart_view_state.current_price_minimum == lower
    assert window._entry_chart_view_state.current_price_maximum == upper

    window._apply_pan_chart_target(("price", 262000., 270698.))
    assert window.reset_chart_view()
    assert window.current_price_bounds == pytest.approx((lower, upper))
    assert not window.price_scale_manually_adjusted


def test_same_m120_refresh_preserves_user_price_and_time_adjustments(case):
    """Same timeframe reinstallation must retain the user's chosen viewport."""
    import json
    from pathlib import Path

    window = window_for(case)
    archive = Path(__file__).resolve().parents[1] / (
        "runtime/signal_validation_v2_history_cache/005930_120_5060.json"
    )
    rows = json.loads(archive.read_text(encoding="utf-8"))["candles"]
    rules = window._signal_validation_seed.settings_snapshot.to_dict()
    rules["bar"]["bar_minutes"] = 120
    rules["validation_timeframe"] = fm.normalize_validation_timeframe(120)
    settings = legacy.ValidationSettingsSnapshot(rules)
    window.set_historical_candle_pool(rows, chart_candle_count=500)
    window.install_normal_base(settings, "M120")

    window._set_time_view(115, 170, manually_adjusted=True)
    window._apply_pan_chart_target(("price", 262000., 270698.))
    assert window.price_scale_manually_adjusted
    window.set_historical_candle_pool(rows, chart_candle_count=500)
    window.install_normal_base(settings, "M120")
    assert window.visible_start_index == pytest.approx(115)
    assert window.visible_candle_span == 170
    assert window.time_scale_manually_adjusted
    assert window.current_price_bounds == pytest.approx((262000., 270698.))
    assert window.price_scale_manually_adjusted
