"""Regression checks: preview existing labels, reflow only the final view."""
import unittest
from unittest.mock import patch
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QImage, QPainter
from PyQt5.QtTest import QTest
from tests.test_indicator_follow_signal_validation_cycle_label_performance import (
    CompletedCycleLabelPerformanceRegressionTest as Fixtures,
)

class Owner:
    def __init__(self, canvas):
        self.canvas, self.busy = canvas, True
    def is_chart_view_update_busy(self):
        return self.busy or self.canvas.is_pointer_interaction_active()

class DeferredLabelsTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        Fixtures.setUpClass()
    def setUp(self):
        self.fixture = Fixtures('runTest')
        self.fixture.setUp()
        self.c = self.fixture._canvas()
        self.owner = Owner(self.c)
        self.c._input_frame_owner = self.owner
        self.paint_labels()
    def tearDown(self):
        self.fixture.tearDown()
    def paint_labels(self):
        image = QImage(self.c.size(), QImage.Format_ARGB32)
        image.fill(Qt.transparent)
        painter = QPainter(image)
        try:
            self.c._draw_completed_cycle_average_labels(painter, self.c.price_scale())
        finally:
            painter.end()
        return image
    def test_continuous_navigation_never_reflows_then_final_reflows_once(self):
        c = self.c
        with patch.object(c, 'completed_cycle_average_label_records',
                          wraps=c.completed_cycle_average_label_records) as layout:
            for start in (1., 2., 3., 4.):
                c.set_time_view(start, 17.5)
                self.paint_labels()
            self.assertEqual(0, layout.call_count, 'intermediate input reran label placement')
            self.owner.busy = False
            QTest.qWait(250)
            self.paint_labels()
            self.assertEqual(1, layout.call_count, 'final view must reflow once')
        self.assertEqual(c.completed_cycle_average_label_records(),
                         list(c._cycle_label_last_records))
    def test_held_pointer_prevents_timer_reflow(self):
        c = self.c
        c._begin_pointer_interaction()
        c.set_time_view(2., 17.5)
        self.paint_labels()
        self.owner.busy = False
        with patch.object(c, 'completed_cycle_average_label_records',
                          wraps=c.completed_cycle_average_label_records) as layout:
            QTest.qWait(250)
            self.paint_labels()
            self.assertEqual(0, layout.call_count)
            c._end_pointer_interaction(cancelled=False)
            QTest.qWait(60)
            self.paint_labels()
            self.assertEqual(1, layout.call_count)
    def test_transform_uses_initial_view_and_keeps_text_and_size(self):
        c = self.c
        original = list(c._cycle_label_last_records)
        c.set_time_view(2., 17.5)
        c.set_price_view(90., 110.)
        self.paint_labels()
        c.set_time_view(4., 15.)
        self.paint_labels()
        transformed = c._cycle_label_records_for_paint(c.price_scale())
        self.assertEqual(len(original), len(transformed))
        for before, after in zip(original, transformed):
            self.assertEqual(before['texts'], after['texts'])
            self.assertEqual(before['label_width'], after['label_width'])
            self.assertEqual(before['label_height'], after['label_height'])
        c.set_time_view(2., 17.5)
        first = c._cycle_label_records_for_paint(c.price_scale())
        c.set_time_view(4., 15.)
        c.set_time_view(2., 17.5)
        self.assertEqual(first, c._cycle_label_records_for_paint(c.price_scale()))
    def test_noop_does_not_start_preview(self):
        self.c.set_time_view(self.c._visible_start_index, self.c._visible_candle_span)
        self.assertFalse(self.c._cycle_label_preview_active)
        self.assertFalse(self.c._cycle_label_settle_timer.isActive())
    def test_clear_range_discards_pending_labels_and_timer(self):
        c = self.c
        c.set_time_view(2., 17.5)
        self.paint_labels()
        c.set_validation_range(None, None)
        self.owner.busy = False
        QTest.qWait(250)
        self.assertFalse(c._cycle_label_preview_active)
        self.assertFalse(c._cycle_label_settle_timer.isActive())
        self.assertEqual([], c._cycle_label_records_for_paint(c.price_scale()))
    def test_cancel_clears_preview_without_replaying_input(self):
        c = self.c
        c.set_time_view(2., 17.5)
        position = (c._visible_start_index, c._visible_candle_span)
        c.discard_pointer_interaction()
        self.owner.busy = False
        QTest.qWait(250)
        self.assertFalse(c._cycle_label_preview_active)
        self.assertFalse(c._cycle_label_settle_timer.isActive())
        self.assertEqual(position, (c._visible_start_index, c._visible_candle_span))
    def test_changed_projection_discards_prior_content(self):
        c = self.c
        c.set_time_view(2., 17.5)
        c.set_visualization_projection((), None, {}, [])
        self.assertFalse(c._cycle_label_preview_active)
        self.assertEqual((), c._cycle_label_last_records)

    def test_hide_cancels_wheel_preview_without_pointer_press(self):
        c = self.c
        c.show()
        self.fixture.app.processEvents()
        c.set_time_view(2., 17.5)
        self.paint_labels()
        self.assertTrue(c._cycle_label_preview_active)
        self.assertFalse(c.is_pointer_interaction_active())
        c.hide()
        self.assertFalse(c._cycle_label_preview_active)
        self.assertFalse(c._cycle_label_settle_timer.isActive())
        self.owner.busy = False
        QTest.qWait(250)
        self.assertEqual((), c._cycle_label_last_records)

    def test_wheel_quiet_period_starts_after_slow_frame_finishes(self):
        import time
        c = self.c
        c.show()
        self.fixture.app.processEvents()
        c.set_time_view(2., 17.5)
        self.owner._chart_input_frame_active = True
        self.owner._chart_input_frame_canvas = c
        original = c._paint_static_chart
        def slow_frame(*args, **kwargs):
            time.sleep(.22)
            return original(*args, **kwargs)
        with patch.object(c, '_paint_static_chart', side_effect=slow_frame):
            c.repaint()
        self.assertGreater(c._cycle_label_settle_timer.remainingTime(), 140,
                           'wheel quiet period expired inside current frame')

class V4DeferredLabelsTest(DeferredLabelsTest):
    def setUp(self):
        import gui_indicator_follow_signal_validation_v4_window as v4
        module = patch('tests.test_indicator_follow_signal_validation_cycle_label_performance.window', v4)
        module.start()
        self.addCleanup(module.stop)
        super().setUp()


if __name__ == '__main__':
    unittest.main()
