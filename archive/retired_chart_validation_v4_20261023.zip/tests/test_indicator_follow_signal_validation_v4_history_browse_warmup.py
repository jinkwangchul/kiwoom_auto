"""Manual-range history browsing uses hidden canonical context, without replaying signals."""
from copy import deepcopy
from datetime import datetime, timedelta
import inspect
from unittest.mock import Mock, patch

import pytest

from tests.test_indicator_follow_signal_validation_v4_normal_base import case, wait_for, legacy, wm, fm
from tests.test_indicator_follow_signal_validation_v4_warmup_legend import archive_rows, flow_case, indicators
from tests.test_indicator_follow_signal_validation_persistent_history_flow import _result
from indicator_follow_signal_validation_visualization import build_validation_indicator_cache


def selected(case, regular=True):
    rows = archive_rows()
    window, flow, session, pool, rules, _ = flow_case(case, rows[-1150:], count=250, regular=regular)
    # Range replay reads draft settings; this fixture browses the same accepted settings.
    window._marking_current_settings = lambda: session.request.settings_snapshot
    key = id(window)
    flow._history_targets[key] = 250
    flow._historical_pools[key] = pool
    flow._validation_sessions[key] = session
    window.set_historical_candle_pool(pool['candles'], chart_candle_count=250)
    view = flow._validation_pool_for_session(session, pool, target_count=1150)
    window.set_historical_display_candles(view.get('display_candles', pool['candles'])[-250:])
    window.install_normal_base(session.request.settings_snapshot, 'M3')
    errors = []
    flow.validation_failed.connect(errors.append)
    flow._replay_factory = legacy.ValidationHistoricalReplay
    window.validation_range_evaluation_requested.connect(
        lambda a, b: flow._run_cached_range_replay(window, a, b))
    window.marking_evaluation_requested.connect(lambda request: flow._start_marking(window, request))
    window._set_time_view(max(0, len(window._candles) - 40), 25)
    # Marking ON clears any preceding local range by contract. Select an
    # interior range *after* marking, preserving both frozen marking and replay.
    with patch.object(window, "_marking_current_settings", return_value=session.request.settings_snapshot):
        window.marking_display_check.setChecked(True)
        wait_for(case, lambda: window._marking_snapshot is not None or not window.marking_display_check.isChecked())
    assert window._marking_snapshot is not None, window.marking_display_check.toolTip()
    marked_snapshot = window._marking_snapshot
    marked_times = window._marking_times
    assert isinstance(marked_times, tuple) and len(marked_times) == 2
    indexes = {str(candle["time"]): idx for idx, candle in enumerate(window._candles)}
    start = indexes[marked_times[0]] + 3
    end = indexes[marked_times[1]] - 3
    assert start < end
    window._complete_validation_range_drag(start, end)
    wait_for(case, lambda: window._range_replay_entries_available or errors)
    assert not errors
    assert window.replay_snapshot is not None
    assert not window._normal_base_requested
    assert window.marking_display_check.isChecked()
    assert window._marking_times == marked_times
    assert window._marking_snapshot is marked_snapshot
    flow._replay_factory = Mock(side_effect=AssertionError('browse must not replay'))
    return rows, window, flow, session, pool, rules


def test_identical_history_source_reuses_only_accepted_full_indicator_series(case):
    """A single bounded cache entry may skip only identical full-series work."""
    from dataclasses import replace
    from unittest.mock import patch
    from gui_indicator_follow_signal_validation_v4_window import (
        prepare_signal_validation_presentation,
    )
    from datetime import datetime, timedelta

    rows, window, flow, session, pool, rules = selected(case)
    source = flow._pool_from_candles(
        session, rows, requested_count=len(rows), request_id="SERIES_REUSE",
        market_data_identity="005930", market_source="KRX",
    )
    expected_marking = window._marking_snapshot
    expected_range = window._validation_range_times
    original_capture = window.capture_history_browse_state
    import gui_indicator_follow_signal_validation_v4_window as v4_window
    descriptors = indicators()
    builds = []
    presentations = []
    real_build = v4_window.build_validation_indicator_cache

    class InlineThread:
        def __init__(self, *, target, **kwargs):
            self.target = target

        def start(self):
            self.target()

    def capture(*args, **kwargs):
        return dict(
            original_capture(*args, **kwargs),
            visualization_descriptors=descriptors,
        )

    def build(*args, **kwargs):
        if inspect.currentframe().f_back.f_code.co_name == "prepare_signal_validation_presentation":
            builds.append(len(args[0]))
        return real_build(*args, **kwargs)

    def prepare(*args, **kwargs):
        result = prepare_signal_validation_presentation(*args, **kwargs)
        presentations.append(result)
        return result

    def browse(target, selected_source):
        flow._history_targets[id(window)] = target
        assert flow._use_pool_for_history_browse(
            window, session, selected_source, evaluation_count=100,
            _warmup_ready=True,
        )
        case.app.processEvents()
        assert window._marking_snapshot is expected_marking
        assert window._validation_range_times == expected_range
        assert window.replay_snapshot is not None

    with (
        patch.object(fm, "Thread", InlineThread),
        patch.object(fm, "prepare_signal_validation_presentation", prepare),
        patch.object(v4_window, "build_validation_indicator_cache", build),
        patch.object(window, "capture_history_browse_state", capture),
        patch.object(flow, "_persist_history", return_value=True),
        patch.object(flow, "_ensure_integrated_display_sidecar"),
    ):
        browse(500, source)
        assert builds == [len(rows)]
        browse(1000, source)
        assert builds == [len(rows)], "same full source must reuse series"
        cached_result = presentations[-1]

        flow._history_browse_indicator_cache.pop(id(window), None)
        browse(1000, source)
        assert builds == [len(rows), len(rows)]
        assert presentations[-1] == cached_result

        descriptors = (
            replace(descriptors[0], identity="ma:changed"),
            *descriptors[1:],
        )
        browse(500, source)
        assert len(builds) == 3, "descriptor changes must invalidate cache"

        older_stamp = (
            datetime.strptime(rows[0]["time"], "%Y%m%d%H%M%S")
            - timedelta(minutes=3)
        ).strftime("%Y%m%d%H%M%S")
        expanded = [dict(rows[0], time=older_stamp), *rows]
        extended_source = flow._pool_from_candles(
            session, expanded, requested_count=len(expanded),
            request_id="SERIES_REUSE",
            market_data_identity="005930", market_source="KRX",
        )
        browse(500, extended_source)
        assert len(builds) == 4, "older source prefix must invalidate cache"
        assert len(flow._history_browse_indicator_cache) == 1

    flow._release_window(id(window))
    assert not flow._history_browse_indicator_cache


@pytest.mark.parametrize('regular', [True, False, None])
@pytest.mark.parametrize('source', ['cache', 'provider'])
def test_manual_selection_then_larger_history_has_hidden_warmup(case, regular, source):
    rows, window, flow, session, old_pool, rules = selected(case, regular is True)
    key = id(window)
    incoming = flow._pool_from_candles(session, rows[-1400:], requested_count=1400,
        request_id='BROWSE', market_data_identity='005930', market_source='KRX')
    descriptors = indicators()
    integrated = rows[-999:]
    stamp = datetime.strptime(integrated[0]['time'], '%Y%m%d%H%M%S') - timedelta(seconds=1)
    nxt = dict(integrated[0], time=stamp.strftime('%Y%m%d%H%M%S'), close=999999)
    integrated = [nxt] + integrated
    before = (window.replay_snapshot, window._validation_range_times,
              deepcopy(window._range_replay_calculation_entries), window._marking_cache,
              session.request.settings_snapshot.rules_hash)
    failures, payloads, requests = [], [], []
    flow.validation_failed.connect(failures.append)
    flow.history_browse_completed.connect(payloads.append)
    entry = fm.ValidationHistoricalCacheEntry('005930', case.stock.name, 3, 'M3', 2900,
        tuple(rows), '', '005930', 'KRX')

    class Provider:
        def __init__(self, *args):
            pass
        def request_latest(self, count, callback):
            requests.append(count)
            callback(_result(case.stock, 3, rows[-count:], market_data_identity='005930', market_source='KRX'))

    flow._historical_provider_factory = Provider if source == 'provider' else Mock(side_effect=AssertionError('cache sufficient'))
    flow._history_targets[key] = 1000
    with patch.object(flow, '_cached_history', return_value=entry if source == 'cache' else None), \
         patch.object(flow, '_integrated_display_candles_for_session', return_value=integrated if regular is False else None), \
         patch.object(flow, '_ensure_integrated_display_sidecar'), \
         patch.object(window, '_filter_display_descriptors', return_value=descriptors):
        expected = flow._validation_pool_for_session(session, incoming, target_count=1900)
        expected = expected.get('display_candles', expected['candles'])[-1000:]
        assert flow._use_pool_for_history_browse(window, session, incoming, evaluation_count=100)
        wait_for(case, lambda: bool(payloads or failures))
        assert not failures
        assert not payloads[0].get('requires_full_revalidation')
        assert window._candles == expected
        assert window.replay_snapshot is before[0]
        assert window._validation_range_times == before[1]
        assert [e.evaluation_time for e in window._range_replay_calculation_entries] == [e.evaluation_time for e in before[2]]
        assert window._marking_cache is before[3]
        assert session.request.settings_snapshot.rules_hash == before[4]
        indexes = window._chart_calculation_indexes
        first = next(i for i, index in enumerate(indexes) if index is not None)
        assert indexes[first] >= fm.required_validation_history_context_bars(rules)
        reference = build_validation_indicator_cache(window._calculation_candles, rules, descriptors)
        for identity, channel, values in window.visualization_cache.series:
            assert values[first] is not None, (identity, channel)
            assert values[first] == pytest.approx(reference.values_for(identity, channel)[indexes[first]])
        for row, index in zip(window._candles, indexes):
            if index is not None:
                assert row == window._calculation_candles[index]
        if regular is False:
            assert window._candles[0] == nxt
            assert indexes[0] is None
            assert nxt not in window._calculation_candles
        assert not flow._active_providers
        flow._replay_factory.assert_not_called()
        assert bool(requests) == (source == 'provider')


def test_exhausted_manual_browse_preserves_chart_and_reports_deficit(case):
    rows, window, flow, session, pool, _ = selected(case)
    before = (deepcopy(window._candles), window.replay_snapshot, window._validation_range_times)
    failures, requests = [], []
    flow.validation_failed.connect(failures.append)

    class Provider:
        def __init__(self, *args):
            pass
        def request_latest(self, count, callback):
            requests.append(count)
            callback(_result(case.stock, 3, pool['candles'], market_data_identity='005930', market_source='KRX'))

    flow._historical_provider_factory = Provider
    flow._history_targets[id(window)] = 1000
    with patch.object(flow, '_cached_history', return_value=None):
        flow._use_pool_for_history_browse(window, session, pool, evaluation_count=100)
    assert len(requests) == 1
    assert failures and 'HISTORY_BROWSE_WARMUP_INSUFFICIENT: missing=' in str(failures)
    assert window._candles == before[0]
    assert window.replay_snapshot is before[1]
    assert window._validation_range_times == before[2]
    assert not flow._active_providers
    flow._replay_factory.assert_not_called()


@pytest.mark.parametrize('stale', [False, True])
def test_history_extension_entry_and_late_warmup_result(case, stale):
    rows, window, flow, session, pool, _ = selected(case)
    key = id(window)
    callbacks, failures = [], []
    flow.validation_failed.connect(failures.append)
    flow._last_run_requests[key] = fm.IndicatorFollowSignalValidationRunRequest(
        session.request.settings_snapshot, 100)

    class Provider:
        def __init__(self, *args):
            pass
        def request_latest(self, count, callback):
            callbacks.append((count, callback))

    flow._historical_provider_factory = Provider
    before = deepcopy(window._candles)
    snapshot = window.replay_snapshot
    with patch.object(flow, '_cached_history', return_value=None), \
         patch.object(flow, '_ensure_integrated_display_sidecar'):
        flow._request_history_extension(window)
        wait_for(case, lambda: bool(callbacks or failures))
        assert not failures
        assert flow._history_targets[key] == 750
        if stale:
            flow._invalidate_window_requests(key)
        while callbacks:
            count, callback = callbacks.pop(0)
            callback(_result(case.stock, 3, rows[-count:], market_data_identity='005930', market_source='KRX'))
            case.app.processEvents()
            if not stale:
                wait_for(case, lambda: bool(callbacks or failures) or key not in flow._history_extension_inflight)
        assert not failures
        if stale:
            assert window._candles == before
        else:
            assert len(window._candles) > len(before)
            assert next(i for i in window._chart_calculation_indexes if i is not None) >= 900
            assert window.replay_snapshot is snapshot
        flow._replay_factory.assert_not_called()


@pytest.mark.parametrize('regular', [True, False])
def test_history_browse_pending_range_replay_keeps_hidden_warmup(case, regular):
    """A committed range awaiting replay must not bypass history-browse warmup."""
    rows, window, flow, session, old_pool, rules = selected(case, regular)
    key = id(window)
    prior_snapshot = window.replay_snapshot
    prior_range = window._validation_range_times
    assert prior_snapshot is not None and prior_range is not None
    assert not window._normal_base_ready
    window._clear_range_replay_override()  # Re-selection: evidence pending.
    assert not window._range_replay_entries_available

    incoming = flow._pool_from_candles(
        session, rows[-1400:], requested_count=1400,
        request_id='PENDING', market_data_identity='005930', market_source='KRX')
    entry = fm.ValidationHistoricalCacheEntry(
        '005930', case.stock.name, 3, 'M3', 2900,
        tuple(rows), '', '005930', 'KRX')
    flow._history_targets[key] = 1000
    failures, payloads = [], []
    flow.validation_failed.connect(failures.append)
    flow.history_browse_completed.connect(payloads.append)
    with patch.object(flow, '_cached_history', return_value=entry), \
         patch.object(flow, '_historical_provider_factory',
                      side_effect=AssertionError('cache must satisfy warmup')):
        assert flow._use_pool_for_history_browse(
            window, session, incoming, evaluation_count=100)
        wait_for(case, lambda: bool(payloads or failures))
        case.app.processEvents()
    assert not failures
    assert 0 < len(window._candles) <= 1000
    assert window._chart_calculation_indexes[0] >= fm.required_validation_history_context_bars(rules)
    assert window.replay_snapshot is prior_snapshot
    assert window._validation_range_times == prior_range
    flow._replay_factory.assert_not_called()

@pytest.mark.parametrize('clear_action', ['range', 'reset'])
def test_normal_period_clear_then_history_browse_stays_uncalculated(case, clear_action):
    """Browsing after clearing a local range must not publish a full replay."""
    rows = archive_rows()
    window, flow, session, pool, rules, replay = flow_case(
        case, rows[-1150:], count=250, regular=True)
    window._marking_current_settings = lambda: session.request.settings_snapshot
    key = id(window)
    flow._historical_pools[key] = pool
    flow._validation_sessions[key] = session
    flow._history_targets[key] = 250
    flow._replay_factory = legacy.ValidationHistoricalReplay
    window.set_historical_candle_pool(pool['candles'], chart_candle_count=250)
    view = flow._validation_pool_for_session(session, pool, target_count=1150)
    window.set_historical_display_candles(view['display_candles'][-250:])
    window.install_normal_base(session.request.settings_snapshot, 'M3')
    window.validation_range_evaluation_requested.connect(
        lambda start, end: flow._run_cached_range_replay(window, start, end))
    assert not window.canvas.marker_records()
    full = flow._prepare_replay_result_from_pool(
        session, pool, history_target=250, evaluation_count=250)
    display_indexes = {row['time']: index for index, row in enumerate(window._candles)}
    signal_index = next(display_indexes[entry.evaluation_time]
                        for entry in full.snapshot.to_entries()
                        if entry.signal == entry.evaluation_side
                        and entry.evaluation_time in display_indexes)
    window._complete_validation_range_drag(max(0, signal_index - 2),
                                           min(len(window._candles) - 1, signal_index + 2))
    wait_for(case, lambda: window._range_replay_entries_available)
    assert window.canvas.marker_records()
    if clear_action == 'reset':
        assert window.reset_chart_view()
    else:
        window._clear_validation_range_interaction()
    assert window.validation_range is None
    assert not window.canvas.marker_records()
    assert window._normal_base_requested
    assert window._normal_base_ready
    assert window.replay_snapshot is None
    assert not window.completed_cycles

    incoming = flow._pool_from_candles(
        session, rows, requested_count=len(rows),
        request_id='NORMAL_AFTER_CLEAR', market_data_identity='005930',
        market_source='KRX')
    failures = []
    flow.validation_failed.connect(failures.append)
    flow._replay_factory = Mock(side_effect=AssertionError('unrequested full replay'))
    with patch.object(flow, '_persist_history', return_value=True):
        assert flow._use_pool_for_history_browse(
            window, session, incoming, evaluation_count=100)
        wait_for(case, lambda: window._normal_base_ready and
                 not flow._prepare_active.get(key))
    assert not failures
    assert flow._historical_pools[key] is incoming
    assert window.replay_snapshot is None
    assert window._normal_base_requested and window._normal_base_ready
    assert not window.canvas.marker_records()
    flow._replay_factory.assert_not_called()

def test_new_validation_request_supersedes_normal_range_restore(case):
    """Accepted full validation request supersedes pending normal-origin range cleanup."""
    rows = archive_rows()
    window, flow, session, pool, _, _ = flow_case(
        case, rows[-1150:], count=250, regular=True)
    key = id(window)
    flow._historical_pools[key] = pool
    flow._validation_sessions[key] = session
    flow._history_targets[key] = 250
    flow._replay_factory = legacy.ValidationHistoricalReplay
    window.set_historical_candle_pool(pool['candles'], chart_candle_count=250)
    view = flow._validation_pool_for_session(session, pool, target_count=1150)
    window.set_historical_display_candles(view['display_candles'][-250:])
    window.install_normal_base(session.request.settings_snapshot, 'M3')
    window.validation_range_evaluation_requested.connect(
        lambda start, end: flow._run_cached_range_replay(window, start, end))
    window._complete_validation_range_drag(210, 234)
    wait_for(case, lambda: window._range_replay_entries_available)
    assert window._range_replay_from_normal_base
    requests = []
    window.validation_run_requested.connect(requests.append)
    assert window._request_validation() is not None
    assert len(requests) == 1
    assert not window._range_replay_from_normal_base
    window._clear_validation_range_interaction()
    assert window.validation_range is None
    assert not window._normal_base_requested
    assert window.replay_snapshot is not None

def test_full_validation_baseline_survives_local_range_clear(case):
    """A genuine full validation must never be downgraded to an uncalculated chart."""
    rows = archive_rows()
    window, flow, session, pool, _, _ = flow_case(
        case, rows[-1150:], count=250, regular=True)
    key = id(window)
    flow._historical_pools[key] = pool
    flow._validation_sessions[key] = session
    flow._history_targets[key] = 250
    flow._replay_factory = legacy.ValidationHistoricalReplay
    window.set_historical_candle_pool(pool['candles'], chart_candle_count=250)
    view = flow._validation_pool_for_session(session, pool, target_count=1150)
    window.set_historical_display_candles(view['display_candles'][-250:])
    window.install_normal_base(session.request.settings_snapshot, 'M3')
    full = flow._prepare_replay_result_from_pool(
        session, pool, history_target=250, evaluation_count=100)
    assert full.ok and full.snapshot is not None
    window.set_replay_snapshot(full.snapshot)
    baseline = list(window._entries), list(window._calculation_entries)
    assert baseline[0] and baseline[1]
    assert not window._range_replay_from_normal_base
    window.validation_range_evaluation_requested.connect(
        lambda start, end: flow._run_cached_range_replay(window, start, end))
    window._complete_validation_range_drag(210, 234)
    wait_for(case, lambda: window._range_replay_entries_available)
    window._clear_validation_range_interaction()
    assert window.validation_range is None
    assert not window._normal_base_requested
    assert not window._range_replay_from_normal_base
    assert (window._entries, window._calculation_entries) == baseline
