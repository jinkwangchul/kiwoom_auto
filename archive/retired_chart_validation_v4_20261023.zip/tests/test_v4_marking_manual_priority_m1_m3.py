# -*- coding: utf-8 -*-
"""Manual selected-range signals override frozen marking visually, on M1/M3."""
from datetime import datetime, timedelta
from PyQt5.QtCore import QSignalBlocker
import pytest

from tests.test_indicator_follow_signal_validation_v4_marking import (
    connected, position_evaluator, turn_on,
)
from tests.test_indicator_follow_signal_validation_v4_normal_base import (
    case, legacy, wait_for,
)


@pytest.mark.parametrize("minutes", (1, 3))
def test_marking_on_then_manual_range_shows_new_markers_without_overlap(
    case, minutes,
):
    window, flow = connected(case, evaluator=position_evaluator)
    with QSignalBlocker(window.basic_signal_interval_combo):
        window.basic_signal_interval_combo.setCurrentText(f"{minutes}분")
    start = datetime(2026, 10, 7, 9, 0)
    rows = []
    for index in range(100):
        stamp = (start + timedelta(minutes=index * minutes)).strftime(
            "%Y%m%d%H%M%S"
        )
        price = float(100_000 + index % 17 * 100)
        rows.append(dict(
            time=stamp, open=price, high=price + 200.,
            low=price - 100., close=price + 100., volume=1.,
        ))
    settings = window._marking_current_settings()
    session = legacy.ValidationSession(legacy.ValidationRequest(
        case.stock, settings, minutes,
    ), operation_active_reader=lambda: False)
    flow._validation_sessions[id(window)] = session
    flow._historical_pools[id(window)] = flow._pool_from_candles(
        session, rows, requested_count=100,
        request_id=f"M{minutes}_SOURCE",
        market_data_identity=case.stock.code, market_source="KRX",
    )
    window.set_historical_candle_pool(rows, chart_candle_count=100)
    window.install_normal_base(settings, f"M{minutes}")
    window._set_time_view(40, 30)
    turn_on(case, window)
    initial = window.canvas.marker_records()
    assert {(m["evaluation_index"], m["side"]) for m in initial} == {
        (42, "BUY"), (45, "BUY"), (55, "SELL"),
    }

    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    case.app.processEvents()
    records = window.canvas.marker_records()
    assert window.validation_range == (44, 56)
    assert window.marking_display_check.isChecked()
    # Before this fix, same-bar BUY/SELL each appeared twice and the older
    # marking's tooltip hid the independent manual execution quantities.
    assert {(m["evaluation_index"], m["side"], m["provenance"])
            for m in records} == {
        (42, "BUY", "marking"),
        (45, "BUY", "manual"),
        (55, "SELL", "manual"),
    }
    assert len(records) == 3
    assert len(window.completed_cycles) == 1
    assert "1차" in next(
        m["tooltip"] for m in records if m["evaluation_index"] == 45
    )
    frozen = window._validation_range_times
    window._set_time_view(38, 24)
    case.app.processEvents()
    assert window._validation_range_times == frozen
    assert len(window.canvas.marker_records()) == 3

    # Turning OFF marking must not clear manual independent evidence.
    window.marking_display_check.setChecked(False)
    assert window.validation_range == (44, 56)
    assert {(m["evaluation_index"], m["provenance"])
            for m in window.canvas.marker_records()} == {
        (45, "manual"), (55, "manual"),
    }

    # Turning marking ON again resets the manual period by the existing UI
    # contract; all 3 frozen marking signals must return.
    turn_on(case, window)
    assert window.validation_range is None
    assert {(m["evaluation_index"], m["provenance"])
            for m in window.canvas.marker_records()} == {
        (42, "marking"), (45, "marking"), (55, "marking"),
    }
