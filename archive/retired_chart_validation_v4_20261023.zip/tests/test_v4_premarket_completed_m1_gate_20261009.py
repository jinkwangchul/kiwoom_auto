# -*- coding: utf-8 -*-
"""Read-only replay fixture: live NXT PRE only from completed M1 authority."""
from datetime import datetime, timedelta

import pytest

from tests.test_indicator_follow_signal_validation_v4_normal_base import case, legacy
from tests.test_indicator_follow_signal_validation_v4_warmup_legend import flow_case
from gui_indicator_follow_signal_validation_v4_flow import IndicatorFollowSignalValidationV4Flow
from indicator_follow_validation_timeframe import normalize_validation_timeframe


def sample(case, minutes, clock="0800"):
    rows = [
        {"time": "20261007090000", "open": 100., "high": 101., "low": 99., "close": 100., "volume": 1},
        {"time": "20261008090000", "open": 101., "high": 102., "low": 100., "close": 101., "volume": 1},
    ]
    _, _, _, _, rules, _ = flow_case(case, rows, count=2, regular=False)
    rules["bar"]["bar_minutes"] = minutes
    rules["validation_timeframe"] = normalize_validation_timeframe(minutes)
    settings = legacy.ValidationSettingsSnapshot(rules)
    session = legacy.ValidationSession(
        legacy.ValidationRequest(case.stock, settings, minutes),
        operation_active_reader=lambda: False,
    )
    row = dict(rows[-1], time="20261009" + clock + "00")
    sidecar = dict(
        stock_code=case.stock.code, timeframe_key=f"M{minutes}",
        timeframe_minutes=minutes,
        market_data_identity=f"{case.stock.code}_AL",
        market_source="INTEGRATED", display_only=True,
        verified_nxt_eligible=True, candles=[row],
    )
    return session, sidecar, row


@pytest.mark.parametrize("minutes", (1, 3, 5, 10, 15, 30, 60, 120, 240))
def test_partial_target_at_080030_must_not_be_promoted(case, minutes):
    session, sidecar, row = sample(case, minutes)
    sidecar["request_as_of"] = "2026-10-09T08:00:30+09:00"
    assert IndicatorFollowSignalValidationV4Flow._verified_validation_premarket_candles(
        session, sidecar,
    ) == []
    sidecar["request_as_of"] = "2026-10-09T08:01:00+09:00"
    admitted = IndicatorFollowSignalValidationV4Flow._verified_validation_premarket_candles(
        session, sidecar,
    )
    assert admitted == ([row] if minutes == 1 else [])


@pytest.mark.parametrize("minutes,clock", (
    (3,"0848"), (5,"0845"), (10,"0840"), (15,"0845"),
    (30,"0830"), (60,"0800"), (120,"0800"), (240,"0800"),
))
def test_last_short_bucket_respects_0850_session_end(case, minutes, clock):
    session, sidecar, row = sample(case, minutes, clock)
    sidecar["request_as_of"] = "2026-10-09T08:49:59+09:00"
    assert IndicatorFollowSignalValidationV4Flow._verified_validation_premarket_candles(
        session, sidecar,
    ) == []
    sidecar["request_as_of"] = "2026-10-09T08:50:00+09:00"
    assert IndicatorFollowSignalValidationV4Flow._verified_validation_premarket_candles(
        session, sidecar,
    ) == [row]


def test_open_target_premarket_remains_displayable_but_not_a_filter_input(case):
    from copy import deepcopy

    history = [
        dict(time="20261007090000", open=100., high=101.,
             low=99., close=100., volume=1),
        dict(time="20261008090000", open=101., high=102.,
             low=100., close=101., volume=1),
    ]
    window, flow, session, pool, _rules, _ = flow_case(
        case, history, count=2, regular=False,
    )
    origin = deepcopy(pool["candles"])
    _session, sidecar, row = sample(case, 3)
    sidecar["candles"] = [*history, row]
    sidecar["request_as_of"] = "2026-10-09T08:00:30+09:00"
    flow._integrated_display_sidecars[
        flow._integrated_display_sidecar_key(session)
    ] = sidecar
    view = flow._validation_pool_for_session(session, pool, target_count=8)
    assert all(item["time"] != row["time"] for item in view["candles"])
    assert any(item["time"] == row["time"] for item in view["display_candles"])
    assert pool["candles"] == origin

