"""V4 hidden history and comparison legends; archive reads and fake providers only."""
from datetime import datetime, timedelta
import json
from pathlib import Path
from unittest.mock import Mock, patch

import pytest

from tests.test_indicator_follow_signal_validation_v4_normal_base import (
    case, window_for, install, candles, wait_for, legacy, wm, fm,
)
from tests.test_indicator_follow_signal_validation_persistent_history_flow import _result
from tests.test_indicator_follow_signal_validation_v4_marking import connected, turn_on
from indicator_follow_signal_validation_visualization import build_validation_indicator_cache


def archive_rows():
    path = Path(__file__).resolve().parents[1] / "runtime/signal_validation_v2_history_cache/005930_3_2900.json"
    return json.loads(path.read_text(encoding="utf-8"))["candles"]


def descriptor(identity, family, channels, parameters, axis="PRICE"):
    return wm.ValidationFilterDescriptor(identity, family, identity, axis, ("BUY", "SELL"),
                                         channels, json.dumps(parameters), ())


def indicators():
    return (
        descriptor("ma", "MOVING_AVERAGE", ("MA50", "MA200", "MA600"), {"periods": [50, 200, 600]}),
        descriptor("box", "PRICE_BOX", ("CRITERION",),
                   {"period": 24, "condition": {"compare_target": "PRICE_BOX_LOWER"}}),
        descriptor("rsi", "RSI", ("RSI",), {"period": 14}, "LOWER"),
        descriptor("macd", "MACD_SIGNAL", ("MACD", "SIGNAL"),
                   {"fast": 12, "slow": 26, "signal": 9}, "LOWER"),
        descriptor("osc", "OCR_OSC", ("OSC",),
                   {"fast": 12, "slow": 26, "signal": 9}, "LOWER"),
    )


def flow_case(case, rows, count=500, regular=True, provider=None):
    window = window_for(case)
    rules = window._signal_validation_seed.settings_snapshot.to_dict()
    rules["bar"]["bar_minutes"] = 3
    rules["validation_timeframe"] = fm.normalize_validation_timeframe(3)
    rules["validation_market_scope"] = {"regular_market_only": regular}
    rules["indicators"]["moving_averages"] = [50, 200, 600]
    rules["indicators"]["price_box"] = {"period": 24}
    settings = legacy.ValidationSettingsSnapshot(rules)
    session = legacy.ValidationSession(legacy.ValidationRequest(case.stock, settings, 3),
                                       operation_active_reader=lambda: False)
    replay = Mock(side_effect=AssertionError("normal chart must not evaluate signals"))
    flow = fm.IndicatorFollowSignalValidationV4Flow(
        object(), host=legacy._FakeHost(case.stock), historical_count=count,
        historical_cache=case.default_history_cache, replay_factory=replay,
        historical_provider_factory=provider or Mock(side_effect=AssertionError("no provider expected")),
    )
    flow._open_windows[id(window)] = window
    flow._request_generation[id(window)] = 0
    pool = flow._pool_from_candles(session, rows, requested_count=len(rows), request_id="WARMUP",
                                   market_data_identity="005930", market_source="KRX")
    return window, flow, session, pool, rules, replay


@pytest.mark.parametrize("source_count", [550, 1400])
def test_archive_regular_display_reserves_hidden_context_before_first_candle(case, source_count):
    rows = archive_rows()
    window, flow, session, pool, rules, replay = flow_case(case, rows[-source_count:])
    old_view = flow._validation_pool_for_session(session, pool, target_count=1400)
    display = old_view["display_candles"][-500:]
    old_indexes = wm._calculation_indexes_for_display(old_view["candles"], display)
    assert old_indexes[0] < fm.required_validation_history_context_bars(rules)
    # Archive contents vary over time; the expanded display still lacks the required hidden prefix.
    expanded = flow._pool_from_candles(
        session, rows, requested_count=2900, request_id="ARCHIVE",
        market_data_identity="005930", market_source="KRX",
    )
    old_expanded = flow._validation_pool_for_session(session, expanded, target_count=2900)
    expanded_display = old_expanded["display_candles"][-2000:]
    assert (wm._calculation_indexes_for_display(rows, expanded_display)[0]
            < fm.required_validation_history_context_bars(rules))
    entry = fm.ValidationHistoricalCacheEntry("005930", case.stock.name, 3, "M3", 2900,
                                              tuple(rows), "", "005930", "KRX")
    descriptors = indicators()
    if source_count == 550:
        before, _ = wm._build_validation_projection_data(
            old_view["candles"], [], [], old_indexes, rules, descriptors)
        assert before.values_for("ma", "MA600")[0] is None
        assert before.values_for("box", "CRITERION")[0] is None
        assert before.values_for("rsi", "RSI")[0] is None
    with patch.object(flow, "_cached_history", return_value=entry), \
            patch.object(window, "_filter_display_descriptors", return_value=descriptors), \
            patch.object(fm, "_build_validation_projection_data", wraps=wm._build_validation_projection_data) as project:
        flow._use_pool_for_window(window, session, pool, evaluation_count=100)
        wait_for(case, lambda: window._normal_base_ready)
        calculation, entries, _, indexes, *_ = project.call_args.args
        assert not entries
        assert indexes[0] >= fm.required_validation_history_context_bars(rules)
        assert window._candles == display
        assert window._chart_calculation_indexes == indexes
        assert window._visible_candle_span == 250
        reference = build_validation_indicator_cache(rows, rules, descriptors)
        first = next(i for i, c in enumerate(rows) if c["time"] == display[0]["time"])
        for identity, channel, values in window.visualization_cache.series:
            assert values[0] is not None, (identity, channel)
            assert values[0] == pytest.approx(reference.values_for(identity, channel)[first])
        closes = [c["close"] for c in rows]
        for period in (50, 200, 600):
            assert window.visualization_cache.values_for("ma", f"MA{period}")[0] == pytest.approx(
                sum(closes[first - period + 1:first + 1]) / period)
        # Painter receives the same complete series, including at the left edge after pan.
        window._set_time_view(0, 250)
        assert window.canvas._cached_values(descriptors[0], "MA600")[0] is not None
    replay.assert_not_called()
    flow._historical_provider_factory.assert_not_called()


def test_full_source_is_not_truncated_before_regular_display_warmup(case):
    rows = archive_rows()
    window, flow, session, pool, rules, _ = flow_case(case, rows)
    view, deficit = flow._normal_base_history_view(session, pool, 500)
    indexes = wm._calculation_indexes_for_display(view["candles"], view["display_candles"])
    assert deficit == 0
    assert indexes[0] == fm.required_validation_history_context_bars(rules)
    assert view["display_candles"] == wm._krx_regular_session_candles(rows[-1400:])[-500:]


@pytest.mark.parametrize("regular", [True, False])
@pytest.mark.parametrize("path", ["worker", "legacy"])
def test_range_replay_retains_normal_indicator_prefix_and_local_evidence(case, regular, path):
    rows = archive_rows()
    window, flow, session, pool, rules, _ = flow_case(case, rows, regular=regular)
    rules["validation_execution"] = {"enabled": True, "first_buy_quantity": 2}
    session = legacy.ValidationSession(
        legacy.ValidationRequest(case.stock, legacy.ValidationSettingsSnapshot(rules), 3),
        operation_active_reader=lambda: False)
    flow._replay_factory = legacy.ValidationHistoricalReplay
    source = pool["candles"]
    source_before = [dict(c) for c in source]
    display = wm._krx_regular_session_candles(rows[-1400:])[-500:]
    if not regular:
        stamp = datetime.strptime(display[1]["time"], "%Y%m%d%H%M%S") - timedelta(seconds=1)
        nxt = dict(display[0], time=stamp.strftime("%Y%m%d%H%M%S"), close=999999)
        display = [nxt] + display[1:]
    with patch.object(flow, "_integrated_display_candles_for_session",
                      return_value=None if regular else display):
        normal, deficit = flow._normal_base_history_view(session, pool, 500)
        assert deficit == 0
        if regular:
            assert normal["display_candles"][0]["time"] == display[0]["time"]
        window.set_historical_candle_pool(normal["candles"], chart_candle_count=500)
        window.set_historical_display_candles(display, display_only_integrated=not regular)
        window.install_normal_base(session.request.settings_snapshot, "M3")
        window._set_validation_range(0, 12)
        # The explicit normal view is the reference; evaluation starts only at the selection.
        expected = flow._prepare_replay_result_from_pool(
            session, pool, history_target=500, chart_range=(0, 12), prepared_view_pool=normal)
        window.apply_range_replay_snapshot(expected.snapshot)
        expected_cycles = window.completed_cycles
        expected_pnl = window.estimated_return_label.text()
        assert expected_cycles
        if path == "worker":
            result = flow._prepare_replay_result_from_pool(
                session, pool, history_target=500, chart_range=(0, 12),
                chart_range_times=(display[0]["time"], display[12]["time"]))
            snapshot = result.snapshot
            window.apply_range_replay_snapshot(snapshot)
        else:
            flow._replay_from_pool(window, session, pool, chart_range=(0, 12))
            snapshot = window.replay_snapshot
    assert snapshot is not None
    actual = snapshot.to_candles()
    assert actual == expected.snapshot.to_candles()
    assert snapshot.to_entries() == expected.snapshot.to_entries()
    assert {e.signal for e in snapshot.to_entries()} >= {"BUY", "SELL"}
    assert window.completed_cycles == expected_cycles
    assert window.estimated_return_label.text() == expected_pnl
    first_context = snapshot.to_entries()[0].trace["evaluation_context"]
    assert first_context["position_quantity"] == 0
    assert first_context["contributing_buy_indexes"] == []
    assert snapshot.timeframe_key == "M3"
    assert snapshot.evaluated_start_index == expected.snapshot.evaluated_start_index == 900
    assert snapshot.evaluated_end_index == expected.snapshot.evaluated_end_index
    assert all(e.evaluation_index >= 900 for e in snapshot.to_entries())
    reference = build_validation_indicator_cache(normal["candles"], rules, indicators())
    replay_cache = build_validation_indicator_cache(actual, rules, indicators())
    for identity, channel, values in replay_cache.series:
        assert values[900] is not None, (identity, channel)
        assert values[900:] == reference.values_for(identity, channel)[900:len(actual)]
    assert window._candles == display
    assert window._validation_range_times == (display[0]["time"], display[12]["time"])
    for entry in window._range_replay_calculation_entries:
        assert window._calculation_candles[entry.evaluation_index]["time"] == entry.evaluation_time
    if not regular:
        assert window._chart_calculation_indexes[0] is None
        assert nxt not in actual
    assert pool["candles"] is source and source == source_before


@pytest.mark.parametrize("path", ["worker", "legacy"])
def test_range_replay_rejects_raw_m1_as_m3_before_evaluation(case, path):
    window, flow, session, pool, _, replay = flow_case(case, archive_rows())
    pool.update(timeframe_minutes=1, timeframe_key="M1")
    failures = []
    flow.validation_failed.connect(failures.append)
    if path == "worker":
        with pytest.raises(ValueError, match="RANGE_REPLAY_SOURCE_TIMEFRAME_MISMATCH"):
            flow._prepare_replay_result_from_pool(
                session, pool, history_target=500, chart_range=(0, 12))
    else:
        flow._replay_from_pool(window, session, pool, chart_range=(0, 12))
        assert failures and "RANGE_REPLAY_SOURCE_TIMEFRAME_MISMATCH" in failures[-1]
    assert window.replay_snapshot is None
    replay.assert_not_called()


def test_range_replay_accepts_completed_production_m3_not_raw_minute_counts(case):
    raw = []
    for day in range(12):
        start = datetime(2026, 9, 1, 8) + timedelta(days=day)
        for minute in range(720):
            price = 10000 + len(raw)
            raw.append(dict(time=(start + timedelta(minutes=minute)).strftime("%Y%m%d%H%M%S"),
                            open=price, high=price + 2, low=price - 1, close=price + 1, volume=1))
    contract = dict(status="PRODUCTION_SESSION_READY", ready=True,
                    session_windows=[dict(name="regular", start_time="08:00:00", end_time="20:00:00")])
    projected = fm.project_production_calculation_candles(
        raw, 3, contract, as_of=datetime(2026, 10, 8))
    rows = projected["candles"]
    assert len(raw) == 8640 and len(rows) == 2880
    assert rows[0]["time"] == "20260901080000"
    assert (rows[0]["open"], rows[0]["close"], rows[0]["volume"]) == (10000, 10003, 3)
    _, flow, session, pool, rules, _ = flow_case(case, rows)
    pool.update(source_timeframe_key="M1", source_timeframe_minutes=1,
                calculation_source="PRODUCTION_M1_SESSION_AGGREGATION")
    flow._replay_factory = legacy.ValidationHistoricalReplay
    normal, deficit = flow._normal_base_history_view(session, pool, 500)
    assert deficit == 0
    result = flow._prepare_replay_result_from_pool(
        session, pool, history_target=500, chart_range=(0, 2))
    snapshot = result.snapshot
    assert snapshot.timeframe_key == "M3" and snapshot.evaluated_start_index == 900
    actual = snapshot.to_candles()
    assert [c["time"] for c in actual] == [c["time"] for c in normal["candles"][:903]]
    assert [c["close"] for c in actual] == [c["close"] for c in normal["candles"][:903]]
    reference = build_validation_indicator_cache(normal["candles"], rules, indicators())
    cache = build_validation_indicator_cache(actual, rules, indicators())
    for identity, channel, values in cache.series:
        assert values[900:] == reference.values_for(identity, channel)[900:903]
    assert pool["source_timeframe_key"] == "M1" and pool["candles"] == rows


@pytest.mark.parametrize("cancel", [False, True])
def test_range_after_warm_provider_uses_installed_context_and_rejects_stale_result(case, cancel):
    rows = archive_rows()
    callbacks = []

    class Provider:
        def __init__(self, *args):
            pass

        def request_latest(self, count, callback):
            callbacks.append((count, callback))

    window, flow, session, pool, _, replay = flow_case(case, rows[-1400:], provider=Provider)
    window._marking_current_settings = lambda: session.request.settings_snapshot
    with patch.object(flow, "_cached_history", return_value=None):
        flow._use_pool_for_window(window, session, pool, evaluation_count=100)
    assert len(callbacks) == 1 and not window._normal_base_ready
    if cancel:
        flow._invalidate_window_requests(id(window))
    count, callback = callbacks[0]
    callback(_result(case.stock, 3, rows[-count:], market_data_identity="005930", market_source="KRX"))
    if cancel:
        case.app.processEvents()
        assert not window._normal_base_ready and window.replay_snapshot is None
        replay.assert_not_called()
        return
    wait_for(case, lambda: window._normal_base_ready)
    calculation = [dict(c) for c in window._calculation_candles]
    installed_pool = flow._historical_pools[id(window)]
    failures = []
    flow.validation_failed.connect(failures.append)
    flow._replay_factory = legacy.ValidationHistoricalReplay
    window.validation_range_evaluation_requested.connect(
        lambda start, end: flow._run_cached_range_replay(window, start, end))
    window._complete_validation_range_drag(0, 2)
    wait_for(case, lambda: window._range_replay_entries_available or failures)
    assert not failures
    assert window.replay_snapshot.to_candles() == calculation[:window.replay_snapshot.evaluated_end_index + 1]
    assert window.replay_snapshot.evaluated_start_index == 900
    assert flow._historical_pools[id(window)] is installed_pool
    assert window._calculation_candles == calculation
    assert not flow._active_providers


def test_range_with_exhausted_history_keeps_missing_indicator_values(case):
    rows = candles(100)
    window, flow, session, pool, rules, _ = flow_case(case, rows, count=100)
    normal, deficit = flow._normal_base_history_view(session, pool, 100)
    assert deficit == 900
    flow._replay_factory = legacy.ValidationHistoricalReplay
    result = flow._prepare_replay_result_from_pool(
        session, pool, history_target=100, chart_range=(0, 2))
    assert result.snapshot.to_candles() == normal["candles"][:3]
    cache = build_validation_indicator_cache(result.snapshot.to_candles(), rules, indicators())
    assert cache.values_for("ma", "MA600") == (None, None, None)
    assert cache.values_for("box", "CRITERION") == (None, None, None)
    assert window.replay_snapshot is None


def test_range_missing_timestamp_and_cancelled_replay_never_publish(case):
    window, flow, session, pool, _, _ = flow_case(case, archive_rows())
    flow._replay_factory = legacy.ValidationHistoricalReplay
    with pytest.raises(ValueError, match="RANGE_REPLAY_TIMESTAMP_UNAVAILABLE"):
        flow._prepare_replay_result_from_pool(
            session, pool, history_target=500, chart_range=(0, 2),
            chart_range_times=("19990101090000", "19990101090300"))
    with pytest.raises(ValueError, match="CANCELLED"):
        flow._prepare_replay_result_from_pool(
            session, pool, history_target=500, chart_range=(0, 2), cancel_predicate=lambda: True)
    assert window.replay_snapshot is None


def test_missing_cache_backfills_through_normal_provider_without_signal_scan(case):
    rows = archive_rows()
    requests = []

    class Provider:
        def __init__(self, session, broker):
            self.session = session

        def request_latest(self, count, callback):
            requests.append(count)
            callback(_result(case.stock, 3, rows[-count:], market_data_identity="005930", market_source="KRX"))

    window, flow, session, pool, rules, replay = flow_case(case, rows[-1400:], provider=Provider)
    expected = wm._krx_regular_session_candles(rows[-1400:])[-500:]
    flow._use_pool_for_window(window, session, pool, evaluation_count=100)
    wait_for(case, lambda: window._normal_base_ready)
    assert len(requests) == 1 and requests[0] > 1400
    assert window._candles == expected
    assert window._chart_calculation_indexes[0] >= fm.required_validation_history_context_bars(rules)
    assert not flow._active_providers
    replay.assert_not_called()


def test_exhausted_provider_stops_without_fabricating_history(case):
    rows = candles(100)
    requests = []

    class Provider:
        def __init__(self, session, broker):
            pass

        def request_latest(self, count, callback):
            requests.append(count)
            callback(_result(case.stock, 3, rows, market_data_identity="005930", market_source="KRX"))

    window, flow, session, pool, _, replay = flow_case(case, rows, count=100, provider=Provider)
    flow._use_pool_for_window(window, session, pool, evaluation_count=100)
    wait_for(case, lambda: window._normal_base_ready)
    assert len(requests) == 1
    assert window._calculation_candles == rows
    assert window._candles == wm._krx_regular_session_candles(rows)
    replay.assert_not_called()


def test_pending_warmup_provider_cannot_publish_after_generation_change(case):
    callbacks = []

    class Provider:
        def __init__(self, session, broker):
            pass

        def request_latest(self, count, callback):
            callbacks.append(callback)

    rows = candles(100)
    window, flow, session, pool, _, _ = flow_case(case, rows, count=100, provider=Provider)
    flow._use_pool_for_window(window, session, pool, evaluation_count=100)
    assert len(callbacks) == 1
    flow._invalidate_window_requests(id(window))
    callbacks[0](_result(case.stock, 3, rows, market_data_identity="005930", market_source="KRX"))
    case.app.processEvents()
    assert not window._normal_base_ready


def test_mixed_display_keeps_nxt_unmapped_and_krx_warmup(case):
    rows = archive_rows()
    window, flow, session, pool, _, replay = flow_case(case, rows, count=250, regular=False)
    stamp = datetime.strptime(rows[-249]["time"], "%Y%m%d%H%M%S") - timedelta(seconds=1)
    nxt = dict(rows[-249], time=stamp.strftime("%Y%m%d%H%M%S"), close=999999)
    display = [nxt] + rows[-249:]
    with patch.object(flow, "_integrated_display_candles_for_session", return_value=display):
        flow._use_pool_for_window(window, session, pool, evaluation_count=100)
        wait_for(case, lambda: window._normal_base_ready)
    assert window._candles == display
    assert window._chart_calculation_indexes[0] is None
    assert window._chart_calculation_indexes[1] >= 900
    assert nxt not in window._calculation_candles
    assert window._visible_candle_span == 250
    replay.assert_not_called()


def test_comparison_legends_have_swatches_and_interactions_when_all_values_masked(case):
    window = window_for(case)
    install(window)
    comparisons = {d.identity for d in window.visualization_descriptors if d.family == wm.FAMILY_PRICE_COMPARISON}
    assert comparisons
    assert window._filter_display_descriptors_for_selection(case.rules, True) == \
        window._all_filter_display_descriptors(case.rules)
    assert window._filter_display_descriptors_for_selection(case.rules, False) == ()
    for identity, _, values in window.visualization_cache.series:
        if identity in comparisons:
            assert all(v is None for v in values)
    records = [r for r in window.canvas.legend_records() if r["identity"] in comparisons]
    assert len(records) == len(comparisons)
    assert all(r["swatches"] for r in records)
    identity = records[0]["identity"]
    window.canvas._toggle_price_legend_identities("SELL", (identity,))
    assert ("SELL", identity) in window.canvas._highlighted_price_filter_identities
    assert identity in {r["identity"] for r in window.canvas.legend_records()}
    window.canvas._toggle_price_legend_identities("SELL", (identity,))
    window._set_time_view(0, 250)
    assert all(all(v is None for v in values) for i, _, values in window.visualization_cache.series if i in comparisons)


def test_avg_derived_criterion_is_manual_only_and_masks_survive_pan_and_filter(case):
    window, flow = connected(case)
    turn_on(case, window)
    price = descriptor("price", "PRICE_COMPARISON", ("CRITERION",),
                       {"condition": {"target": "SIGNAL_PRICE", "compare_target": "CLOSE"}})
    average = descriptor("average", "PRICE_COMPARISON", ("AVG_PRICE", "CRITERION"),
                         {"condition": {"target": "CLOSE", "compare_target": "AVG_PRICE"}})
    normal = indicators()[0]
    descriptors = (price, average, normal)
    values = tuple(float(i) for i in range(100))
    raw = wm.ValidationIndicatorSeriesCache(100, (("price", "CRITERION", values),
        ("average", "AVG_PRICE", values), ("average", "CRITERION", values), ("ma", "MA600", values)))
    window._marking_comparison_cache = (tuple(c["time"] for c in window._candles), raw)
    clipped = window._clip_comparison_cache(descriptors, raw)
    assert clipped.values_for("price", "CRITERION") == tuple(v if 40 <= i <= 69 else None for i, v in enumerate(values))
    assert all(v is None for v in clipped.values_for("average", "CRITERION"))
    window._set_validation_range(45, 55)
    window._set_time_view(0, 25)
    clipped = window._clip_comparison_cache(descriptors, raw)
    for channel in ("AVG_PRICE", "CRITERION"):
        assert clipped.values_for("average", channel) == tuple(v if 45 <= i <= 55 else None for i, v in enumerate(values))
    assert clipped.values_for("ma", "MA600") == values
    window._set_validation_range(None, None)
    window.filter_display_check.setChecked(False)
    wait_for(case, lambda: not window.visualization_descriptors)
    assert not window.visualization_cache.series
    assert raw.series[0][2] == values
