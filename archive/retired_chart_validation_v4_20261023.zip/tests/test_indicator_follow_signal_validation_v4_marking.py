"""V4 marking ownership, bounded replay and immutable display anchors."""
from copy import deepcopy
from dataclasses import replace
import json
from unittest.mock import Mock, patch

import pytest
from PyQt5.QtCore import QPoint, QSignalBlocker, Qt
from PyQt5.QtWidgets import QCheckBox, QLineEdit, QPushButton
from PyQt5.QtTest import QTest


from tests.test_indicator_follow_signal_validation_v4_normal_base import (
    case, window_for, install, candles, wait_for, legacy, wm, fm,
)


def connected(case, count=100, evaluator=None):
    window = window_for(case)
    rows = candles(count)
    install(window, rows)
    settings = window._marking_current_settings()
    window.install_normal_base(settings, "M1")
    session = legacy.ValidationSession(legacy.ValidationRequest(
        case.stock, settings, settings.to_dict()["bar"]["bar_minutes"],
    ), operation_active_reader=lambda: False)
    factory = (lambda s: legacy.ValidationHistoricalReplay(s, evaluator=evaluator)) if evaluator else legacy.ValidationHistoricalReplay
    flow = fm.IndicatorFollowSignalValidationV4Flow(
        object(), host=legacy._FakeHost(case.stock), replay_factory=factory,
        historical_cache=case.default_history_cache, historical_count=count,
    )
    if hasattr(flow, "_validation_source_by_code"):
        flow._validation_source_by_code[case.stock.code] = False
    key = id(window)
    flow._open_windows[key] = window
    flow._request_generation[key] = 0
    flow._history_targets[key] = count
    flow._validation_sessions[key] = session
    flow._historical_pools[key] = flow._pool_from_candles(
        session, rows, requested_count=count, request_id="MARKING",
        market_data_identity=case.stock.code, market_source="KRX",
    )
    window.marking_evaluation_requested.connect(lambda r: flow._start_marking(window, r))
    window.validation_range_evaluation_requested.connect(lambda a, b: flow._run_cached_range_replay(window, a, b))
    window._set_time_view(40, 30)
    return window, flow


def turn_on(case, window):
    window.marking_display_check.setChecked(True)
    wait_for(case, lambda: window._marking_snapshot is not None or not window.marking_display_check.isChecked())
    assert window._marking_snapshot is not None, window.marking_display_check.toolTip()
    return window._marking_snapshot


def connect_full_validation(window, flow):
    failures = []
    flow.validation_failed.connect(failures.append)
    window.chart_input_invalidated.connect(
        lambda: flow._invalidate_window_input(window)
    )
    window.validation_run_requested.connect(
        lambda request: flow._run_validation(window, request)
    )
    return failures


def test_not_halo_refresh_invalidates_raster_without_moving_period_or_view(case):
    window, _flow = connected(case)
    canvas = window.canvas
    window._set_validation_range(45, 55)
    period = canvas.validation_range
    view = (window.visible_start_index, window.visible_candle_span)
    canvas._static_chart_cache = object()
    canvas._static_chart_cache_key = ("warm",)

    canvas.set_not_filter_identities({("BUY", "owned")})

    assert canvas._static_chart_cache is None
    assert canvas._static_chart_cache_key is None
    assert canvas.validation_range == period
    assert (window.visible_start_index, window.visible_candle_span) == view


def test_series_tooltip_is_channel_value_only_and_keeps_real_parameters(case):
    window, _flow = connected(case)
    canvas = window.canvas

    def descriptor(identity, family, label, channel, parameters, sides=("BUY",)):
        return wm.ValidationFilterDescriptor(
            identity, family, label, wm.PRICE_AXIS, sides, (channel,),
            json.dumps(parameters), (),
        )

    ocr_buy = descriptor(
        "ocr-buy", wm.FAMILY_OCR_OSC, "BUY OCR above zero", "OSC",
        {"fast": 12, "slow": 26, "signal": 9},
    )
    ocr_sell = descriptor(
        "ocr-sell", wm.FAMILY_OCR_OSC, "SELL OCR below zero", "OSC",
        {"fast": 12, "slow": 26, "signal": 9}, ("SELL",),
    )
    assert canvas._series_tooltip_text(
        [ocr_buy, ocr_sell], "OSC", -808.0879,
    ) == "OCR(12,26,9): -808.0879"

    assert canvas._series_tooltip_text(
        [descriptor("rsi", wm.FAMILY_RSI, "RSI above 70", "RSI", {"period": 7})],
        "RSI", 42.5,
    ) == "RSI(7): 42.5"
    macd = descriptor(
        "macd", wm.FAMILY_MACD_SIGNAL, "MACD threshold", "MACD",
        {"fast": 5, "slow": 35, "signal": 4},
    )
    assert canvas._series_tooltip_text(
        [macd], "MACD", 12.5,
    ) == f"{canvas._series_channel_label('MACD')}(5,35,4): 12.5"
    assert canvas._series_tooltip_text(
        [macd], "SIGNAL", 10.25,
    ) == f"{canvas._series_channel_label('SIGNAL')}(5,35,4): 10.25"

    for family in (wm.FAMILY_MOVING_AVERAGE, wm.FAMILY_MA_ARRANGEMENT):
        assert canvas._series_tooltip_text(
            [descriptor("ma", family, "BUY MA criterion", "MA20", {"periods": [5, 20]})],
            "MA20", 101.25,
        ) == f"{canvas._series_channel_label('MA20')}: 101.25"
    assert canvas._series_tooltip_text(
        [descriptor("boll", wm.FAMILY_BOLLINGER, "BOLL", "UPPER", {"period": 22, "std": 2.5})],
        "UPPER", 103.0,
    ) == "볼린저밴드(22,2.5) 상단: 103"
    assert canvas._series_tooltip_text(
        [descriptor("box", wm.FAMILY_PRICE_BOX, "BOX", "HIGH", {"period": 17})],
        "HIGH", 104.0,
    ) == "가격박스(17) 상단: 104"
    for channel, line in (("MIDDLE", "중단"), ("LOWER", "하단")):
        assert canvas._series_tooltip_text(
            [descriptor("boll-raw", wm.FAMILY_BOLLINGER, "BOLL", channel,
                        {"period": 18, "std": 1.5})],
            channel, 102.25,
        ) == f"볼린저밴드(18,1.5) {line}: 102.25"
        assert canvas._series_tooltip_text(
            [descriptor("box-raw", wm.FAMILY_PRICE_BOX, "BOX", channel,
                        {"period": 24})],
            channel, 101.75,
        ) == f"가격박스(24) {line}: 101.75"

    assert canvas._series_tooltip_text(
        [descriptor("boll-upper", wm.FAMILY_BOLLINGER, "BOLL", "CRITERION", {
            "period": 20, "std": 2.0,
            "condition": {
                "compare_target": "BOLLINGER_UPPER",
                "value": -0.2,
                "signed_percent_offset": True,
            },
        })],
        "CRITERION", 241811.9,
    ) == "볼린저밴드(20,2.0) 상단 -0.2% 기준선: 241,811.9"
    assert canvas._series_tooltip_text(
        [descriptor("boll-lower", wm.FAMILY_BOLLINGER, "BOLL", "CRITERION", {
            "period": 21, "std": 2.25,
            "condition": {
                "compare_target": "BOLLINGER_LOWER",
                "value": 0.5,
                "signed_percent_offset": True,
            },
        })],
        "CRITERION", 98765.4321,
    ) == "볼린저밴드(21,2.25) 하단 +0.5% 기준선: 98,765.43"
    assert canvas._series_tooltip_text(
        [descriptor("box-upper", wm.FAMILY_PRICE_BOX, "BOX", "CRITERION", {
            "period": 24,
            "condition": {"compare_target": "PRICE_BOX_UPPER"},
        })],
        "CRITERION", 101.2,
    ) == "가격박스(24) 상단 기준선: 101.2"
    assert canvas._series_tooltip_text(
        [descriptor("box-lower", wm.FAMILY_PRICE_BOX, "BOX", "CRITERION", {
            "period": 30,
            "condition": {
                "compare_target": "PRICE_BOX_LOWER",
                "value": -1.25,
                "signed_percent_offset": True,
            },
        })],
        "CRITERION", 99.125,
    ) == "가격박스(30) 하단 -1.25% 기준선: 99.125"
    assert canvas._series_tooltip_text(
        [descriptor("boll-unknown", wm.FAMILY_BOLLINGER, "BOLL", "CRITERION", {
            "period": 19, "std": 3.0,
            "condition": {
                "compare_target": "CUSTOM_BAND",
                "value": 0.75,
                "signed_percent_offset": True,
            },
        })],
        "CRITERION", 100.0,
    ) == "볼린저밴드(19,3.0) +0.75% 기준선: 100"
    assert canvas._series_tooltip_text(
        [descriptor("comparison", wm.FAMILY_PRICE_COMPARISON, "BUY close above average", "CLOSE", {})],
        "CLOSE", 105.0,
    ) == f"{canvas._series_channel_label('CLOSE')}: 105"

    distinct = descriptor(
        "ocr-distinct", wm.FAMILY_OCR_OSC, "SELL OCR criterion", "OSC",
        {"fast": 7, "slow": 17, "signal": 3}, ("SELL",),
    )
    assert canvas._series_tooltip_text(
        [ocr_buy, ocr_sell, distinct], "OSC", 1.0,
    ) == "OCR(12,26,9) / OCR(7,17,3): 1"


def test_default_off_only_one_new_control_and_no_scan(case):
    window, flow = connected(case)
    base = case._window()
    base_filter = base.findChild(QCheckBox, "signalValidationFilterDisplayEnabled")
    assert base_filter is not None
    before = sorted(
        c.text() for c in base.findChildren(QCheckBox) if c is not base_filter
    )
    assert sorted(c.text() for c in window.findChildren(QCheckBox)) == before
    marking = window.findChild(QPushButton, "signalValidationMarkingEnabled")
    filter_display = window.findChild(QPushButton, "signalValidationFilterDisplayEnabled")
    valid_display = window.findChild(QPushButton, "signalValidationFilterDisplayValid")
    assert marking is window.marking_display_check
    assert filter_display is window.filter_display_check
    assert valid_display is window.filter_display_valid_check
    assert (marking.text(), filter_display.text(), valid_display.text()) == ("마킹", "필터", "유효")
    assert marking.isCheckable() and filter_display.isCheckable() and valid_display.isCheckable()
    window.show()
    case.app.processEvents()
    assert filter_display.x() < valid_display.x() < window.reset_button.x()
    assert not valid_display.isChecked()
    assert all(
        (button.width(), button.height(), button.focusPolicy()) == (68, 22, Qt.NoFocus)
        for button in (marking, filter_display, valid_display)
    )
    assert (marking.receivers(marking.toggled)
            and filter_display.receivers(filter_display.toggled)
            and valid_display.receivers(valid_display.toggled))
    for button in (marking, filter_display, valid_display):
        style = button.styleSheet()
        selector = f"QPushButton#{button.objectName()}"
        assert "color: #404040" in style
        assert "border: 1px solid #111827" in style
        assert f"{selector}:checked" in style
        assert "color: #16A34A" in style
        checked = button.isChecked()
        with QSignalBlocker(button):
            button.setChecked(not checked)
            assert button.isChecked() is not checked
            button.setChecked(checked)
        assert button.styleSheet() == style
    assert not window.marking_display_check.isChecked()
    assert not window.canvas.marker_records()
    assert window.replay_snapshot is None
    with patch.object(flow, "_prepare_replay_result_from_pool", side_effect=AssertionError("scan")):
        window._set_time_view(30, 25)
        window._set_time_view(35, 30)
        case.app.processEvents()
    assert window._MAX_VISIBLE_CANDLE_SPAN == 3500
    assert not hasattr(base, "marking_display_check")


def test_valid_display_selects_enabled_ui_without_marking_or_projection(case):
    """Valid is a settings-only overlay and never starts replay or full projection."""
    window, flow = connected(case)
    blockers = [
        QSignalBlocker(window.buy_signal_expr_line),
        QSignalBlocker(window.sell_signal_expr_line),
    ]
    window.buy_signal_expr_line.setText("A")
    window.sell_signal_expr_line.setText("A AND B")
    del blockers
    window._on_signal_validation_ui_changed()
    wait_for(case, lambda: window._visualization_projection_active is None)
    canvas = window.canvas
    descriptors = window.visualization_descriptors
    cache = window.visualization_cache
    expected = {
        (side, descriptor.identity)
        for descriptor in descriptors
        for side in descriptor.sides
        if (
            side == "BUY"
            and descriptor.family == wm.FAMILY_OCR_OSC
        ) or (
            side == "SELL"
            and descriptor.family in {
                wm.FAMILY_OCR_OSC,
                wm.FAMILY_RSI,
                wm.FAMILY_PRICE_COMPARISON,
                wm.FAMILY_PRICE_BOX,
                wm.FAMILY_BOLLINGER,
            }
        )
    }
    assert len(expected) == 8
    manual_price = next(
        descriptor for descriptor in descriptors
        if descriptor.axis == wm.PRICE_AXIS
    )
    manual_lower = next(
        descriptor for descriptor in descriptors
        if descriptor.axis == wm.LOWER_AXIS
    )
    canvas._toggle_price_legend_identities(
        manual_price.sides[0], (manual_price.identity,),
    )
    canvas._toggle_price_legend_identities(
        manual_lower.sides[0], (manual_lower.identity,),
    )
    manual_price_keys = canvas.highlighted_price_filter_identities
    manual_lower_keys = canvas.highlighted_lower_filter_identities

    with patch.object(
        flow,
        "_prepare_replay_result_from_pool",
        side_effect=AssertionError("valid display must not replay"),
    ), patch.object(
        window,
        "_refresh_filter_display_projection",
        side_effect=AssertionError("valid display must not project"),
    ), patch.object(
        canvas,
        "set_visualization_projection",
        side_effect=AssertionError("valid display must not reload canvas"),
    ):
        window.filter_display_valid_check.setChecked(True)

    assert window.filter_display_valid_check.isChecked()
    assert not window.marking_display_check.isChecked()
    assert window.validation_range is None and window.replay_snapshot is None
    assert set(canvas.valid_filter_identities) == expected
    assert canvas._valid_filter_index_ranges == {}
    assert canvas._valid_filter_delay_ranges == {}
    assert window.visualization_descriptors == descriptors
    assert window.visualization_cache is cache
    assert canvas.highlighted_price_filter_identities == manual_price_keys
    assert canvas.highlighted_lower_filter_identities == manual_lower_keys

    transition = next(
        descriptor for descriptor in descriptors
        if descriptor.family in {wm.FAMILY_OCR_OSC, wm.FAMILY_MACD_SIGNAL}
        and descriptor.parameters.get("condition", {}).get("operator") in {
            "TURN_UP", "TURN_DOWN", "ZERO_CROSS_UP", "ZERO_CROSS_DOWN",
        }
    )
    assert all(
        canvas._histogram_valid_signal_color(index, (transition,)) is None
        for index in range(len(canvas._candles))
    )

    window.filter_display_valid_check.setChecked(False)
    assert canvas.valid_filter_identities == ()
    assert canvas.highlighted_price_filter_identities == manual_price_keys
    assert canvas.highlighted_lower_filter_identities == manual_lower_keys
    window.filter_display_valid_check.setChecked(True)
    window.filter_display_check.setChecked(False)
    assert canvas.valid_filter_identities == ()
    assert window.filter_display_valid_check.isChecked()


def test_valid_display_uses_only_expression_referenced_enabled_groups(case):
    window, _flow = connected(case)
    line_blocker = QSignalBlocker(window.sell_signal_expr_line)
    window.sell_signal_expr_line.setText("A AND B")
    del line_blocker
    window._on_signal_validation_ui_changed()
    wait_for(case, lambda: window._visualization_projection_active is None)

    window.filter_display_valid_check.setChecked(True)
    selected = set(window.canvas.valid_filter_identities)
    sell_families = {
        descriptor.family
        for descriptor in window.visualization_descriptors
        if ("SELL", descriptor.identity) in selected
    }
    assert sell_families == {
        wm.FAMILY_OCR_OSC,
        wm.FAMILY_RSI,
        wm.FAMILY_PRICE_COMPARISON,
        wm.FAMILY_PRICE_BOX,
        wm.FAMILY_BOLLINGER,
    }
    assert not window._valid_filter_selection_error


def test_valid_display_not_keeps_groups_and_excludes_disabled_b_and_active_c(case):
    window, _flow = connected(case)
    b_controls = (
        window.sell_signal_condition_b_price_box_check,
        window.sell_signal_condition_b_bollinger_check,
        window.sell_signal_condition_b_gap_check,
    )
    c_controls = (
        window.sell_signal_condition_c_macd_check,
        window.sell_signal_condition_c_array_check,
        window.sell_signal_condition_c_gap_check,
    )
    blockers = [QSignalBlocker(control) for control in c_controls]
    for control in c_controls:
        control.setChecked(True)
    line_blocker = QSignalBlocker(window.sell_signal_expr_line)
    window.sell_signal_expr_line.setText("A NOT B")
    del line_blocker, blockers
    window._on_signal_validation_ui_changed()
    wait_for(case, lambda: window._visualization_projection_active is None)

    window.filter_display_valid_check.setChecked(True)
    selected = set(window.canvas.valid_filter_identities)
    sell_families = {
        descriptor.family
        for descriptor in window.visualization_descriptors
        if ("SELL", descriptor.identity) in selected
    }
    assert sell_families == {
        wm.FAMILY_OCR_OSC,
        wm.FAMILY_RSI,
        wm.FAMILY_PRICE_COMPARISON,
        wm.FAMILY_PRICE_BOX,
        wm.FAMILY_BOLLINGER,
    }

    blockers = [QSignalBlocker(control) for control in b_controls]
    for control in b_controls:
        control.setChecked(False)
    del blockers
    window._on_signal_validation_ui_changed()
    wait_for(case, lambda: window._visualization_projection_active is None)
    selected = set(window.canvas.valid_filter_identities)
    sell_families = {
        descriptor.family
        for descriptor in window.visualization_descriptors
        if ("SELL", descriptor.identity) in selected
    }
    assert sell_families == {
        wm.FAMILY_OCR_OSC,
        wm.FAMILY_RSI,
        wm.FAMILY_PRICE_COMPARISON,
    }
    assert not window._valid_filter_selection_error


def test_valid_display_invalid_expression_fails_closed_with_tooltip(case):
    window, _flow = connected(case)
    line_blocker = QSignalBlocker(window.sell_signal_expr_line)
    window.sell_signal_expr_line.setText("A AND (")
    del line_blocker
    window._on_signal_validation_ui_changed()
    wait_for(case, lambda: window._visualization_projection_active is None)

    window.filter_display_valid_check.setChecked(True)

    assert window.canvas.valid_filter_identities == ()
    assert window._valid_filter_selection_error
    assert window.filter_display_valid_check.toolTip().endswith(
        window._valid_filter_selection_error
    )


def test_oscillator_histogram_recolors_real_transition_without_price_marker(case):
    window, _flow = connected(case, evaluator=position_evaluator)
    canvas = window.canvas
    original = next(
        value for value in window.visualization_descriptors
        if value.family == wm.FAMILY_OCR_OSC
    )
    descriptor = replace(
        original,
        identity="transition-buy",
        sides=("BUY",),
        series_keys=("OSC",),
        parameter_json=json.dumps({"condition": {
            "operator": "ZERO_CROSS_UP", "target": "OSC",
        }}),
    )
    other = replace(descriptor, identity="transition-sell", sides=("SELL",))
    values = tuple([-2.0, -1.0, 1.0] + [1.0] * (len(canvas._candles) - 3))
    cache = wm.ValidationIndicatorSeriesCache(len(values), (
        (descriptor.identity, "OSC", values),
        (other.identity, "OSC", values),
    ))
    canvas.set_visualization_projection((descriptor, other), cache, {}, [])
    index = 2
    assert not canvas.marker_records()
    canvas.set_valid_filter_identities({("BUY", descriptor.identity)})
    assert canvas._histogram_valid_signal_color(index, (descriptor,)).name() == "#22c55e"
    assert canvas._histogram_valid_signal_color(1, (descriptor,)) is None
    assert wm._OSC_POSITIVE.name() != "#22c55e"
    macd = replace(
        descriptor,
        identity="transition-macd-buy",
        family=wm.FAMILY_MACD_SIGNAL,
        series_keys=("MACD",),
        parameter_json=json.dumps({"condition": {
            "operator": "ZERO_CROSS_UP", "target": "MACD",
        }}),
    )
    cache = wm.ValidationIndicatorSeriesCache(len(values), (
        (descriptor.identity, "OSC", values),
        (other.identity, "OSC", values),
        (macd.identity, "MACD", values),
    ))
    canvas.set_visualization_projection((descriptor, other, macd), cache, {}, [])
    canvas.set_valid_filter_identities({("BUY", macd.identity)})
    assert canvas._histogram_valid_signal_color(
        index,
        canvas._lower_histogram_evidence_owners(wm.FAMILY_OCR_OSC, (descriptor,)),
    ).name() == "#22c55e"
    canvas.set_valid_filter_identities({
        ("BUY", descriptor.identity),
        ("SELL", other.identity),
    })
    assert canvas._histogram_valid_signal_color(
        index, (descriptor, other),
    ) is None
    canvas.set_valid_filter_identities({("BUY", descriptor.identity)}, index_ranges={
        ("BUY", descriptor.identity): ((0, 1),),
    })
    assert canvas._histogram_valid_signal_color(index, (descriptor,)) is None


def test_oscillator_histogram_keeps_selected_and_frozen_buy_ocr_delays_distinct(case):
    window, _flow = connected(case, count=1101, evaluator=position_evaluator)
    canvas = window.canvas
    original = next(
        value for value in window.visualization_descriptors
        if value.family == wm.FAMILY_OCR_OSC
    )
    descriptor = replace(
        original,
        identity="selected-frozen-ocr-turn",
        sides=("BUY",),
        series_keys=("OSC",),
        parameter_json=json.dumps({"condition": {
            "operator": "TURN_UP", "target": "OSC",
        }}),
    )
    values = tuple(
        [3.0, 2.0, 3.0, 4.0, 3.0, 2.0, 3.0, 4.0, 3.0]
        + [3.0] * (len(canvas._candles) - 9)
    )
    canvas.set_visualization_projection(
        (descriptor,),
        wm.ValidationIndicatorSeriesCache(len(values), (
            (descriptor.identity, "OSC", values),
        )),
        {},
        [],
    )
    canvas.set_valid_filter_identities(
        {("BUY", descriptor.identity)},
        index_ranges={
            ("BUY", descriptor.identity): ((0, 5), (6, 10)),
        },
        delay_ranges={
            ("BUY", descriptor.identity): ((0, 5, 2), (6, 10, 4)),
        },
    )
    assert [
        (
            color.name()
            if (color := canvas._histogram_valid_signal_color(index, (descriptor,)))
            is not None
            else None
        )
        for index in range(5)
    ] == [None, None, None, None, "#22c55e"]
    assert canvas._histogram_valid_signal_color(6, (descriptor,)).name() == "#22c55e"
    assert canvas._histogram_valid_signal_color(10, (descriptor,)).name() == "#22c55e"
    assert canvas._histogram_valid_signal_color(11, (descriptor,)) is None
    canvas.set_valid_filter_identities(
        {("BUY", descriptor.identity)},
        index_ranges={("BUY", descriptor.identity): ((0, len(values) - 1),)},
        delay_ranges={("BUY", descriptor.identity): ((0, len(values) - 1, 100),)},
    )
    assert canvas._histogram_valid_signal_color(102, (descriptor,)).name() == "#22c55e"


def test_valid_display_survives_mark_off_period_and_delayed_projection(case):
    window, flow = connected(case, evaluator=position_evaluator)
    window.canvas.resize(1100, 700)
    window.filter_display_valid_check.setChecked(True)
    selected = window.canvas.valid_filter_identities
    assert len(selected) == len(window.visualization_descriptors) == 13
    turn_on(case, window)
    wait_for(case, lambda: window._visualization_projection_active is None)

    def lower_geometry():
        records = []
        for pane in window.canvas.lower_pane_records():
            family = str(pane["family"])
            scale = window.canvas._lower_scale(
                family, int(pane["top"]), int(pane["bottom"]),
            )
            assert scale is not None
            records.extend(window.canvas.lower_reference_line_records(family, scale))
        return records

    criteria = lower_geometry()
    assert criteria
    x_positions = tuple(
        window.canvas._x_for_index(index) for index in (10, 50, 90)
    )
    jobs = []

    class HeldThread:
        def __init__(self, *, target, **_kwargs):
            jobs.append(target)

        def start(self):
            pass

    mapper = window._load_indicator_follow_rule_mapper()
    with patch.object(
        mapper,
        "build_engine_rules_preview_from_ui_state",
        side_effect=AssertionError("cached valid selection must not remap"),
    ):
        with patch.object(wm, "Thread", HeldThread):
            window.marking_display_check.setChecked(False)
            assert not window.marking_display_check.isChecked()
            assert window.canvas.valid_filter_identities == selected
            assert window.canvas._valid_filter_index_ranges == {}
            assert window.canvas._valid_filter_delay_ranges == {}
            assert lower_geometry() == criteria
            assert tuple(
                window.canvas._x_for_index(index) for index in (10, 50, 90)
            ) == x_positions
            assert len(jobs) == 1

            jobs.pop()()
            wait_for(case, lambda: window._visualization_projection_active is None)
            assert window.canvas.valid_filter_identities == selected
            assert lower_geometry() == criteria
            assert tuple(
                window.canvas._x_for_index(index) for index in (10, 50, 90)
            ) == x_positions

    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    wait_for(case, lambda: window._visualization_projection_active is None)
    assert window.canvas.valid_filter_identities == selected
    assert window.canvas._valid_filter_index_ranges == {}
    assert window.canvas._valid_filter_delay_ranges == {}
    assert lower_geometry() == criteria


def test_exact_visible_endpoints_prefix_and_programmatic_view_changes_stay_frozen(case):
    seen = []
    def evaluator(prefix, rules, context):
        seen.append((prefix[-1]["time"], len(prefix), context.get("average_price")))
        return legacy.RoutineSignal(None, "none", [], [], -1, 0)
    window, flow = connected(case, evaluator=evaluator)
    window._set_time_view(40.25, 29.25)
    expected = (window._candles[40]["time"], window._candles[69]["time"])
    snapshot = turn_on(case, window)
    assert window._marking_times == expected
    assert (snapshot.evaluated_start_index, snapshot.evaluated_end_index) == (40, 69)
    assert min(n for _, n, _ in seen) == 41
    assert all(expected[0] <= stamp <= expected[1] for stamp, _, _ in seen)
    assert all(avg is None for _, _, avg in seen)
    assert window.validation_range is None
    assert window.replay_snapshot is None
    assert not flow._range_replay_pending and not flow._range_replay_active
    count = len(seen)
    window._set_time_view(10, 25)
    window._set_time_view(60, 30)
    case.app.processEvents()
    assert window._marking_times == expected and len(seen) == count
    assert window._marking_snapshot is snapshot


def test_integrated_display_endpoints_map_to_canonical_and_no_imported_buy(case):
    seen = []
    def evaluator(prefix, rules, context):
        seen.append(prefix[-1]["time"])
        return legacy.RoutineSignal(None, "none", [], [], -1, 0)
    window, flow = connected(case, evaluator=evaluator)
    canonical = deepcopy(window._calculation_candles)
    rows = deepcopy(canonical)
    extra = dict(rows[0], time=rows[0]["time"][:8] + "080000")
    window.validation_regular_market_only_check.setChecked(False)
    window.set_display_only_integrated_candles([extra] + rows[-80:])
    window._set_time_view(0, 30)
    assert window._chart_calculation_indexes[0] is None
    snapshot = turn_on(case, window)
    assert window._marking_times[0] == extra["time"]
    assert snapshot.evaluated_start_index == 0
    assert snapshot.evaluated_end_index == 48
    assert extra["time"] not in seen
    assert window._calculation_candles == canonical


def test_marking_on_off_preserves_candles_normal_series_view_and_manual_state(case):
    window, flow = connected(case)
    rows = deepcopy(window._candles)
    series = {(i, c): v for i, c, v in window.visualization_cache.series}
    view = window._current_chart_view_state()
    snapshot = turn_on(case, window)
    wait_for(case, lambda: window._visualization_projection_active is None)
    current = {(i, c): v for i, c, v in window.visualization_cache.series}
    assert all(current[k] == values for k, values in series.items())
    assert not window.visualization_active_identities(40, "BUY")
    assert not window.canvas._completed_cycle_average_lines
    window.marking_display_check.setChecked(False)
    wait_for(case, lambda: window._visualization_projection_active is None)
    assert window._candles == rows
    assert window._current_chart_view_state() == view
    assert window.replay_snapshot is None and window.validation_range is None
    assert not any(m["provenance"] == "marking" for m in window.canvas.marker_records())
    with patch.object(flow, "_prepare_replay_result_from_pool", side_effect=AssertionError("cache miss")):
        assert turn_on(case, window) is snapshot


@pytest.mark.parametrize("control", [
    "rule",
    "reset",
    "regular",
    "stock",
    "timeframe",
])
def test_controls_invalidate_marking(case, control):
    window, flow = connected(case)
    turn_on(case, window)
    old = window._marking_generation
    if control == "rule":
        edit = next(w for w in window.findChildren(QLineEdit) if not w.isReadOnly() and w.text().isdigit())
        edit.setText(str(int(edit.text()) + 1))
        window._flush_pending_signal_validation_ui_confirmation()
    elif control == "reset":
        window.reset_button.click()
    elif control == "regular":
        window.validation_regular_market_only_check.setChecked(not window.validation_regular_market_only_check.isChecked())
    elif control == "stock":
        window.set_validation_stock(legacy.ValidationStockRef("000660", "SK"))
    elif control == "timeframe":
        window.basic_signal_interval_combo.setCurrentText("15분")
    else:
        widget = getattr(window, control)
        if isinstance(widget, QCheckBox):
            widget.setChecked(not widget.isChecked())
        else:
            widget.setCurrentIndex((widget.currentIndex() + 1) % widget.count())
    assert not window.marking_display_check.isChecked()
    assert window._marking_generation > old
    assert window._marking_snapshot is None and window._marking_cache is None


@pytest.mark.parametrize("control, field", [
    ("validation_averaging_enabled_check", "enabled"),
    ("validation_trading_cost_enabled_check", "trading_cost_enabled"),
])
def test_policy_toggle_disables_marking_until_manual_reenable(
    case,
    control,
    field,
):
    window, flow = policy_refresh_case(case)
    failures = connect_full_validation(window, flow)

    assert window._request_validation() is not None
    wait_for(case, lambda: (
        window.replay_snapshot is not None
        and id(window) not in flow._prepare_active
    ) or failures)
    assert not failures
    original_marking = turn_on(case, window)
    canvas = window.canvas
    axis = window.fixed_price_axis
    view = window._current_chart_view_state()
    scroll = (
        window.time_navigation_scrollbar.minimum(),
        window.time_navigation_scrollbar.maximum(),
        window.time_navigation_scrollbar.value(),
    )
    descriptor = next(
        descriptor
        for descriptor in window.visualization_descriptors
        if descriptor.axis == wm.PRICE_AXIS
    )
    canvas._toggle_price_legend_identities(
        descriptor.sides[0],
        (descriptor.identity,),
    )
    legend = canvas.highlighted_price_filter_identities
    generation = window._marking_generation
    stale_payload = {
        "window_key": id(window),
        "generation": generation,
        "key": window._marking_key,
        "request_generation": flow._request_generation[id(window)],
        "snapshot": original_marking,
        "comparison": window._marking_comparison_cache,
    }
    assert window._marking_cache is not None
    old_markers = window.canvas.marker_records()
    assert old_markers

    getattr(window, control).setChecked(True)

    assert not window.marking_display_check.isChecked()
    assert window._marking_generation > generation
    assert (
        window._marking_times,
        window._marking_key,
        window._marking_snapshot,
        window._marking_settings,
        window._marking_comparison_cache,
        window._marking_cache,
    ) == (None, None, None, None, None, None)
    assert not window._marking_policy_refresh_pending
    assert window.canvas.marker_records() == []
    assert not window.completed_cycles
    assert not window.estimated_return_label.text()
    assert window.canvas is canvas and window.fixed_price_axis is axis
    assert window._current_chart_view_state() == view
    assert (
        window.time_navigation_scrollbar.minimum(),
        window.time_navigation_scrollbar.maximum(),
        window.time_navigation_scrollbar.value(),
    ) == scroll
    assert canvas.highlighted_price_filter_identities == legend

    flow._on_marking_completed(stale_payload)
    assert not window.marking_display_check.isChecked()
    assert window._marking_snapshot is None
    assert window._marking_cache is None
    assert window.canvas.marker_records() == []

    wait_for(case, lambda: (
        window._result_settings_snapshot.to_dict()["validation_execution"][field] is True
        and id(window) not in flow._prepare_active
    ) or failures)
    assert not failures
    assert not window.marking_display_check.isChecked()
    assert window._marking_snapshot is None
    assert window._marking_cache is None
    assert window.canvas.marker_records() == []
    assert not window.completed_cycles
    assert not window.estimated_return_label.text()
    assert window.replay_snapshot is None
    assert window.canvas is canvas and window.fixed_price_axis is axis
    assert window._current_chart_view_state() == view
    assert (
        window.time_navigation_scrollbar.minimum(),
        window.time_navigation_scrollbar.maximum(),
        window.time_navigation_scrollbar.value(),
    ) == scroll
    assert canvas.highlighted_price_filter_identities == legend

    flow._on_marking_completed(stale_payload)
    assert not window.marking_display_check.isChecked()
    assert window._marking_snapshot is None
    assert window.canvas.marker_records() == []

    enabled_marking = turn_on(case, window)
    assert enabled_marking is not original_marking
    assert enabled_marking.settings_hash == window._result_settings_snapshot.rules_hash
    assert window._marking_settings.rules_hash == window._result_settings_snapshot.rules_hash
    assert window._result_settings_snapshot.to_dict()["validation_execution"][field] is True
    assert window.marking_display_check.isChecked()
    assert window.canvas.marker_records()
    assert window.canvas is canvas and window.fixed_price_axis is axis
    assert window._current_chart_view_state() == view
    assert canvas.highlighted_price_filter_identities == legend


@pytest.mark.parametrize("control, field", [
    ("validation_averaging_enabled_check", "enabled"),
    ("validation_trading_cost_enabled_check", "trading_cost_enabled"),
])
def test_rapid_policy_toggles_never_auto_restore_marking(
    case,
    control,
    field,
):
    window, flow = policy_refresh_case(case)
    failures = connect_full_validation(window, flow)
    period_snapshot = turn_on(case, window)
    period = window._marking_times

    for enabled in (True, False, True, False):
        getattr(window, control).setChecked(enabled)

    assert not window.marking_display_check.isChecked()
    assert window._marking_times is None
    assert window._marking_snapshot is None
    assert window._marking_cache is None
    assert window.canvas.marker_records() == []
    wait_for(case, lambda: (
        window._result_settings_snapshot.to_dict()["validation_execution"][field] is False
        and id(window) not in flow._prepare_active
    ) or failures)
    assert not failures
    assert not window.marking_display_check.isChecked()
    assert window._marking_times is None
    assert window._marking_snapshot is None
    assert window._marking_cache is None
    assert window.canvas.marker_records() == []

    replacement = turn_on(case, window)
    assert replacement is not period_snapshot
    assert replacement.settings_hash == (
        window._result_settings_snapshot.rules_hash
    )
    assert window._marking_settings.rules_hash == (
        window._result_settings_snapshot.rules_hash
    )
    assert window.marking_display_check.isChecked()
    assert window._marking_times == period


def test_late_async_completion_after_off_is_ignored(case):
    window, flow = connected(case)
    jobs = []
    class HeldThread:
        def __init__(self, *, target, **kwargs):
            jobs.append(target)
        def start(self):
            pass
    with patch.object(fm, "Thread", HeldThread):
        window.marking_display_check.setChecked(True)
    generation, key = window._marking_generation, window._marking_key
    window._apply_time_zoom_target(
        window.visible_start_index,
        window.visible_candle_span - 5,
    )
    assert not window.marking_display_check.isChecked()
    assert window._marking_generation == generation + 1
    with patch.object(flow, "_prepare_replay_result_from_pool", side_effect=AssertionError("cancelled scan")):
        jobs[0]()
    flow._on_marking_completed(dict(window_key=id(window), generation=generation, key=key,
                                   request_generation=0, snapshot=object()))
    assert window._marking_snapshot is None
    assert not window.canvas.marker_records()


def test_marking_entry_detaches_payload_before_deferred_filter_projection(case):
    window, flow = connected(case)
    wait_for(case, lambda: window._visualization_projection_active is None)
    calculation_source = window._calculation_candles
    display_source = window._candles
    requests = []
    window.marking_evaluation_requested.connect(requests.append)

    class HeldThread:
        def __init__(self, *, target, **kwargs):
            self.target = target

        def start(self):
            pass

    original_deepcopy = wm.deepcopy

    full_candle_deepcopies = []

    def track_full_candle_deepcopy(value, *args, **kwargs):
        if value is calculation_source or value is display_source:
            full_candle_deepcopies.append(value)
        return original_deepcopy(value, *args, **kwargs)

    with patch.object(fm, "Thread", HeldThread), \
         patch.object(wm, "deepcopy", side_effect=track_full_candle_deepcopy), \
         patch.object(window, "_refresh_filter_display_projection") as refresh:
        window.marking_display_check.setChecked(True)

        assert window.marking_display_check.isChecked()
        assert len(requests) == 1
        request = requests[0]
        assert request["calculation"] == calculation_source
        assert request["display"] == display_source
        assert request["calculation"] is not calculation_source
        assert request["display"] is not display_source
        assert all(a is not b for a, b in zip(request["calculation"], calculation_source))
        assert all(a is not b for a, b in zip(request["display"], display_source))
        assert not full_candle_deepcopies
        refresh.assert_not_called()

        wait_for(case, lambda: refresh.call_count == 1)
        refresh.assert_called_once_with()


def test_manual_range_feedback_precedes_filter_projection_and_clears_old_evidence(case):
    window, flow = connected(case, evaluator=position_evaluator)
    turn_on(case, window)
    wait_for(case, lambda: window._visualization_projection_active is None)
    assert any(44 <= row["evaluation_index"] <= 56
               for row in window.canvas.marker_records())
    observed = []
    window.validation_range_evaluation_requested.connect(
        lambda *_: observed.append((window.canvas.validation_range,
                                    window.canvas.marker_records())))

    class HeldThread:
        def __init__(self, *, target, **kwargs):
            self.target = target

        def start(self):
            pass

    with patch.object(fm, "Thread", HeldThread), \
         patch.object(window, "_refresh_filter_display_projection") as refresh:
        window._complete_validation_range_drag(44, 56)

        assert window.canvas.validation_range == (44, 56)
        assert observed and observed[0][0] == (44, 56)
        assert not any(44 <= row["evaluation_index"] <= 56
                       for row in window.canvas.marker_records())
        assert not window.completed_cycles
        assert not window.estimated_return_label.text()
        refresh.assert_not_called()

        wait_for(case, lambda: refresh.call_count == 1)
        refresh.assert_called_once_with()


def test_comparison_mask_is_copy_and_manual_union_has_exact_endpoints(case):
    window, flow = connected(case)
    turn_on(case, window)
    normal = window.visualization_descriptors[0]
    compare = wm.ValidationFilterDescriptor("comparison", wm.FAMILY_PRICE_COMPARISON, "cmp", "PRICE",
                                           ("BUY",), ("CLOSE", "AVG_PRICE"), "{}", ())
    values = tuple(range(100))
    raw = wm.ValidationIndicatorSeriesCache(100, (("comparison", "CLOSE", values),
          ("comparison", "AVG_PRICE", values), (normal.identity, "MA", values)))
    window._marking_comparison_cache = (tuple(c["time"] for c in window._candles), raw)
    clipped = window._clip_comparison_cache((compare, normal), raw)
    assert clipped.values_for("comparison", "CLOSE") == tuple(v if 40 <= i <= 69 else None for i, v in enumerate(values))
    assert all(v is None for v in clipped.values_for("comparison", "AVG_PRICE"))
    assert clipped.values_for(normal.identity, "MA") == values
    window._set_validation_range(45, 55)
    clipped = window._clip_comparison_cache((compare, normal), raw)
    assert clipped.values_for("comparison", "AVG_PRICE") == tuple(v if 45 <= i <= 55 else None for i, v in enumerate(values))
    assert raw.series[0][2] == values
    window._disable_marking()
    clipped = window._clip_comparison_cache((compare, normal), raw)
    assert clipped.values_for("comparison", "CLOSE") == tuple(v if 45 <= i <= 55 else None for i, v in enumerate(values))


def test_source_content_change_rejects_cache(case):
    window, flow = connected(case)
    turn_on(case, window)
    key = window._marking_key
    window._calculation_candles[0]["close"] += 1
    window._revalidate_marking_source()
    assert window._marking_key is None and window._marking_cache is None
    assert not window.marking_display_check.isChecked()
    turn_on(case, window)
    assert window._marking_key != key


def position_evaluator(prefix, rules, context):
    index = len(prefix) - 1
    side = context["_indicator_follow_evaluate_side"]
    signal = (side if (side == "BUY" and index in (3, 42, 45))
              or (side == "SELL" and index == 55 and context.get("average_price") is not None)
              else None)
    return legacy.RoutineSignal(signal, "fixture", [], [], index if signal else -1, 0)


@pytest.mark.parametrize("settings_changed", [False, True])
def test_current_period_rules_keep_frozen_marking_outside_selected_range(
    case, settings_changed,
):
    def evaluator(prefix, rules, context):
        index = len(prefix) - 1
        side = context["_indicator_follow_evaluate_side"]
        current = rules["validation_execution"]["trading_cost_enabled"]
        signal = (
            side
            if (
                (side == "BUY" and index == 65)
                or (current and side == "BUY" and index == 42)
                or (not current and side == "BUY" and index == 45)
                or (
                    side == "SELL"
                    and index == 55
                    and context.get("average_price") is not None
                )
            )
            else None
        )
        return legacy.RoutineSignal(
            signal, "range marking fixture", [], [], index if signal else -1, 0,
        )

    window, flow = connected(case, evaluator=evaluator)
    frozen = turn_on(case, window)
    if settings_changed:
        blocker = QSignalBlocker(window.validation_trading_cost_enabled_check)
        window.validation_trading_cost_enabled_check.setChecked(True)
        del blocker

    window._complete_validation_range_drag(40, 60)
    wait_for(case, lambda: window._range_replay_entries_available)
    records = {
        (record["evaluation_index"], record["side"]): record["provenance"]
        for record in window.canvas.marker_records()
    }
    if settings_changed:
        assert records == {
            (42, "BUY"): "manual",
            (55, "SELL"): "manual",
        }
        assert window._marking_snapshot is None
        assert not window.marking_display_check.isChecked()
    else:
        assert records == {
            (65, "BUY"): "marking",
            (45, "BUY"): "manual",
            (55, "SELL"): "manual",
        }
        assert window._marking_snapshot is frozen
        assert window.marking_display_check.isChecked()


def policy_refresh_case(case):
    def evaluator(prefix, rules, context):
        index = len(prefix) - 1
        side = context["_indicator_follow_evaluate_side"]
        signal = (
            side
            if (side == "BUY" and index in (942, 945))
            or (
                side == "SELL"
                and index == 955
                and context.get("average_price") is not None
            )
            else None
        )
        return legacy.RoutineSignal(
            signal,
            "policy refresh fixture",
            [],
            [],
            index if signal else -1,
            0,
        )

    window, flow = connected(case, count=1000, evaluator=evaluator)
    key = id(window)
    flow._history_targets[key] = 100
    verified_at = flow._source_snapshot_datetime(
        flow._historical_pools[key]["source_verified_at"]
    )
    flow._now_factory = lambda: verified_at
    rows = deepcopy(window._calculation_candles)
    window.set_historical_candle_count(100)
    window.set_historical_candle_pool(rows, chart_candle_count=100)
    window.install_normal_base(
        window._result_settings_snapshot,
        flow._validation_sessions[key].request.timeframe_key,
    )
    window._set_time_view(40, 30)
    return window, flow


def shifted_cycle_case(case, *, marking=False):
    window, flow = connected(case, evaluator=position_evaluator)
    raw = deepcopy(window._calculation_candles)
    window.set_historical_candle_pool(raw, chart_candle_count=101)
    window.set_historical_display_candles(raw[30:])
    window.install_normal_base(window._result_settings_snapshot, "M1")
    window.resize(1400, 800)
    window.show()  # Offscreen fixture window, never the production GUI.
    case.app.processEvents()
    window._set_time_view(10, 30)
    if marking:
        turn_on(case, window)
    window._complete_validation_range_drag(14, 26)
    wait_for(case, lambda: window._range_replay_entries_available)
    wait_for(case, lambda: window._visualization_projection_active is None)
    assert [(c.buy_indexes, c.sell_index) for c in window.completed_cycles] == [((15,), 25)]
    return window, flow, raw


def cycle_table_text(window):
    table = window.completed_cycle_table
    return tuple(table.item(r, c).text() for r in range(table.rowCount())
                 for c in range(table.columnCount()))


def assert_cycle_anchors(window):
    cycle, = window.completed_cycles
    line, = window.canvas.completed_cycle_average_line_records()
    label, = window.canvas.completed_cycle_average_label_records()
    sell_x = window.canvas._x_for_index(cycle.sell_index)
    assert line["x1"] == pytest.approx(window.canvas._x_for_index(cycle.buy_start_index))
    assert line["x2"] == pytest.approx(sell_x)
    assert label["x2"] == pytest.approx(sell_x)
    assert label["leader_x1"] == pytest.approx(sell_x)
    gap = max(label["label_left"] - sell_x,
              sell_x - label["label_left"] - label["label_width"], 0)
    assert gap <= 48


@pytest.mark.parametrize("marking", [False, True])
@pytest.mark.parametrize("extra_bar", [False, True])
def test_display_only_cycle_timestamp_round_trip(case, marking, extra_bar):
    window, flow, raw = shifted_cycle_case(case, marking=marking)
    original, = window.completed_cycles
    table = cycle_table_text(window)
    replay = window.replay_snapshot
    snapshot_candles = replay.to_candles()
    marked = window._marking_snapshot
    anchors = (window._validation_range_times, window._marking_times)
    summary = window.estimated_return_label.text()
    requests = []
    window.validation_range_evaluation_requested.connect(lambda *_: requests.append("range"))
    window.marking_evaluation_requested.connect(lambda *_: requests.append("marking"))
    expanded = deepcopy(raw)
    if extra_bar:
        expanded.insert(50, dict(raw[49], time=raw[49]["time"][:12] + "30"))
    with QSignalBlocker(window.validation_regular_market_only_check):
        window.validation_regular_market_only_check.setChecked(False)
    with patch.object(window, "_refresh_validation_range_results", side_effect=AssertionError("recompute")), \
         patch.object(flow, "_prepare_replay_result_from_pool", side_effect=AssertionError("replay")):
        for rows, buy, sell, bounds in ((expanded, 45, 55 + extra_bar, (44, 56 + extra_bar)),
                                       (deepcopy(raw[30:]), 15, 25, (14, 26))):
            assert_cycle_anchors(window)  # Warm the old geometry cache before replacement.
            old_canvas = window.canvas
            view = window._current_chart_view_state()
            window.set_display_only_integrated_candles(rows)
            wait_for(case, lambda: window._visualization_projection_active is None)
            cycle, = window.completed_cycles
            assert window.completed_cycle_table.item(0, 5).text() == window._cycle_time(
                window._candles[cycle.sell_index]["time"])
            assert window._candles[cycle.sell_index]["time"] == raw[55]["time"]
            assert tuple(window._candles[i]["time"] for i in cycle.buy_indexes) == (raw[45]["time"],)
            assert cycle == replace(original, buy_indexes=(buy,), buy_start_index=buy,
                                    buy_end_index=buy, sell_index=sell)
            assert cycle_table_text(window) == table
            assert window.estimated_return_label.text() == summary
            assert all(window.completed_cycle_table.item(0, c).data(Qt.UserRole) == sell
                       for c in range(window.completed_cycle_table.columnCount()))
            assert window.validation_range == bounds
            assert window.canvas is not old_canvas
            assert window._current_chart_view_state() == replace(
                view, visible_candle_span=min(view.visible_candle_span, len(rows)))
            assert window.replay_snapshot is replay and replay.to_candles() == snapshot_candles
            assert window._calculation_candles == raw
            # Existing source validation invalidates marking when a bar is
            # inserted inside its frozen interval; ordinary shifts retain it.
            assert window._marking_snapshot is (None if extra_bar else marked)
            assert window.marking_display_check.isChecked() == (marking and not extra_bar)
            assert window._validation_range_times == anchors[0]
            assert window._marking_times == (None if extra_bar else anchors[1])
            if extra_bar and len(rows) == 101:
                assert window._chart_calculation_indexes[50] is None
            if buy >= window.visible_start_index + window.visible_candle_span:
                assert not window.canvas.completed_cycle_average_line_records()
                assert not window.canvas.completed_cycle_average_label_records()
            else:
                assert_cycle_anchors(window)
            # The retained viewport can be away from the shifted cycle; show its range,
            # then zoom out to expose any orphaned cached line or label.
            window._set_time_view(buy - 5, 30)
            assert_cycle_anchors(window)
            window._set_time_view(0, len(rows))
            assert_cycle_anchors(window)
            rows[buy]["close"] = -1
            assert window._candles[buy]["close"] == raw[45]["close"]
        window._completed_cycle_row_clicked(0, 0)
        assert window._selected_index == 25
        assert not requests


@pytest.mark.parametrize("invalid", ["missing_buy", "missing_sell", "duplicate", "reordered", "nxt_reordered", "blank"])
def test_display_only_cycle_invalid_timestamps_preserve_prior_state(case, invalid):
    window, flow, raw = shifted_cycle_case(case)
    rows = deepcopy(raw)
    if invalid.startswith("missing"):
        rows.pop(45 if invalid == "missing_buy" else 55)
    elif invalid == "duplicate":
        rows.insert(55, dict(rows[55]))
    elif invalid == "reordered":
        rows[54], rows[55] = rows[55], rows[54]
    elif invalid == "nxt_reordered":
        rows.insert(50, dict(rows[49], time=rows[0]["time"][:8] + "080000"))
    else:
        rows.insert(50, dict(rows[49], time=""))
    with QSignalBlocker(window.validation_regular_market_only_check):
        window.validation_regular_market_only_check.setChecked(False)
    before = (window._candles, window.canvas, window._completed_cycles,
              window._display_only_integrated_candles, window._visualization_data_epoch,
              window._preserve_view_on_next_replay, window._chart_calculation_indexes)
    text = cycle_table_text(window)
    with pytest.raises(ValueError, match="TIME_IDENTITY_INVALID"):
        window.set_display_only_integrated_candles(rows)
    assert (window._candles, window.canvas, window._completed_cycles,
            window._display_only_integrated_candles, window._visualization_data_epoch,
            window._preserve_view_on_next_replay, window._chart_calculation_indexes) == before
    assert cycle_table_text(window) == text
    assert window.completed_cycle_table.item(0, 5).data(Qt.UserRole) == 25
    assert_cycle_anchors(window)
    # A later valid display still starts from the preserved source coordinates.
    window.set_display_only_integrated_candles(raw)
    assert window.completed_cycles[0].sell_index == 55


def test_v4_history_browse_cycles_remap_once_5000_to_5900(case):
    window, flow = connected(case, count=5000, evaluator=position_evaluator)
    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    wait_for(case, lambda: window._visualization_projection_active is None)
    cycle, = window.completed_cycles
    text = cycle_table_text(window)
    rows = candles(5900)
    assert rows[-5000:] == window._candles
    prepared = wm.prepare_signal_validation_presentation(
        rows, (), window._result_settings_snapshot, chart_start_index=0, chart_count=5900)
    with patch.object(window, "_refresh_validation_range_results", side_effect=AssertionError("recompute")):
        window.apply_history_browse_presentation(rows, chart_candle_count=5900,
                                                 prepared_presentation=prepared)
    assert window.completed_cycles == (replace(cycle, buy_indexes=(945,), buy_start_index=945,
                                              buy_end_index=945, sell_index=955),)
    assert window.validation_range == (944, 956)
    assert cycle_table_text(window) == text
    assert window.completed_cycle_table.item(0, 5).data(Qt.UserRole) == 955
    assert window.canvas._completed_cycle_average_lines == window.completed_cycles


@pytest.mark.parametrize("refresh", ["full_replay", "regular_display"])
def test_cycle_remap_is_owned_by_the_selected_refresh_path(case, refresh):
    window, flow, raw = shifted_cycle_case(case)
    original = window._completed_cycles
    text = cycle_table_text(window)
    if refresh == "full_replay":
        window.set_historical_display_candles(raw)
        assert window._completed_cycles is original
        window.set_replay_snapshot(window.replay_snapshot)
    else:
        with QSignalBlocker(window.validation_regular_market_only_check):
            window.validation_regular_market_only_check.setChecked(True)
        with patch.object(window, "_refresh_validation_range_results", side_effect=AssertionError("recompute")):
            window._on_validation_regular_market_display_changed()
    assert window.completed_cycles[0] == replace(
        original[0], buy_indexes=(45,), buy_start_index=45, buy_end_index=45, sell_index=55)
    assert window.validation_range == (44, 56)
    assert cycle_table_text(window) == text
    assert window.completed_cycle_table.item(0, 5).data(Qt.UserRole) == 55


def test_display_only_remaps_every_buy_in_multiple_completed_cycles(case):
    def evaluator(prefix, rules, context):
        index, side = len(prefix) - 1, context["_indicator_follow_evaluate_side"]
        signal = side if ((side == "BUY" and index in (42, 45, 62, 65)) or
                          (side == "SELL" and index in (55, 75)
                           and context.get("average_price") is not None)) else None
        return legacy.RoutineSignal(signal, "fixture", [], [], index if signal else -1, 0)
    window, flow = connected(case, evaluator=evaluator)
    raw = deepcopy(window._calculation_candles)
    window.set_historical_display_candles(raw[30:])
    window.install_normal_base(window._result_settings_snapshot, "M1")
    window._complete_validation_range_drag(10, 50)
    wait_for(case, lambda: window._range_replay_entries_available)
    original = window.completed_cycles
    assert [c.buy_indexes for c in original] == [(12, 15), (32, 35)]
    text = cycle_table_text(window)
    with QSignalBlocker(window.validation_regular_market_only_check):
        window.validation_regular_market_only_check.setChecked(False)
    window.set_display_only_integrated_candles(raw)
    assert window.completed_cycles == tuple(replace(
        c, buy_indexes=tuple(i + 30 for i in c.buy_indexes),
        buy_start_index=c.buy_start_index + 30, buy_end_index=c.buy_end_index + 30,
        sell_index=c.sell_index + 30) for c in original)
    assert cycle_table_text(window) == text
    for row, cycle in enumerate(window.completed_cycles):
        assert window.completed_cycle_table.item(row, 5).text() == window._cycle_time(raw[cycle.sell_index]["time"])
        assert all(window.completed_cycle_table.item(row, col).data(Qt.UserRole) == cycle.sell_index
                   for col in range(window.completed_cycle_table.columnCount()))


@pytest.mark.parametrize("refresh", ["integrated", "snapshot"])
@pytest.mark.parametrize("active_range", [True, False])
def test_presentation_refresh_preserves_cycles_then_horizontal_navigation_disables_marking(
    case, refresh, active_range,
):
    window, flow = connected(case, evaluator=position_evaluator)
    marking_snapshot = turn_on(case, window)
    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    wait_for(case, lambda: window._visualization_projection_active is None)
    assert len(window.completed_cycles) == window.completed_cycle_table.rowCount() == 1
    assert len(window.canvas.completed_cycle_average_line_records()) == 1
    assert len(window.canvas.completed_cycle_average_label_records()) == 1
    if not active_range:
        # Retain computed results while removing the period to exercise the guard.
        window._set_validation_range(None, None)
    cycles = tuple(window.completed_cycles)
    replay = window.replay_snapshot
    old_canvas = window.canvas
    table = tuple(window.completed_cycle_table.item(row, col).text()
                  for row in range(window.completed_cycle_table.rowCount())
                  for col in range(window.completed_cycle_table.columnCount()))
    anchors = (window._marking_times, window._validation_range_times,
               window._validation_range_anchor_time)
    requests = []
    window.marking_evaluation_requested.connect(lambda *_: requests.append("marking"))
    window.validation_range_evaluation_requested.connect(lambda *_: requests.append("range"))

    with patch.object(window, "_refresh_validation_range_results",
                      side_effect=AssertionError("presentation must not rebuild cycles")), \
            patch.object(flow, "_prepare_replay_result_from_pool",
                         side_effect=AssertionError("presentation must not replay")):
        if refresh == "integrated":
            with QSignalBlocker(window.validation_regular_market_only_check):
                window.validation_regular_market_only_check.setChecked(False)
            window.set_display_only_integrated_candles(list(window._candles))
        else:
            window.set_replay_snapshot(replay, presentation_only=True)
        wait_for(case, lambda: window._visualization_projection_active is None)
        assert window.canvas is not old_canvas
        # The direct snapshot API may select the last bar; inspect the cycle's range.
        window._set_time_view(40, 30)
        before_pan = window.visible_start_index
        for action in ("installed", "pan", "wheel"):
            if action == "pan":
                window.canvas.pan_requested.emit(-20.0, 0.0)
                assert window.visible_start_index != before_pan
            elif action == "wheel":
                span = window.visible_candle_span
                window.canvas.time_scale_wheel_requested.emit(window.canvas._x_for_index(50), 120)
                window._flush_pending_wheel_zoom()
                assert window.visible_candle_span < span
            case.app.processEvents()
            if action == "installed":
                assert window.marking_display_check.isChecked()
                assert window._marking_snapshot is marking_snapshot
                assert window._marking_times == anchors[0]
            else:
                assert not window.marking_display_check.isChecked()
                assert window._marking_snapshot is None
                assert window._marking_times is None
            assert window.replay_snapshot is replay
            assert tuple(window.completed_cycles) == cycles
            assert window.completed_cycles[0] is cycles[0]
            assert table == tuple(window.completed_cycle_table.item(row, col).text()
                                  for row in range(window.completed_cycle_table.rowCount())
                                  for col in range(window.completed_cycle_table.columnCount()))
            assert (window._validation_range_times,
                    window._validation_range_anchor_time) == anchors[1:]
            assert window.validation_range == ((44, 56) if active_range else None)
            assert window.canvas.validation_range == window.validation_range
            lines = window.canvas.completed_cycle_average_line_records()
            labels = window.canvas.completed_cycle_average_label_records()
            assert len(lines) == len(labels) == int(active_range)
            assert window.canvas._completed_cycle_average_lines == (cycles if active_range else ())
            if active_range:
                assert (lines[0]["buy_start_index"], lines[0]["sell_index"]) == (45, 55)
                assert labels[0]["cycle_number"] == lines[0]["cycle_number"]
                assert lines[0]["x1"] == pytest.approx(window.canvas._x_for_index(45))
                assert lines[0]["x2"] == pytest.approx(window.canvas._x_for_index(55))
        assert not requests


def test_period_then_marking_clears_period_and_keeps_visible_evidence_only(case):
    window, flow = connected(case, evaluator=position_evaluator)
    window.show()
    case.app.processEvents()
    window._set_time_view(40.25, 29.25)
    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    wait_for(case, lambda: window._visualization_projection_active is None)
    assert window.canvas.validation_range == (44, 56)
    assert len(window.completed_cycles) == window.completed_cycle_table.rowCount() == 1
    assert window.canvas.completed_cycle_average_label_records()
    assert window.estimated_return_label.text()
    before = window.canvas.marker_records()
    manual_buy = next(m for m in before if m["evaluation_index"] == 45)
    assert "1차" in manual_buy["tooltip"]
    window._completed_cycle_row_clicked(0, 0)
    rows = deepcopy(window._candles)
    calculation = deepcopy(window._calculation_candles)
    entries = deepcopy(window._calculation_entries)
    replay = window.replay_snapshot
    view = window._current_chart_view_state()
    requests = []
    window.marking_evaluation_requested.connect(
        lambda request: requests.append((request["times"], window.validation_range)))

    snapshot = turn_on(case, window)
    wait_for(case, lambda: window._visualization_projection_active is None)
    expected_times = (rows[40]["time"], rows[69]["time"])
    assert requests == [(expected_times, None)]
    assert window._marking_times == expected_times
    assert (snapshot.evaluated_start_index, snapshot.evaluated_end_index) == (40, 69)
    assert window.validation_range is None and window._validation_range_times is None
    assert window.canvas.validation_range is None
    assert window._validation_range_anchor_index is None
    assert window._validation_range_anchor_time is None
    assert window._selected_index is None and window.canvas.selected_index is None
    assert not window._range_replay_entries_available
    assert not window._range_replay_entries and not window._range_replay_calculation_entries
    assert not window._range_replay_revalidation_pending
    assert not window.completed_cycles and window.completed_cycle_table.rowCount() == 0
    assert not window.canvas._completed_cycle_average_lines
    assert not window.canvas.completed_cycle_average_label_records()
    assert window.canvas.selected_completed_cycle_number is None
    assert not window.estimated_return_label.text()
    assert "캔들" not in window.result_summary_label.text()
    records = window.canvas.marker_records()
    assert {m["provenance"] for m in records} == {"marking"}
    assert {(m["evaluation_index"], m["side"]) for m in records} == {
        (42, "BUY"), (45, "BUY"), (55, "SELL")}
    assert all(m["evaluation_time"] == rows[m["evaluation_index"]]["time"] for m in records)
    marking_buy = next(m for m in records if m["evaluation_index"] == 45)
    assert "2차" in marking_buy["tooltip"]
    assert window.canvas.marker_tooltip_at(
        window.canvas._x_for_index(45), window.canvas._marker_y(45, "BUY")) == marking_buy["tooltip"]
    assert window.canvas.pinned_marker_key is None

    compare = wm.ValidationFilterDescriptor("comparison", wm.FAMILY_PRICE_COMPARISON, "cmp", "PRICE",
                                           ("BUY",), ("CLOSE", "AVG_PRICE"), "{}", ())
    raw = wm.ValidationIndicatorSeriesCache(100, (("comparison", "CLOSE", (999,) * 100),
                                                 ("comparison", "AVG_PRICE", (999,) * 100)))
    marked = wm.ValidationIndicatorSeriesCache(100, (("comparison", "CLOSE", tuple(range(100))),))
    window._marking_comparison_cache = (tuple(c["time"] for c in rows), marked)
    clipped = window._clip_comparison_cache((compare,), raw)
    assert clipped.values_for("comparison", "CLOSE") == tuple(i if 40 <= i <= 69 else None for i in range(100))
    assert clipped.values_for("comparison", "AVG_PRICE") == (None,) * 100
    assert raw.values_for("comparison", "CLOSE") == (999,) * 100
    assert window._candles == rows and window._calculation_candles == calculation
    assert window._calculation_entries == entries == []
    # This fixture began in uncalculated normal mode. Clearing its local
    # range must not promote the temporary range replay to a full baseline.
    assert replay is not None
    assert window.replay_snapshot is None and window._normal_base_requested
    # Pane heights are populated asynchronously after the first rendered layout.
    current_view = window._current_chart_view_state()
    assert replace(current_view, lower_pane_heights=()) == replace(
        view, selected_evaluation_index=None, lower_pane_heights=(),
    )
    marker_position = QPoint(
        round(window.canvas._x_for_index(45)),
        round(window.canvas._marker_y(45, "BUY")),
    )
    QTest.mouseClick(window.canvas, Qt.LeftButton, pos=marker_position)
    case.app.processEvents()
    assert window._selected_index == 45
    assert window.canvas.selected_index == 45
    assert window.canvas.pinned_marker_key == (45, "BUY")
    assert window.canvas.marker_tooltip_at(
        marker_position.x(), marker_position.y()
    ) == marking_buy["tooltip"]
    assert not hasattr(window.canvas, "selection_indicator_index")
    assert not hasattr(window, "_position_indicator_index")
    window.marking_display_check.setChecked(False)
    wait_for(case, lambda: window._visualization_projection_active is None)
    assert window.validation_range is None and window.canvas.validation_range is None
    assert not window.completed_cycles and window.completed_cycle_table.rowCount() == 0
    assert not window.estimated_return_label.text()
    assert not window.canvas.marker_records()


def test_marking_without_manual_range_hides_retained_base_markers(case):
    window, flow = connected(case, evaluator=position_evaluator)
    # Unlike a temporary local range on an uncalculated normal chart,
    # genuine full-validation evidence survives local range clearing.
    session = flow._validation_sessions[id(window)]
    pool = flow._historical_pools[id(window)]
    full = flow._prepare_replay_result_from_pool(
        session, pool, history_target=100, evaluation_count=100,
    )
    assert full.ok and full.snapshot is not None
    window.set_replay_snapshot(full.snapshot)
    baseline_entries = list(window._entries), list(window._calculation_entries)
    assert window._marker_entries_for_calculation()
    assert not window._marker_entries_for_display()
    assert not window.canvas.marker_records()
    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    window._clear_validation_range_interaction()
    # Full-calculation evidence remains reusable internally, but cannot
    # reappear as triangles when marking is OFF and there is no selection.
    assert not window._normal_base_requested
    assert (window._entries, window._calculation_entries) == baseline_entries
    assert window._marker_entries_for_calculation()
    assert not window._marker_entries_for_display()
    assert not window.canvas.marker_records()
    turn_on(case, window)
    assert {m["provenance"] for m in window.canvas.marker_records()} == {"marking"}


@pytest.mark.parametrize("failure", ["settings", "calculation"])
def test_marking_failure_does_not_restore_previous_period(case, failure):
    window, flow = connected(case, evaluator=position_evaluator)
    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    target, method = ((window, "_marking_current_settings") if failure == "settings"
                      else (flow, "_prepare_replay_result_from_pool"))
    with patch.object(target, method, side_effect=ValueError("fixture failure")):
        window.marking_display_check.setChecked(True)
        wait_for(case, lambda: not window.marking_display_check.isChecked())
    assert "fixture failure" in window.marking_display_check.toolTip()
    assert window.validation_range is None and window._validation_range_times is None
    assert window.canvas.validation_range is None
    assert window._validation_range_anchor_index is None
    assert not window._range_replay_entries_available
    assert not window.completed_cycles and window.completed_cycle_table.rowCount() == 0
    assert not window.canvas._completed_cycle_average_lines
    assert not window.estimated_return_label.text()


def test_marking_confirmation_failure_clears_period_before_delayed_completion(case):
    window, flow = connected(case, evaluator=position_evaluator)
    jobs, completions = [], []

    class HeldThread:
        def __init__(self, *, target, **kwargs):
            jobs.append(target)

        def start(self):
            pass

    with patch.object(fm, "Thread", HeldThread):
        window._complete_validation_range_drag(44, 56)
    with patch.object(flow, "_emit_range_replay_completed", side_effect=completions.append):
        jobs[0]()
    payload, = completions
    assert window.canvas.validation_range == (44, 56)
    assert id(window) in flow._range_replay_active

    detail = "confirmation fixture failure"
    with patch.object(
        window, "_current_signal_ui_validation_warnings", side_effect=ValueError(detail),
    ):
        window.marking_display_check.setChecked(True)
        wait_for(case, lambda: not window.marking_display_check.isChecked())

    assert detail in window.marking_display_check.toolTip()
    assert window.validation_status_label.text()
    assert detail not in window.validation_status_label.text()
    assert window.validation_range is None and window._validation_range_times is None
    assert window.canvas.validation_range is None
    assert window._validation_range_anchor_index is None
    assert not window._range_replay_entries_available
    assert not window.completed_cycles and window.completed_cycle_table.rowCount() == 0

    flow._on_range_replay_completed(payload)
    case.app.processEvents()
    assert id(window) not in flow._range_replay_active
    assert window.validation_range is None and window.canvas.validation_range is None
    assert window.replay_snapshot is None and not window._range_replay_entries_available
    assert not window.canvas.marker_records()


def test_unrelated_confirmation_failure_does_not_touch_mark_button_tooltip(case):
    window, _flow = connected(case)
    original_tooltip = "existing Mark tooltip"
    window.marking_display_check.setToolTip(original_tooltip)
    window.show()
    line = window.buy_signal_expr_line
    line.setFocus(Qt.OtherFocusReason)
    case.app.processEvents()
    assert line.hasFocus()
    assert not window.marking_display_check.isChecked()

    detail = "unrelated config fixture"
    with patch.object(
        window, "_current_signal_ui_validation_warnings", side_effect=ValueError(detail),
    ):
        assert not window._on_signal_validation_ui_confirmed()

    message = window.validation_status_label.text()
    assert message and detail not in message
    assert line.toolTip() == message
    assert window.marking_display_check.toolTip() == original_tooltip

    window._clear_signal_validation_confirmation_error()
    assert not window.validation_status_label.text()
    assert not line.toolTip()
    assert window.marking_display_check.toolTip() == original_tooltip


def test_successful_mark_retry_clears_confirmation_failure_tooltip(case):
    window, _flow = connected(case)
    detail = "confirmation fixture failure"
    with patch.object(
        window, "_current_signal_ui_validation_warnings", side_effect=ValueError(detail),
    ):
        window.marking_display_check.setChecked(True)
    assert not window.marking_display_check.isChecked()
    assert window.marking_display_check.toolTip() == detail

    turn_on(case, window)
    assert not window.marking_display_check.toolTip()


def test_period_completion_queued_before_marking_cannot_repaint_cleared_range(case):
    window, flow = connected(case, evaluator=position_evaluator)
    jobs, completions = [], []
    class HeldThread:
        def __init__(self, *, target, **kwargs):
            jobs.append(target)
        def start(self):
            pass
    with patch.object(fm, "Thread", HeldThread):
        window._complete_validation_range_drag(44, 56)
    with patch.object(flow, "_emit_range_replay_completed", side_effect=completions.append):
        jobs[0]()
    payload, = completions
    assert payload["snapshot"] is not None and not payload["error"]
    assert id(window) in flow._range_replay_active
    snapshot = turn_on(case, window)
    before = window.canvas.marker_records()
    flow._on_range_replay_completed(payload)
    wait_for(case, lambda: window._visualization_projection_active is None)
    assert id(window) not in flow._range_replay_active
    assert window.validation_range is None and window.canvas.validation_range is None
    assert window.replay_snapshot is None and not window._range_replay_entries_available
    assert window._marking_snapshot is snapshot
    assert window.canvas.marker_records() == before
    assert not window.completed_cycles and window.completed_cycle_table.rowCount() == 0


def test_manual_inside_replaces_marking_evidence_same_bar_and_avg_only_manual(case):
    window, flow = connected(case, evaluator=position_evaluator)
    turn_on(case, window)
    marked = [m for m in window.canvas.marker_records() if m["provenance"] == "marking"]
    assert {(m["evaluation_index"], m["side"]) for m in marked} == {(42, "BUY"), (45, "BUY"), (55, "SELL")}
    assert "2차" in next(m["tooltip"] for m in marked if m["evaluation_index"] == 45)
    assert not window.canvas._completed_cycle_average_lines
    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    records = window.canvas.marker_records()
    # Keep frozen evidence outside selection, never under the new manual markers.
    assert [m for m in records if m["provenance"] == "marking"] == [
        m for m in marked if not 44 <= m["evaluation_index"] <= 56
    ]
    pair = [m for m in records if m["evaluation_index"] == 45]
    assert len(pair) == 1
    assert "1차" in next(m["tooltip"] for m in pair if m["provenance"] == "manual")
    assert window.canvas._completed_cycle_average_lines
    window.show()
    case.app.processEvents()
    tooltip = window.canvas.marker_tooltip_at(window.canvas._x_for_index(45), window.canvas._marker_y(45, "BUY"))
    assert tooltip == next(m["tooltip"] for m in pair if m["provenance"] == "manual")
    assert "1차" in tooltip and "2차" not in tooltip
    assert "마킹" not in tooltip and "선택 기간" not in tooltip
    replay = window.replay_snapshot
    view = window._current_chart_view_state()
    manual = [m for m in records if m["provenance"] == "manual"]
    assert {(m["evaluation_index"], m["side"]) for m in records} == {
        (42, "BUY"), (45, "BUY"), (55, "SELL"),
    }
    window.marking_display_check.setChecked(False)
    assert window.replay_snapshot is replay and window.validation_range == (44, 56)
    assert window._current_chart_view_state() == view
    assert window.canvas.marker_records() == manual
    assert window.canvas._completed_cycle_average_lines
    turn_on(case, window)
    window._clear_validation_range_interaction()
    assert [m for m in window.canvas.marker_records() if m["provenance"] == "marking"] == marked
    assert window.canvas.marker_tooltip_at(window.canvas._x_for_index(45), window.canvas._marker_y(45, "BUY")) == next(
        m["tooltip"] for m in marked if m["evaluation_index"] == 45)
    assert window.canvas.pinned_marker_key is None
    assert not window.canvas._completed_cycle_average_lines


def test_manual_outside_resets_before_request_and_replays_original_range(case):
    window, flow = connected(case, evaluator=position_evaluator)
    turn_on(case, window)
    observed = []
    window.validation_range_evaluation_requested.connect(lambda a, b: observed.append(window.marking_display_check.isChecked()))
    window._complete_validation_range_drag(30, 55)
    assert observed == [False]
    assert window._marking_times is None
    wait_for(case, lambda: window._range_replay_entries_available)
    assert window.validation_range == (30, 55)
    assert not any(m["provenance"] == "marking" for m in window.canvas.marker_records())


def test_history_display_extension_preserves_marker_timestamps_and_evidence(case):
    window, flow = connected(case, evaluator=position_evaluator)
    rows = deepcopy(window._calculation_candles)
    settings = window._result_settings_snapshot
    window.set_historical_display_candles(rows[30:])
    window.install_normal_base(settings, "M1")
    window._set_time_view(10, 30)
    turn_on(case, window)
    before = window.canvas.marker_records()
    times = window._marking_times
    window.set_historical_display_candles(rows)
    window.install_normal_base(settings, "M1")
    after = window.canvas.marker_records()
    assert window._marking_times == times
    assert [(m["evaluation_time"], m["tooltip"]) for m in after] == [(m["evaluation_time"], m["tooltip"]) for m in before]
    assert [m["evaluation_index"] for m in after] == [m["evaluation_index"] + 30 for m in before]


def test_history_prefix_prepend_retains_frozen_result_but_next_on_recomputes(case):
    window, flow = connected(case, evaluator=position_evaluator)
    snapshot = turn_on(case, window)
    before = window.canvas.marker_records()
    rows = candles(120)
    assert rows[-100:] == window._calculation_candles
    settings = window._result_settings_snapshot
    window.set_historical_candle_pool(rows, chart_candle_count=120)
    window.install_normal_base(settings, "M1")
    after = window.canvas.marker_records()
    assert window._marking_snapshot is snapshot
    assert [(m["evaluation_time"], m["tooltip"]) for m in after] == [(m["evaluation_time"], m["tooltip"]) for m in before]
    assert [m["evaluation_index"] for m in after] == [m["evaluation_index"] + 20 for m in before]
    old_key = window._marking_key
    window.marking_display_check.setChecked(False)
    window._set_time_view(60, 30)
    turn_on(case, window)
    assert window._marking_key != old_key
    assert window._marking_snapshot is not snapshot


def test_completed_but_queued_result_is_rejected_after_source_change(case):
    window, flow = connected(case)
    turn_on(case, window)
    payload = dict(window_key=id(window), generation=window._marking_generation,
                   key=window._marking_key, request_generation=0,
                   snapshot=window._marking_snapshot, comparison=window._marking_comparison_cache)
    window._calculation_candles[50]["close"] += 100
    flow._on_marking_completed(payload)
    assert window._marking_snapshot is None
    assert not window.marking_display_check.isChecked()
    assert not any(m["provenance"] == "marking" for m in window.canvas.marker_records())


@pytest.mark.parametrize("visible_slice", [
    slice(0, 30), slice(0, 55), slice(55, None), slice(75, None),
])
def test_marking_frozen_after_display_only_viewport_clip(case, visible_slice):
    """A display-only viewport change must not revoke a frozen source result."""
    window, flow = connected(case, evaluator=position_evaluator)
    original_snapshot = turn_on(case, window)
    original_markers = [
        (record["evaluation_time"], record["tooltip"], record["provenance"])
        for record in window.canvas.marker_records()
    ]
    assert original_markers
    frozen_times = window._marking_times
    frozen_key = window._marking_key
    frozen_generation = window._marking_generation
    original_calculation = deepcopy(window._calculation_candles)
    source = deepcopy(window._candles)
    window.set_historical_display_candles(source[visible_slice])
    window.install_normal_base(window._result_settings_snapshot, "M1")
    assert window.marking_display_check.isChecked()
    assert window._marking_snapshot is original_snapshot
    assert window._marking_times == frozen_times
    assert window._marking_key == frozen_key
    assert window._marking_generation == frozen_generation
    assert window._calculation_candles == original_calculation
    # Restore the full display without rescanning or reactivating marking.
    window.set_historical_display_candles(source)
    window.install_normal_base(window._result_settings_snapshot, "M1")
    assert window.marking_display_check.isChecked()
    assert window._marking_snapshot is original_snapshot
    assert window._marking_times == frozen_times
    assert [
        (record["evaluation_time"], record["tooltip"], record["provenance"])
        for record in window.canvas.marker_records()
    ] == original_markers


@pytest.mark.parametrize("change", ["insert_in_range", "drop_in_range"])
def test_marking_source_overlap_changes_still_invalidate(case, change):
    """Viewport retention must never excuse genuinely changed visible evidence."""
    window, flow = connected(case, evaluator=position_evaluator)
    turn_on(case, window)
    altered = deepcopy(window._candles)
    if change == "insert_in_range":
        altered.insert(50, dict(altered[49], time=altered[49]["time"][:12] + "30"))
    else:
        altered.pop(49)
    window.set_historical_display_candles(
        altered, display_only_integrated=change == "insert_in_range",
    )
    window.install_normal_base(window._result_settings_snapshot, "M1")
    assert not window.marking_display_check.isChecked()
    assert window._marking_times is None
    assert window._marking_snapshot is None
    assert window._marking_key is None

@pytest.mark.parametrize("mixed", [False, True])
def test_marking_display_only_ohlcv_refresh_keeps_frozen_evidence(case, mixed):
    """Presentation-only price/volume changes must not invalidate calculation."""
    window, flow = connected(case, evaluator=position_evaluator)
    snapshot = turn_on(case, window)
    previous_key = window._marking_key
    previous_times = window._marking_times
    before_markers = [
        (m["evaluation_time"], m["tooltip"], m["provenance"])
        for m in window.canvas.marker_records()
    ]
    untouched_calculation = deepcopy(window._calculation_candles)
    display = deepcopy(window._candles)
    display[49]["close"] += 17
    display[49]["volume"] += 123
    window.set_historical_display_candles(display, display_only_integrated=mixed)
    window.install_normal_base(window._result_settings_snapshot, "M1")
    assert window._calculation_candles == untouched_calculation
    assert window.marking_display_check.isChecked()
    assert window._marking_key == previous_key
    assert window._marking_times == previous_times
    assert window._marking_snapshot is snapshot
    assert [
        (m["evaluation_time"], m["tooltip"], m["provenance"])
        for m in window.canvas.marker_records()
    ] == before_markers

def test_price_axis_wheel_with_marking_never_requests_history(case):
    """Price-scale wheel is not a request to browse older candles."""
    from PyQt5.QtCore import QPointF
    from PyQt5.QtGui import QWheelEvent
    from PyQt5.QtWidgets import QApplication
    from PyQt5.QtTest import QTest

    window, flow = connected(case, evaluator=position_evaluator)
    window.show()
    case.app.processEvents()
    turn_on(case, window)
    source_times, snapshot = window._marking_times, window._marking_snapshot
    window._set_time_view(0, 30, manually_adjusted=True)
    assert window._history_extension_is_needed()
    emitted = []
    window.historical_extension_requested.connect(lambda: emitted.append("history"))
    scale = window.canvas.price_scale()
    assert scale is not None
    cursor_y = (scale.plot_top + scale.plot_bottom) / 2
    axis = window.fixed_price_axis
    pos = QPoint(
        axis.width() // 2,
        round(window.chart_scroll_area.viewport().geometry().top() + cursor_y),
    )
    QApplication.sendEvent(axis, QWheelEvent(
        QPointF(pos), QPointF(axis.mapToGlobal(pos)), QPoint(),
        QPoint(0, -120), Qt.NoButton, Qt.NoModifier, Qt.NoScrollPhase, False,
    ))
    window._flush_pending_wheel_zoom()
    QTest.qWait(850)
    case.app.processEvents()
    assert not emitted
    assert window.marking_display_check.isChecked()
    assert window._marking_times == source_times
    assert window._marking_snapshot is snapshot

def test_time_axis_wheel_disables_marking_and_still_requests_history(case):
    """Actual horizontal zoom revokes marking without changing prefetch."""
    from PyQt5.QtCore import QPoint, QPointF
    from PyQt5.QtGui import QWheelEvent
    from PyQt5.QtWidgets import QApplication
    from PyQt5.QtTest import QTest

    window, flow = connected(case, evaluator=position_evaluator)
    window.show()
    case.app.processEvents()
    turn_on(case, window)
    generation = window._marking_generation
    window._set_time_view(0, 30, manually_adjusted=True)
    assert window._history_extension_is_needed()
    emitted = []
    window.historical_extension_requested.connect(lambda: emitted.append("history"))
    pos = QPoint(window.canvas._LEFT + 100, window.canvas.height() // 2)
    QApplication.sendEvent(window.canvas, QWheelEvent(
        QPointF(pos), QPointF(window.canvas.mapToGlobal(pos)), QPoint(),
        QPoint(0, -120), Qt.NoButton, Qt.NoModifier, Qt.NoScrollPhase, False,
    ))
    window._flush_pending_wheel_zoom()
    QTest.qWait(850)
    case.app.processEvents()
    assert emitted
    assert not window.marking_display_check.isChecked()
    assert window._marking_generation == generation + 1
    assert window._marking_snapshot is None


def test_time_scrollbar_change_disables_marking_but_noop_does_not(case):
    window, _flow = connected(case, evaluator=position_evaluator)
    frozen = turn_on(case, window)
    generation = window._marking_generation
    current = window.time_navigation_scrollbar.value()

    window.time_navigation_scrollbar.sliderPressed.emit()
    window.time_navigation_scrollbar.setValue(current)
    window.time_navigation_scrollbar.sliderReleased.emit()
    assert window.marking_display_check.isChecked()
    assert window._marking_snapshot is frozen
    assert window._marking_generation == generation

    window.time_navigation_scrollbar.sliderPressed.emit()
    window.time_navigation_scrollbar.setValue(current - window._TIME_SCROLL_UNITS_PER_CANDLE)
    window.time_navigation_scrollbar.sliderReleased.emit()
    window._flush_pending_time_navigation()
    assert not window.marking_display_check.isChecked()
    assert window._marking_generation == generation + 1


def test_vertical_price_drag_and_click_keep_marking(case):
    from PyQt5.QtCore import QPointF, QEvent
    from PyQt5.QtGui import QMouseEvent
    from PyQt5.QtWidgets import QApplication

    window, _flow = connected(case, evaluator=position_evaluator)
    window.resize(1200, 820)
    window.show()
    case.app.processEvents()
    frozen = turn_on(case, window)
    generation = window._marking_generation
    canvas = window.canvas
    x = round(canvas._LEFT + canvas._plot_width() * 0.7)
    y = round((canvas.price_scale().plot_top + canvas.price_scale().plot_bottom) / 2)
    before_price = window.current_price_bounds

    QTest.mousePress(canvas, Qt.LeftButton, pos=QPoint(x, y))
    QApplication.sendEvent(canvas, QMouseEvent(
        QEvent.MouseMove, QPointF(x, y + 80),
        Qt.NoButton, Qt.LeftButton, Qt.NoModifier,
    ))
    QTest.mouseRelease(canvas, Qt.LeftButton, pos=QPoint(x, y + 80))
    case.app.processEvents()
    assert window.current_price_bounds != before_price
    assert window.marking_display_check.isChecked()
    assert window._marking_snapshot is frozen
    assert window._marking_generation == generation

    QTest.mouseClick(canvas, Qt.LeftButton, pos=QPoint(x, y))
    assert window.marking_display_check.isChecked()
    assert window._marking_snapshot is frozen
    assert window._marking_generation == generation


def test_programmatic_viewport_restore_keeps_marking(case):
    window, _flow = connected(case, evaluator=position_evaluator)
    frozen = turn_on(case, window)
    generation = window._marking_generation
    state = replace(
        window._current_chart_view_state(),
        visible_start_index=20,
        visible_candle_span=35,
    )

    window._restore_chart_view_state(state)

    assert (window.visible_start_index, window.visible_candle_span) == (20, 35)
    assert window.marking_display_check.isChecked()
    assert window._marking_snapshot is frozen
    assert window._marking_generation == generation

@pytest.mark.parametrize("edge", ["latest", "oldest", "all_latest", "all_oldest"])
def test_marking_time_drag_noop_edge_only_oldest_requests_history(case, edge):
    """At latest edge a saturated newer drag must not fetch old candles."""
    from PyQt5.QtCore import QPoint, QPointF, QEvent
    from PyQt5.QtGui import QMouseEvent
    from PyQt5.QtWidgets import QApplication
    from PyQt5.QtTest import QTest

    window, flow = connected(case, evaluator=position_evaluator)
    window.resize(1200, 820)
    window.show()
    case.app.processEvents()
    all_visible = edge.startswith("all_")
    initial_start = 0 if all_visible or edge.endswith("oldest") else 30
    window._set_time_view(initial_start, 100 if all_visible else 70, manually_adjusted=True)
    frozen = turn_on(case, window)
    original_times = window._marking_times
    original_view = (window.visible_start_index, window.visible_candle_span)
    assert window._history_extension_is_needed()
    requests = []
    window.historical_extension_requested.connect(lambda: requests.append("history"))
    canvas = window.canvas
    x = 400
    y = round((canvas.price_scale().plot_top + canvas.price_scale().plot_bottom) / 2)
    direction = -1 if edge.endswith("latest") else 1
    QTest.mousePress(canvas, Qt.LeftButton, pos=QPoint(x, y))
    for offset in (12, 45, 98, 145):
        QApplication.sendEvent(canvas, QMouseEvent(
            QEvent.MouseMove, QPointF(x + direction * offset, y),
            Qt.NoButton, Qt.LeftButton, Qt.NoModifier,
        ))
        case.app.processEvents()
    assert canvas._time_pan_preview_offset_x == 0
    assert (window.visible_start_index, window.visible_candle_span) == original_view
    QTest.mouseRelease(canvas, Qt.LeftButton, pos=QPoint(x + direction * 145, y))
    QTest.qWait(850)
    case.app.processEvents()
    assert requests == (["history"] if edge.endswith("oldest") else [])
    assert window.marking_display_check.isChecked()
    assert window._marking_times == original_times
    assert window._marking_snapshot is frozen

def test_marking_drag_into_latest_edge_does_not_prefetch_old_history(case):
    """Moving toward newer bars must not request older history on saturation."""
    from PyQt5.QtCore import QPoint, QPointF, QEvent
    from PyQt5.QtGui import QMouseEvent
    from PyQt5.QtWidgets import QApplication
    from PyQt5.QtTest import QTest

    window, flow = connected(case, evaluator=position_evaluator)
    window.resize(1200, 820)
    window.show()
    case.app.processEvents()
    window._set_time_view(28, 70, manually_adjusted=True)
    turn_on(case, window)
    generation = window._marking_generation
    requests = []
    window.historical_extension_requested.connect(lambda: requests.append("history"))
    canvas = window.canvas
    x, y = 400, round((canvas.price_scale().plot_top + canvas.price_scale().plot_bottom) / 2)
    QTest.mousePress(canvas, Qt.LeftButton, pos=QPoint(x, y))
    for offset in (-24, -80, -160):
        QApplication.sendEvent(canvas, QMouseEvent(
            QEvent.MouseMove, QPointF(x + offset, y),
            Qt.NoButton, Qt.LeftButton, Qt.NoModifier,
        ))
        case.app.processEvents()
    QTest.mouseRelease(canvas, Qt.LeftButton, pos=QPoint(x - 160, y))
    QTest.qWait(850)
    case.app.processEvents()
    assert window.visible_start_index == window._maximum_visible_start()
    assert not requests
    assert not window.marking_display_check.isChecked()
    assert window._marking_generation == generation + 1
    assert window._marking_snapshot is None

def test_marking_drag_reversal_back_to_latest_cancels_old_history_intent(case):
    """An older request queued mid-drag must die when the user reverses newer."""
    from PyQt5.QtCore import QPoint, QPointF, QEvent
    from PyQt5.QtGui import QMouseEvent
    from PyQt5.QtWidgets import QApplication
    from PyQt5.QtTest import QTest

    window, flow = connected(case, evaluator=position_evaluator)
    window.resize(1200, 820)
    window.show()
    case.app.processEvents()
    window._set_time_view(28, 70, manually_adjusted=True)
    turn_on(case, window)
    generation = window._marking_generation
    requested = []
    window.historical_extension_requested.connect(lambda: requested.append("history"))
    canvas = window.canvas
    x, y = 400, round((canvas.price_scale().plot_top + canvas.price_scale().plot_bottom) / 2)
    QTest.mousePress(canvas, Qt.LeftButton, pos=QPoint(x, y))
    for offset in (45, -45, -165):
        QApplication.sendEvent(canvas, QMouseEvent(
            QEvent.MouseMove, QPointF(x + offset, y),
            Qt.NoButton, Qt.LeftButton, Qt.NoModifier,
        ))
        case.app.processEvents()
    QTest.mouseRelease(canvas, Qt.LeftButton, pos=QPoint(x - 165, y))
    QTest.qWait(850)
    case.app.processEvents()
    assert window.visible_start_index == window._maximum_visible_start()
    assert not requested
    assert not window.marking_display_check.isChecked()
    assert window._marking_generation == generation + 1
    assert window._marking_snapshot is None

def test_marking_off_caller_diagnostic_records_context_before_reset(case):
    """Opt-in trace identifies the real caller without changing OFF semantics."""
    window, flow = connected(case, evaluator=position_evaluator)
    turn_on(case, window)
    before_generation = window._marking_generation
    before_times = window._marking_times
    saved_snapshot = window._marking_snapshot
    events = []
    with patch.object(wm, "signal_validation_trace_enabled", return_value=True), \
         patch.object(wm, "trace_signal_validation_event",
                      side_effect=lambda event, **fields: events.append((event, fields))):
        window._disable_marking(clear_cache=True, refresh=False,
                                reason="test_diagnostic")
    diagnostics = [fields for event, fields in events
                   if event == "window.marking.disabled.caller"]
    assert len(diagnostics) == 1
    event = diagnostics[0]
    assert event["reason"] == "test_diagnostic"
    assert event["active"] is True and event["checkbox_on"] is True
    assert event["marking_generation"] == before_generation
    assert event["frozen_times"] == before_times
    assert event["frozen_source_start"]
    assert event["calculation"]["count"] == len(window._calculation_candles)
    assert event["display"]["count"] == len(window._candles)
    assert event["caller_path"][0][1] == (
        "test_marking_off_caller_diagnostic_records_context_before_reset"
    )
    assert event["flow_request_generation"] is None
    assert saved_snapshot is not None
    assert not window.marking_display_check.isChecked()
    assert window._marking_times is None


def test_marking_flow_failure_trace_records_caller_error_and_work_generation(case):
    """Async failure owns its error and flow generation at the OFF boundary."""
    window, flow = connected(case, evaluator=position_evaluator)
    turn_on(case, window)
    event_log = []
    request = {
        "window_key": id(window),
        "generation": window._marking_generation,
        "key": window._marking_key,
        "request_generation": flow._request_generation[id(window)],
        "error": "DIAGNOSTIC_SYNTHETIC_FAILURE",
    }
    with patch.object(wm, "signal_validation_trace_enabled", return_value=True), \
         patch.object(wm, "trace_signal_validation_event",
                      side_effect=lambda event, **fields: event_log.append((event, fields))):
        flow._on_marking_completed(request)
    diagnostics = [fields for event, fields in event_log
                   if event == "window.marking.disabled.caller"]
    assert len(diagnostics) == 1
    event = diagnostics[0]
    assert event["reason"] == "context_reset"
    assert event["caller_path"][0][1] == "_on_marking_completed"
    assert event["flow_request_generation"] == request["request_generation"]
    assert event["flow_history_target"] == flow._history_targets[id(window)]
    assert event["failure_type"] == "ValueError"
    assert "DIAGNOSTIC_SYNTHETIC_FAILURE" in event["failure_detail"]
    assert not window.marking_display_check.isChecked()


def test_marking_off_diagnostic_exception_cannot_affect_reset(case):
    """A broken trace sink must not prevent safe marking cancellation."""
    window, flow = connected(case, evaluator=position_evaluator)
    turn_on(case, window)
    with patch.object(wm, "signal_validation_trace_enabled", return_value=True), \
         patch.object(wm, "trace_signal_validation_event",
                      side_effect=RuntimeError("diagnostic file failed")):
        window._disable_marking(clear_cache=True, refresh=False)
    assert window._marking_times is None
    assert window._marking_snapshot is None
    assert not window.marking_display_check.isChecked()

def test_marking_off_trace_writes_jsonl_when_opted_in(case, tmp_path):
    """A real opt-in record must be readable without affecting broker state."""
    import json
    import indicator_follow_signal_validation_runtime_trace as runtime_trace

    window, flow = connected(case, evaluator=position_evaluator)
    turn_on(case, window)
    trace_path = tmp_path / "marking_disable.jsonl"
    with patch.dict("os.environ", {"KIWOOM_SIGNAL_VALIDATION_TRACE": "1"}), \
         patch.object(runtime_trace, "_TRACE_PATH", trace_path):
        window._disable_marking(clear_cache=True, refresh=False,
                                reason="jsonl_contract_probe")
    records = [json.loads(line) for line in trace_path.read_text(encoding="utf-8").splitlines()]
    matching = [row for row in records
                if row["event"] == "window.marking.disabled.caller"]
    assert len(matching) == 1
    row = matching[0]
    assert row["reason"] == "jsonl_contract_probe"
    assert row["pid"] and row["window_key"] == id(window)
    assert row["stock_code"] == window.stock.code
    assert row["caller_path"][0][1] == "test_marking_off_trace_writes_jsonl_when_opted_in"
    assert row["calculation"]["count"] == len(window._calculation_candles)

@pytest.mark.parametrize("final_revision", ["original", "changed_display", "changed_calculation"])
def test_marking_mixed_display_history_rebuild_is_not_a_new_source(case, final_revision):
    """KRX placeholder during NXT repaint is not an authoritative display revision."""
    window, flow = connected(case, evaluator=position_evaluator)
    authoritative = deepcopy(window._calculation_candles)
    mixed = [deepcopy(candle) for i, candle in enumerate(authoritative)
             if i not in (50, 53)]
    window.set_historical_display_candles(mixed, display_only_integrated=True)
    window.install_normal_base(window._result_settings_snapshot, "M1")
    assert window._display_only_integrated_active
    snapshot = turn_on(case, window)
    original_key, original_times = window._marking_key, window._marking_times
    original_markers = [
        (record["evaluation_time"], record["tooltip"], record["provenance"])
        for record in window.canvas.marker_records()
    ]
    incoming = deepcopy(authoritative)
    if final_revision == "changed_calculation":
        incoming[40]["close"] += 17
    # Two-stage refresh: the old integrated display is reset to KRX first.
    window.set_historical_candle_pool(incoming, chart_candle_count=100)
    window.set_historical_display_candles(incoming)
    window.install_normal_base(window._result_settings_snapshot, "M1")
    if final_revision == "changed_calculation":
        assert not window.marking_display_check.isChecked()
        return
    assert window.marking_display_check.isChecked()
    assert window._marking_snapshot is snapshot
    restored = deepcopy(mixed)
    if final_revision == "changed_display":
        restored.pop(52)
    window.set_historical_display_candles(restored, display_only_integrated=True)
    window.install_normal_base(window._result_settings_snapshot, "M1")
    if final_revision == "changed_display":
        assert not window.marking_display_check.isChecked()
    else:
        assert window.marking_display_check.isChecked()
        assert window._marking_snapshot is snapshot
        assert window._marking_key == original_key
        assert window._marking_times == original_times
        assert [
            (record["evaluation_time"], record["tooltip"], record["provenance"])
            for record in window.canvas.marker_records()
        ] == original_markers

def test_marking_reprojection_survives_two_pool_updates_before_mixed_display(case):
    """Two cache stages may publish raw KRX placeholders before NXT returns."""
    from datetime import datetime, timedelta

    window, flow = connected(case, evaluator=position_evaluator)
    original = deepcopy(window._calculation_candles)
    projected = [deepcopy(row) for i, row in enumerate(original)
                 if i not in (50, 53)]
    window.set_historical_display_candles(projected, display_only_integrated=True)
    window.install_normal_base(window._result_settings_snapshot, "M1")
    frozen = turn_on(case, window)
    times = window._marking_times
    before = [
        (item["evaluation_time"], item["tooltip"], item["provenance"])
        for item in window.canvas.marker_records()
    ]

    window.set_historical_candle_pool(original, chart_candle_count=100)
    window.set_historical_display_candles(original)
    window.install_normal_base(window._result_settings_snapshot, "M1")
    assert window._marking_display_reprojection_pending
    assert window.marking_display_check.isChecked()

    older = dict(
        original[0],
        time=(datetime.strptime(original[0]["time"], "%Y%m%d%H%M%S")
              - timedelta(minutes=1)).strftime("%Y%m%d%H%M%S"),
    )
    expanded = [older] + original
    window.set_historical_candle_pool(expanded, chart_candle_count=100)
    window.set_historical_display_candles(expanded[-100:])
    window.install_normal_base(window._result_settings_snapshot, "M1")
    assert window._marking_display_reprojection_pending
    assert window.marking_display_check.isChecked()

    window.set_historical_display_candles(projected, display_only_integrated=True)
    window.install_normal_base(window._result_settings_snapshot, "M1")
    assert not window._marking_display_reprojection_pending
    assert window.marking_display_check.isChecked()
    assert window._marking_times == times
    assert window._marking_snapshot is frozen
    assert [
        (item["evaluation_time"], item["tooltip"], item["provenance"])
        for item in window.canvas.marker_records()
    ] == before

def test_marking_unflagged_transitional_display_replacement_stays_frozen(case):
    """A raw fallback is provisional even when previous display lacked mixed flag."""
    window, flow = connected(case, evaluator=position_evaluator)
    authoritative = deepcopy(window._calculation_candles)
    prior_display = [deepcopy(row) for i, row in enumerate(authoritative)
                     if i not in (50, 53, 56, 59)]
    window.set_historical_display_candles(prior_display)
    window.install_normal_base(window._result_settings_snapshot, "M1")
    assert not window._display_only_integrated_active
    frozen = turn_on(case, window)
    original_key, original_times = window._marking_key, window._marking_times
    window.set_historical_candle_pool(deepcopy(authoritative), chart_candle_count=100)
    window.set_historical_display_candles(deepcopy(authoritative))
    window.install_normal_base(window._result_settings_snapshot, "M1")
    assert window.marking_display_check.isChecked()
    assert window._marking_snapshot is frozen
    assert window._marking_display_reprojection_pending

    window.set_historical_display_candles(deepcopy(prior_display))
    window.install_normal_base(window._result_settings_snapshot, "M1")
    assert window.marking_display_check.isChecked()
    assert not window._marking_display_reprojection_pending
    assert window._marking_snapshot is frozen
    assert (window._marking_key, window._marking_times) == (
        original_key, original_times
    )

@pytest.mark.parametrize("final_change", [False, True])
def test_marking_integrated_intermediate_published_before_final_sidecar(case, final_change):
    """Interim mixed view during pool installation is not a final publication."""
    window, flow = connected(case, evaluator=position_evaluator)
    canonical = deepcopy(window._calculation_candles)
    frozen_display = [deepcopy(row) for i, row in enumerate(canonical)
                      if i not in (50, 53, 56, 59)]
    window.set_historical_display_candles(frozen_display, display_only_integrated=True)
    window.install_normal_base(window._result_settings_snapshot, "M1")
    snapshot = turn_on(case, window)
    frozen_times = window._marking_times
    window.set_historical_candle_pool(deepcopy(canonical), chart_candle_count=100)
    window.set_historical_display_candles(deepcopy(canonical), display_only_integrated=True)
    window.install_normal_base(window._result_settings_snapshot, "M1")
    assert window.marking_display_check.isChecked()
    assert window._marking_snapshot is snapshot
    assert window._marking_display_reprojection_pending

    final_display = deepcopy(frozen_display)
    if final_change:
        final_display.pop(51)
    window.set_historical_display_candles(final_display, display_only_integrated=True)
    window.install_normal_base(window._result_settings_snapshot, "M1")
    assert not window._marking_display_reprojection_pending
    if final_change:
        assert not window.marking_display_check.isChecked()
        assert window._marking_snapshot is None
    else:
        assert window.marking_display_check.isChecked()
        assert window._marking_snapshot is snapshot
        assert window._marking_times == frozen_times


@pytest.mark.parametrize("calculation_change", [False, True])
def test_pending_integrated_sidecar_finishes_atomic_marking_publication(
    case, calculation_change,
):
    """A final 1,000-bar sidecar cannot stop behind active marking evidence."""
    signal_times = {}
    sell_average_prices = []

    def evaluator(prefix, rules, context):
        stamp = prefix[-1]["time"]
        side = context["_indicator_follow_evaluate_side"]
        if side == "SELL" and stamp == signal_times.get("sell"):
            sell_average_prices.append(context.get("average_price"))
        signal = (
            "BUY"
            if side == "BUY" and stamp == signal_times.get("buy")
            else "SELL"
            if (
                side == "SELL"
                and stamp == signal_times.get("sell")
                and context.get("average_price") is not None
            )
            else None
        )
        return legacy.RoutineSignal(
            signal, "atomic sidecar fixture", [], [], len(prefix) - 1 if signal else -1, 0,
        )

    window, flow = connected(case, count=500, evaluator=evaluator)
    window._set_time_view(140, 30)
    signal_times.update(
        buy=window._candles[145]["time"],
        sell=window._candles[160]["time"],
    )
    original_snapshot = turn_on(case, window)
    frozen_times = window._marking_times
    expected_markers = {
        (signal_times["buy"], "BUY", "marking"),
        (signal_times["sell"], "SELL", "marking"),
    }
    assert {
        (item["evaluation_time"], item["side"], item["provenance"])
        for item in window.canvas.marker_records()
    } == expected_markers
    assert any(value is not None for value in sell_average_prices)

    expanded = candles(1900)
    key = id(window)
    session = flow._validation_sessions[key]
    pool = flow._pool_from_candles(
        session, expanded, requested_count=1900, request_id="MARKING-EXPANDED",
        market_data_identity=case.stock.code, market_source="KRX",
    )
    flow._historical_pools[key] = pool
    flow._history_targets[key] = 1000

    # Reproduce the observed 1,000 calculation -> stale 500 display stage.
    window.set_historical_candle_pool(expanded, chart_candle_count=1000)
    window.set_historical_display_candles(
        expanded[-500:], display_only_integrated=True,
    )
    window.install_normal_base(window._result_settings_snapshot, "M1")
    assert len(window._calculation_candles) == 1900
    assert len(window._candles) == 500
    assert window._marking_snapshot is original_snapshot
    assert window.marking_display_check.isChecked()

    final_sidecar = deepcopy(expanded[-1000:])
    inserted_time = None
    if calculation_change:
        inserted_time = frozen_times[0][:8] + "080000"
        premarket = dict(
            expanded[-1], time=inserted_time, open=91_000, high=91_200,
            low=90_900, close=91_100, volume=321,
        )
        final_sidecar.append(premarket)
        final_sidecar.sort(key=lambda row: row["time"])
    sidecar_key = flow._integrated_display_sidecar_key(session)
    flow._integrated_display_sidecars[sidecar_key] = {
        "stock_code": case.stock.code,
        "timeframe_key": session.request.timeframe_key,
        "timeframe_minutes": session.request.timeframe_minutes,
        "requested_count": 1000,
        "coverage_count": len(final_sidecar),
        "market_data_identity": f"{case.stock.code}_AL",
        "market_source": "INTEGRATED",
        "verified_nxt_eligible": True,
        "display_only": True,
        "request_as_of": "2026-10-07T21:00:00+09:00",
        "candles": final_sidecar,
    }
    if calculation_change:
        assert [row["time"] for row in flow._verified_validation_premarket_candles(
            session, flow._integrated_display_sidecars[sidecar_key],
        )] == [inserted_time]

    jobs = []

    class HeldThread:
        def __init__(self, *, target, **_kwargs):
            jobs.append(target)

        def start(self):
            pass

    with patch.object(fm, "Thread", HeldThread):
        flow._apply_integrated_display_sidecar(window, session)

    # Background preparation must leave the previous evidence visibly intact.
    assert len(jobs) == 1
    assert len(window._candles) == 500
    assert window._marking_snapshot is original_snapshot
    assert window.marking_display_check.isChecked()

    jobs[0]()
    case.app.processEvents()

    assert len(window._candles) == 1000
    assert window._display_only_integrated_candles == window._candles
    assert window._visualization_cache.candle_count == 1000
    assert window._marking_times == frozen_times
    assert window.marking_display_check.isChecked()
    assert {
        (item["evaluation_time"], item["side"], item["provenance"])
        for item in window.canvas.marker_records()
    } == expected_markers
    assert any(value is not None for value in sell_average_prices)
    if calculation_change:
        assert inserted_time in {
            row["time"] for row in window._calculation_candles
        }
        assert inserted_time in {row["time"] for row in window._candles}
        assert window._marking_snapshot is not original_snapshot
    else:
        assert window._calculation_candles == expanded
        assert window._marking_snapshot is original_snapshot
    with patch.object(fm, "Thread", side_effect=AssertionError("duplicate revision")):
        flow._apply_integrated_display_sidecar(window, session)


def test_pending_integrated_sidecar_rejects_stale_completion(case):
    window, flow = connected(case, count=500, evaluator=position_evaluator)
    original_snapshot = turn_on(case, window)
    original_calculation = deepcopy(window._calculation_candles)
    original_display = deepcopy(window._candles)
    expanded = candles(1400)
    key = id(window)
    session = flow._validation_sessions[key]
    flow._historical_pools[key] = flow._pool_from_candles(
        session, expanded, requested_count=1400, request_id="STALE-SIDECAR",
        market_data_identity=case.stock.code, market_source="KRX",
    )
    sidecar_key = flow._integrated_display_sidecar_key(session)
    flow._integrated_display_sidecars[sidecar_key] = {
        "stock_code": case.stock.code,
        "timeframe_key": session.request.timeframe_key,
        "timeframe_minutes": session.request.timeframe_minutes,
        "requested_count": 500,
        "coverage_count": 500,
        "market_data_identity": f"{case.stock.code}_AL",
        "market_source": "INTEGRATED",
        "verified_nxt_eligible": True,
        "display_only": True,
        "request_as_of": "2026-10-07T21:00:00+09:00",
        "candles": deepcopy(expanded[-500:]),
    }
    jobs = []

    class HeldThread:
        def __init__(self, *, target, **_kwargs):
            jobs.append(target)

        def start(self):
            pass

    payloads = []
    flow.marking_completed.disconnect(flow._on_marking_completed)
    flow.marking_completed.connect(payloads.append)
    with patch.object(fm, "Thread", HeldThread):
        flow._apply_integrated_display_sidecar(window, session)
    assert len(jobs) == 1
    jobs[0]()
    assert len(payloads) == 1 and not payloads[0]["error"]

    flow._request_generation[key] += 1
    flow._on_marking_completed(payloads[0])

    assert flow._marking_source_revisions[key]["status"] == "rejected"
    assert window._calculation_candles == original_calculation
    assert window._candles == original_display
    assert window._marking_snapshot is original_snapshot
    assert window.marking_display_check.isChecked()


def test_pending_integrated_sidecar_failure_preserves_previous_marking(case):
    window, flow = connected(case, count=500, evaluator=position_evaluator)
    original_snapshot = turn_on(case, window)
    original_calculation = deepcopy(window._calculation_candles)
    original_display = deepcopy(window._candles)
    key = id(window)
    session = flow._validation_sessions[key]
    sidecar_key = flow._integrated_display_sidecar_key(session)
    flow._integrated_display_sidecars[sidecar_key] = {
        "stock_code": case.stock.code,
        "timeframe_key": session.request.timeframe_key,
        "timeframe_minutes": session.request.timeframe_minutes,
        "requested_count": 500,
        "coverage_count": 500,
        "market_data_identity": f"{case.stock.code}_AL",
        "market_source": "INTEGRATED",
        "verified_nxt_eligible": True,
        "display_only": True,
        "request_as_of": "2026-10-07T21:00:00+09:00",
        "candles": deepcopy(original_display),
    }
    jobs = []

    class HeldThread:
        def __init__(self, *, target, **_kwargs):
            jobs.append(target)

        def start(self):
            pass

    with patch.object(fm, "Thread", HeldThread), patch.object(
        flow, "_normal_base_history_view", side_effect=RuntimeError("revision failure"),
    ):
        flow._apply_integrated_display_sidecar(window, session)
        assert len(jobs) == 1
        jobs[0]()

    assert flow._marking_source_revisions[key]["status"] == "error"
    assert "revision failure" in window.marking_display_check.toolTip()
    assert window._calculation_candles == original_calculation
    assert window._candles == original_display
    assert window._marking_snapshot is original_snapshot
    assert window.marking_display_check.isChecked()

def test_idle_chart_never_republishes_full_validation_markers(case):
    """Approved marking/range owns triangles; idle full replay is retained only as evidence."""
    window, flow = connected(case, evaluator=position_evaluator)
    session = flow._validation_sessions[id(window)]
    pool = flow._historical_pools[id(window)]
    full = flow._prepare_replay_result_from_pool(
        session, pool, history_target=100, evaluation_count=100,
    )
    assert full.ok and full.snapshot is not None
    window.set_replay_snapshot(full.snapshot)
    retained = list(window._marker_entries_for_calculation())
    assert retained, "Fixture must have full-validation markers to expose regression"
    assert not window.marking_display_check.isChecked()
    assert window.validation_range is None
    assert window._marker_entries_for_display() == []
    assert window.canvas.marker_records() == []

    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    selected = window.canvas.marker_records()
    assert selected
    assert all(record["provenance"] == "manual" for record in selected)
    assert all(44 <= record["evaluation_index"] <= 56 for record in selected)
    assert {record["evaluation_time"] for record in selected}.issubset(
        {row["time"] for row in window._candles[44:57]}
    )

    window._clear_validation_range_interaction()
    wait_for(case, lambda: window._visualization_projection_active is None)
    assert window._marker_entries_for_calculation() == retained
    assert not window.marking_display_check.isChecked()
    assert window.validation_range is None
    assert window._marker_entries_for_display() == []
    assert window.canvas.marker_records() == []

def test_range_clear_immediately_removes_rendered_triangles_without_async_worker(case):
    """The old manual glyphs cannot remain visible while projection is pending."""
    window, flow = connected(case, evaluator=position_evaluator)
    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    wait_for(case, lambda: window._visualization_projection_active is None)
    assert window.canvas.marker_records()
    with patch.object(window, "_dispatch_visualization_projection", side_effect=lambda _intent: None):
        window._clear_validation_range_interaction()
        assert window.validation_range is None
        assert window._marker_entries_for_display() == []
        assert window.canvas.marker_records() == []

def test_filter_checkbox_never_revokes_frozen_marking(case):
    """Visibility selection is not a marking, range or trading calculation input."""
    window, flow = connected(case, evaluator=position_evaluator)
    snapshot = turn_on(case, window)
    wait_for(case, lambda: window._visualization_projection_active is None)
    before = (
        window._marking_generation,
        window._marking_key,
        window._marking_times,
        window._marking_settings,
        window._marking_cache,
    )
    old_markers = [
        (m["evaluation_time"], m["side"], m["provenance"])
        for m in window.canvas.marker_records()
    ]
    assert old_markers
    for _ in range(2):
        window.filter_display_check.setChecked(
            not window.filter_display_check.isChecked()
        )
        wait_for(case, lambda: window._visualization_projection_active is None)
        assert window.marking_display_check.isChecked()
        assert window._marking_snapshot is snapshot
        assert (
            window._marking_generation,
            window._marking_key,
            window._marking_times,
            window._marking_settings,
            window._marking_cache,
        ) == before
        assert [
            (m["evaluation_time"], m["side"], m["provenance"])
            for m in window.canvas.marker_records()
        ] == old_markers


def test_filter_checkbox_preserves_manual_range_results(case):
    window, flow = connected(case, evaluator=position_evaluator)
    snapshot = turn_on(case, window)
    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    wait_for(case, lambda: window._visualization_projection_active is None)
    before = (
        window._marking_generation,
        window._marking_times,
        window._validation_range_times,
        window.replay_snapshot,
        window._range_replay_entries_available,
        tuple(window.completed_cycles),
        window.result_summary_label.text(),
        window.estimated_return_label.text(),
    )
    old_markers = [
        (m["evaluation_time"], m["side"], m["provenance"])
        for m in window.canvas.marker_records()
    ]
    window.filter_display_check.setChecked(
        not window.filter_display_check.isChecked()
    )
    wait_for(case, lambda: window._visualization_projection_active is None)
    assert window.marking_display_check.isChecked()
    assert window._marking_snapshot is snapshot
    assert (
        window._marking_generation,
        window._marking_times,
        window._validation_range_times,
        window.replay_snapshot,
        window._range_replay_entries_available,
        tuple(window.completed_cycles),
        window.result_summary_label.text(),
        window.estimated_return_label.text(),
    ) == before
    assert [
        (m["evaluation_time"], m["side"], m["provenance"])
        for m in window.canvas.marker_records()
    ] == old_markers


@pytest.mark.parametrize("side", ("BUY", "SELL"))
def test_price_legend_prefix_resets_visibility_without_changing_filter_universe(case, side):
    window, _flow = connected(case, evaluator=position_evaluator)
    canvas = window.canvas
    canvas.resize(1100, 600)
    canvas.show()
    case.app.processEvents()
    frozen = turn_on(case, window)
    generation = window._marking_generation
    layouts = canvas._price_legend_layout(canvas.price_scale(), canvas.font())
    row = next(row for row in layouts if row["side"] == side and row["blocks"])
    block = row["blocks"][0]["block"]
    identities = tuple(block["descriptor_identities"])
    canvas._toggle_price_legend_identities(row["side"], identities)
    assert canvas.highlighted_price_filter_identities
    assert window._highlighted_price_filter_identities
    window.filter_display_valid_check.setChecked(True)
    valid_identities = canvas.valid_filter_identities
    assert window.filter_display_valid_check.isChecked()
    assert valid_identities
    before = window.visualization_descriptors
    cache = window.visualization_cache
    markers = canvas.marker_records()

    QTest.mouseClick(
        canvas,
        Qt.LeftButton,
        pos=row["prefix_rect"].center().toPoint(),
    )
    case.app.processEvents()

    assert not canvas.highlighted_price_filter_identities
    assert not canvas.hidden_price_filter_identities
    assert not canvas.hide_unhighlighted_price_filters
    assert not window._highlighted_price_filter_identities
    assert not window._hidden_price_filter_identities
    assert not window._hide_unhighlighted_price_filters
    assert not window.filter_display_valid_check.isChecked()
    assert not canvas.valid_filter_identities
    assert window.visualization_descriptors == before
    assert window.visualization_cache is cache
    assert window.visualization_descriptors == window._all_filter_display_descriptors(
        window._result_settings_snapshot.to_dict()
    )
    assert not hasattr(window, "_filter_display_side")
    assert window.marking_display_check.isChecked()
    assert window._marking_snapshot is frozen
    assert window._marking_generation == generation
    assert canvas.marker_records() == markers


def test_price_legend_prefix_turns_valid_off_without_manual_visibility_state(case):
    window, flow = connected(case)
    canvas = window.canvas
    canvas.resize(1100, 600)
    canvas.show()
    case.app.processEvents()
    assert not canvas.highlighted_price_filter_identities
    assert not canvas.hidden_price_filter_identities
    assert not canvas.hide_unhighlighted_price_filters
    assert window.filter_display_check.isChecked()
    window.filter_display_valid_check.setChecked(True)
    assert window.filter_display_valid_check.isChecked()
    assert canvas.valid_filter_identities
    descriptors = window.visualization_descriptors
    cache = window.visualization_cache
    row = next(
        row for row in canvas._price_legend_layout(
            canvas.price_scale(), canvas.font()
        )
        if row["side"] == "BUY" and row["blocks"]
    )

    with patch.object(
        flow,
        "_prepare_replay_result_from_pool",
        side_effect=AssertionError("legend prefix reset must not replay"),
    ), patch.object(
        window,
        "_refresh_filter_display_projection",
        side_effect=AssertionError("legend prefix reset must not project"),
    ), patch.object(
        canvas,
        "set_visualization_projection",
        side_effect=AssertionError("legend prefix reset must not reload canvas"),
    ):
        QTest.mouseClick(
            canvas,
            Qt.LeftButton,
            pos=row["prefix_rect"].center().toPoint(),
        )
        case.app.processEvents()

    assert not window.filter_display_valid_check.isChecked()
    assert not canvas.valid_filter_identities
    assert window.filter_display_check.isChecked()
    assert window._filter_display_enabled
    assert window.visualization_descriptors == descriptors
    assert window.visualization_cache is cache


def test_price_legend_filter_click_and_programmatic_reset_keep_valid_on(case):
    window, _flow = connected(case)
    canvas = window.canvas
    canvas.resize(1100, 600)
    canvas.show()
    case.app.processEvents()
    window.filter_display_valid_check.setChecked(True)
    valid_identities = canvas.valid_filter_identities
    assert valid_identities
    row = next(
        row for row in canvas._price_legend_layout(
            canvas.price_scale(), canvas.font()
        )
        if row["side"] == "BUY" and row["blocks"]
    )

    QTest.mouseClick(
        canvas,
        Qt.LeftButton,
        pos=row["blocks"][0]["rect"].center().toPoint(),
    )
    case.app.processEvents()

    assert window.filter_display_valid_check.isChecked()
    assert canvas.valid_filter_identities == valid_identities
    assert canvas.highlighted_price_filter_identities

    canvas.reset_price_legend_visibility()

    assert window.filter_display_valid_check.isChecked()
    assert canvas.valid_filter_identities == valid_identities


def test_manual_range_and_reprojection_preserve_all_filter_universe(case):
    window, _flow = connected(case, evaluator=position_evaluator)
    wait_for(case, lambda: window._visualization_projection_active is None)
    expected = window._all_filter_display_descriptors(
        window._result_settings_snapshot.to_dict()
    )
    assert window.visualization_descriptors == expected

    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    wait_for(case, lambda: window._visualization_projection_active is None)
    replay = window.replay_snapshot
    assert replay is not None
    assert window.visualization_descriptors == expected

    window._refresh_filter_display_projection()
    wait_for(case, lambda: window._visualization_projection_active is None)
    assert window.visualization_descriptors == expected
    assert window.replay_snapshot is replay
