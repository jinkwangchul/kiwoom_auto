# -*- coding: utf-8 -*-
"""V4-specific regression: broker-limited direct period refresh."""
from __future__ import annotations

from datetime import datetime
import tempfile
import time

from PyQt5.QtCore import QCoreApplication
import pytest

from candle_timeframe_aggregation import SEOUL_TIMEZONE
from gui_indicator_follow_signal_validation_v4_flow import (
    IndicatorFollowSignalValidationV4Flow,
    _SHARED_SIGNAL_VALIDATION_HISTORICAL_POOLS,
)
from indicator_follow_signal_validation_historical_cache import (
    IndicatorFollowSignalValidationHistoricalCache,
)
from indicator_follow_signal_validation_projection import (
    IndicatorFollowSignalValidationRunRequest,
)
from indicator_follow_validation_history_contract import (
    required_validation_history_context_bars,
)
from routines.지표추종매매.routine_validation_contract import (
    ValidationSettingsSnapshot, ValidationStockRef,
)
from tests.test_indicator_follow_signal_validation_persistent_history_flow import (
    _Host, _Window, _legacy_session_unavailable,
)
from tests.test_validation_period_short_history_cache_refresh import (
    _provider_result, _rows,
)


@pytest.mark.parametrize(
    "key,expect_latest",
    [
        ("D1", True), ("W1", True), ("MO1", True), ("Y1", True),
        ("Y1", False), ("M120", False),
    ],
)
def test_v4_short_broker_history_guard(key, expect_latest):
    """Only overlapping period rows can bypass nominal requested bar count."""
    _SHARED_SIGNAL_VALIDATION_HISTORICAL_POOLS.clear()
    stock = ValidationStockRef("005930", "Samsung")
    minute_value = 120 if key == "M120" else 5
    rules = {"bar": {"bar_minutes": minute_value}}
    if key != "M120":
        rules["validation_timeframe"] = {"key": key}
    settings = ValidationSettingsSnapshot(rules)
    request = IndicatorFollowSignalValidationRunRequest(settings, 10)
    old_rows = _rows(key, 41)
    next_rows = (
        _rows(key, 42)
        if expect_latest or key == "M120"
        else _rows(key, 42)[-1:]
    )
    calls = []

    class Broker:
        def __init__(self, session, requester):
            assert session.request.timeframe_key == key

        def request_latest(self, count, callback):
            calls.append(count)
            callback(_provider_result(stock, key, minute_value, next_rows))

    try:
        with tempfile.TemporaryDirectory() as tmp:
            cache = IndicatorFollowSignalValidationHistoricalCache(tmp)
            flow = IndicatorFollowSignalValidationV4Flow(
                object(), host=_Host(), historical_count=120,
                historical_provider_factory=Broker, historical_cache=cache,
                production_session_contract_reader=_legacy_session_unavailable,
            )
            flow._now_factory = lambda: datetime(
                2026, 10, 13, 9, 0, tzinfo=SEOUL_TIMEZONE
            )
            window = _Window(stock)
            wid = id(window)
            flow._open_windows[wid] = window
            flow._request_generation[wid] = 0
            count = 120 + required_validation_history_context_bars(
                settings.to_dict()
            )
            assert flow._persist_history(
                stock, minute_value, key, count, old_rows,
                market_data_identity=stock.code, market_source="KRX",
            )
            flow._run_validation(window, request)
            assert calls, "Expected a read-only broker refresh probe"
            readback = cache.load(stock.code, minute_value, count, key)
            assert readback is not None
            expected_rows = _rows(key, 42) if expect_latest else old_rows
            assert list(readback.candles) == expected_rows
            if expect_latest:
                app = QCoreApplication.instance() or QCoreApplication([])
                limit = time.monotonic() + 5
                while not window.pool_installs and not window.errors and time.monotonic() < limit:
                    app.processEvents()
                    time.sleep(0.005)
                assert window.pool_installs, window.errors
                assert not window.errors
    finally:
        _SHARED_SIGNAL_VALIDATION_HISTORICAL_POOLS.clear()
