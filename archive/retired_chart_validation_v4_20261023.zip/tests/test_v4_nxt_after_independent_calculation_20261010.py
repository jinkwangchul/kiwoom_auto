# -*- coding: utf-8 -*-
"""Independent M1/M3 verified NXT AFTER calculation; no fabricated source bars."""
from copy import deepcopy
from datetime import datetime

import pytest

from tests.test_indicator_follow_signal_validation_v4_normal_base import case, legacy
from tests.test_indicator_follow_signal_validation_v4_warmup_legend import flow_case
from gui_indicator_follow_signal_validation_v4_window import (
    _calculation_indexes_for_mixed_display,
    _build_validation_projection_data,
)


def bars(*stamps):
    return [
        dict(time=t, open=100., high=103., low=99.,
             close=101., volume=4.) for t in stamps
    ]


def fixture(case, minutes, regular_only=False):
    key = f"M{minutes}"
    raw = bars("20260922090000", "20260922153000",
               "20260922153300", "20260922160000")
    window, flow, _, _, rules, _ = flow_case(
        case, raw, count=4, regular=regular_only,
    )
    rules["bar"]["bar_minutes"] = minutes
    rules["validation_timeframe"] = {"key": key}
    rules["validation_market_scope"] = {"regular_market_only": regular_only}
    settings = legacy.ValidationSettingsSnapshot(rules)
    session = legacy.ValidationSession(
        legacy.ValidationRequest(case.stock, settings, minutes),
        operation_active_reader=lambda: False,
    )
    pool = flow._pool_from_candles(
        session, raw, requested_count=len(raw), request_id="DIRECT_KRX",
        market_data_identity=case.stock.code, market_source="KRX",
    )
    return window, flow, session, pool, rules


@pytest.mark.parametrize("minutes,first,second", (
    (1, "20260922154000", "20260922154100"),
    (3, "20260922153900", "20260922154200"),
))
@pytest.mark.parametrize("regular_only", (False, True))
def test_verified_after_calculates_same_timeframe_osc_and_keeps_raw_krx(
    case, minutes, first, second, regular_only,
):
    window, flow, session, pool, rules = fixture(case, minutes, regular_only)
    original = deepcopy(pool)
    nxt = bars(first, second)
    # The KRX overlapping 16:00 bar must keep the raw KRX OHLC.
    overlay = bars("20260922160000")
    overlay[0]["close"] = 888.
    overlay[0]["high"] = 900.
    sidecar = {
        "stock_code": case.stock.code, "timeframe_key": f"M{minutes}",
        "timeframe_minutes": minutes,
        "market_data_identity": f"{case.stock.code}_AL",
        "market_source": "INTEGRATED",
        "display_only": True, "verified_nxt_eligible": True,
        "request_as_of": "2026-09-22T16:20:00+09:00",
        "candles": sorted([
            *(row for row in pool["candles"]
              if row["time"] not in (
                  "20260922160000", "20260922153000", "20260922153300",
              )),
            *nxt, *overlay,
        ], key=lambda c: c["time"]),
    }
    flow._integrated_display_sidecars[
        flow._integrated_display_sidecar_key(session)
    ] = sidecar
    view = flow._validation_pool_for_session(session, pool, target_count=30)
    assert view["market_source"] == "VALIDATION_COMPOSITE"
    assert view["snapshot"].market_source == "VALIDATION_COMPOSITE"
    assert view["market_data_identity"] != case.stock.code
    calc = {bar["time"]: bar for bar in view["candles"]}
    assert all(stamp in calc for stamp in (first, second))
    assert calc["20260922160000"]["close"] == 101.
    if not regular_only:
        # The integrated TR can omit the auction rows, but the original KRX
        # closes must still be visible next to the new NXT AFTER bars.
        display_times = {row["time"] for row in view["display_candles"]}
        assert {"20260922153000", "20260922153300"} <= display_times
    assert pool["candles"] == original["candles"]
    assert pool["market_source"] == "KRX"
    assert pool["snapshot"].market_source == "KRX"

    # Regular-market-only is a display control; calculation is invariant.
    for stamp in (first, second):
        assert stamp in calc
    if not regular_only:
        display = view["display_candles"]
        lookup = _calculation_indexes_for_mixed_display(view["candles"], display)
        for stamp in (first, second):
            idx = next(i for i, row in enumerate(display)
                       if row["time"] == stamp)
            assert lookup[idx] is not None, f"OSC source missing for {stamp}"
        desc = tuple(d for d in window._filter_display_descriptors(rules)
                     if d.axis == "LOWER")
        projected, _ = _build_validation_projection_data(
            view["candles"], [], [], lookup, rules, desc,
        )
        assert any(
            channel == "OSC" and all(
                values[i] is not None
                for i, row in enumerate(display)
                if row["time"] in (first, second)
            )
            for identity, channel, values in projected.series
        )
    else:
        display_times = [row["time"] for row in view["display_candles"]]
        assert first not in display_times
        assert second not in display_times


@pytest.mark.parametrize("minutes,first,as_of", (
    (1, "20260922154000", "2026-09-22T15:40:30+09:00"),
    (3, "20260922153900", "2026-09-22T15:41:59+09:00"),
))
def test_open_after_target_stays_visible_but_not_in_calculation(
    case, minutes, first, as_of,
):
    window, flow, session, pool, rules = fixture(case, minutes)
    key = flow._integrated_display_sidecar_key(session)
    flow._integrated_display_sidecars[key] = {
        "stock_code": case.stock.code, "timeframe_key": f"M{minutes}",
        "timeframe_minutes": minutes,
        "market_data_identity": f"{case.stock.code}_AL",
        "market_source": "INTEGRATED",
        "display_only": True, "verified_nxt_eligible": True,
        "request_as_of": as_of,
        "candles": [*pool["candles"], *bars(first)],
    }
    view = flow._validation_pool_for_session(session, pool, target_count=30)
    assert first in [row["time"] for row in view["display_candles"]]
    assert first not in [row["time"] for row in view["candles"]]
    assert pool["market_source"] == "KRX"


@pytest.mark.parametrize("minutes,stamp", (
    (1, "20260922154000"), (3, "20260922153900"),
))
def test_unverified_after_never_enters_calculation(case, minutes, stamp):
    window, flow, session, pool, rules = fixture(case, minutes)
    key = flow._integrated_display_sidecar_key(session)
    flow._integrated_display_sidecars[key] = {
        "stock_code": case.stock.code, "timeframe_key": f"M{minutes}",
        "timeframe_minutes": minutes, "market_data_identity": "005930_AL",
        "market_source": "INTEGRATED", "display_only": True,
        "verified_nxt_eligible": False,
        "candles": [*pool["candles"], *bars(stamp)],
    }
    view = flow._validation_pool_for_session(session, pool, target_count=30)
    assert view["market_source"] == "KRX"
    assert stamp not in [row["time"] for row in view["candles"]]



@pytest.mark.parametrize("minutes", (1, 3))
def test_late_nxt_source_does_not_relabel_frozen_marking(case, minutes):
    from unittest.mock import patch

    window, flow, session, pool, _rules = fixture(case, minutes)
    flow._integrated_display_sidecars[
        flow._integrated_display_sidecar_key(session)
    ] = {
        "stock_code": case.stock.code, "timeframe_key": f"M{minutes}",
        "timeframe_minutes": minutes,
        "market_data_identity": f"{case.stock.code}_AL",
        "market_source": "INTEGRATED", "display_only": True,
        "verified_nxt_eligible": True,
        "request_as_of": "2026-09-22T16:20:00+09:00",
        "candles": bars("20260922154000" if minutes == 1
                        else "20260922153900"),
    }
    # A newer display without the corresponding finished independent
    # calculation would shift live marking/range evidence.
    with patch.object(window.marking_display_check, "isChecked", return_value=True), \
         patch.object(window, "set_display_only_integrated_candles") as install:
        flow._apply_integrated_display_sidecar(window, session)
    install.assert_not_called()
