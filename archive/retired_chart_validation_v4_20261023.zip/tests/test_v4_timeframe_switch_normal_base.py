# -*- coding: utf-8 -*-
"""Changing the selected V4 timeframe is chart preparation, not signal replay."""
from __future__ import annotations

from tests.test_indicator_follow_signal_validation_v4_normal_base import (
    case, window_for,
)


def test_all_thirteen_timeframe_selections_keep_signal_scan_unrequested(case):
    window = window_for(case)
    requests = []
    window.validation_run_requested.connect(
        lambda request: requests.append(
            (window.basic_signal_interval_combo.currentText(),
             window._normal_base_requested,
             request.force_historical_refresh)
        )
    )
    first = window.request_initial_validation()
    assert first is not None
    assert requests == [("5분", True, False)]
    combo = window.basic_signal_interval_combo
    assert combo.count() == 14  # 13 timeframes plus the visual separator.
    choices = ("1분", "3분", "5분", "10분", "15분",
               "30분", "60분", "120분", "240분",
               "일", "주", "월", "년")
    for selected in choices:
        for index in range(combo.count()):
            if combo.itemText(index) == selected:
                break
        else:
            raise AssertionError("missing selected timeframe: " + selected)
        if combo.currentIndex() == index:
            continue
        before = len(requests)
        combo.setCurrentIndex(index)
        case.app.processEvents()
        assert len(requests) == before + 1, selected
        assert requests[-1] == (selected, True, False)
        assert not window.marking_display_check.isChecked()
        assert window.replay_snapshot is None
        assert not window._calculation_signal_marker_entries
        assert not window._entries


def test_explicit_other_context_change_is_not_silently_rewritten(case):
    window = window_for(case)
    requests = []
    window.validation_run_requested.connect(
        lambda request: requests.append(
            (window._normal_base_requested, request.force_historical_refresh)
        )
    )
    window.request_initial_validation()
    assert requests[-1] == (True, False)
    window._on_validation_context_changed()
    assert requests[-1] == (False, False)



def test_switch_after_explicit_replay_restores_unmarked_normal_chart(case):
    from tests.test_indicator_follow_signal_validation_v4_normal_base import (
        range_signal_flow, marker_keys, candles,
    )

    window, flow = range_signal_flow(case)
    session = flow._validation_sessions[id(window)]
    pool = flow._historical_pools[id(window)]
    result = flow._prepare_replay_result_from_pool(
        session, pool, history_target=100, chart_range=(0, 20),
    )
    assert result.ok and result.snapshot is not None
    window.set_replay_snapshot(result.snapshot)
    assert marker_keys(window) == set()

    requests = []
    window.validation_run_requested.connect(
        lambda request: requests.append(
            (window._normal_base_requested, request.candle_count)
        )
    )
    window.basic_signal_interval_combo.setCurrentIndex(0)  # 1-minute
    assert requests and requests[-1][0] is True
    assert not window.marking_display_check.isChecked()

    new_candles = candles(100)
    window.set_historical_candle_pool(new_candles, chart_candle_count=100)
    assert window._pending_result_settings_snapshot is not None
    window.install_normal_base(
        window._pending_result_settings_snapshot, "M1"
    )
    assert marker_keys(window) == set()
    assert window._normal_base_ready
    assert window.replay_snapshot is None
    assert not window._entries
    assert not window._calculation_signal_marker_entries


def test_chart_bottom_navigation_scrollbar_keeps_geometry_when_pan_available(case):
    """Horizontal navigation must have one fixed slot even at the full-history span."""
    from tests.test_indicator_follow_signal_validation_v4_normal_base import (
        install, candles,
    )
    window = window_for(case)
    install(window, candles(100))
    window.resize(1180, 760)
    window.show()
    case.app.processEvents()
    scrollbar = window.time_navigation_scrollbar
    area = window.chart_scroll_area
    assert scrollbar.isVisible()
    assert not scrollbar.isEnabled()
    assert scrollbar.maximum() == 0
    fixed_geometry = (
        area.geometry().y(), area.geometry().height(),
        scrollbar.geometry().y(), scrollbar.height(),
    )
    assert scrollbar.height() > 0

    window._set_time_view(0, 50)
    case.app.processEvents()
    assert scrollbar.isVisible()
    assert scrollbar.isEnabled()
    assert scrollbar.maximum() > 0
    assert (
        area.geometry().y(), area.geometry().height(),
        scrollbar.geometry().y(), scrollbar.height(),
    ) == fixed_geometry

    scrollbar.setValue(scrollbar.maximum())
    case.app.processEvents()
    assert window.visible_start_index > 0
    window._set_time_view(0, 100)
    case.app.processEvents()
    assert scrollbar.isVisible()
    assert not scrollbar.isEnabled()
    assert scrollbar.maximum() == 0
    assert (
        area.geometry().y(), area.geometry().height(),
        scrollbar.geometry().y(), scrollbar.height(),
    ) == fixed_geometry
