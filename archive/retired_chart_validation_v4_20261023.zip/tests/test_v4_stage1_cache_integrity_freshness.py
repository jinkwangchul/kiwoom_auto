"""Stage 1 regressions for V4 signal-cache identity and bounded source reuse."""
from datetime import datetime, timedelta
from unittest.mock import patch

from candle_timeframe_aggregation import SEOUL_TIMEZONE
from tests.test_indicator_follow_signal_validation_v4_normal_base import case
from tests.test_indicator_follow_signal_validation_v4_warmup_legend import flow_case


ROWS = [
    dict(time="20261009090000", open=100., high=102., low=99., close=101., volume=25.),
    dict(time="20261009090300", open=101., high=103., low=100., close=102., volume=30.),
    dict(time="20261009090600", open=102., high=104., low=101., close=103., volume=35.),
]


class IntegratedBroker:
    def __init__(self):
        self.calls = []

    def request_minute_candles_display_only_integrated(self, code, name, **kwargs):
        self.calls.append((code, name, kwargs))
        return {"ok": True, "request_id": f"DISPLAY-{len(self.calls)}"}


def install_sidecar(flow, session, request_as_of, *, candles=ROWS, coverage=10_000):
    flow._integrated_display_sidecars[
        flow._integrated_display_sidecar_key(session)
    ] = {
        "stock_code": session.request.stock.code,
        "timeframe_key": session.request.timeframe_key,
        "timeframe_minutes": session.request.timeframe_minutes,
        "market_data_identity": f"{session.request.stock.code}_AL",
        "market_source": "INTEGRATED",
        "verified_nxt_eligible": True,
        "display_only": True,
        "coverage_count": coverage,
        "request_as_of": request_as_of.isoformat(),
        "candles": [dict(candle) for candle in candles],
    }


def test_signal_signature_invalidates_middle_close_and_volume(case):
    window, flow, session, pool, rules, replay = flow_case(case, ROWS, count=3)
    first = flow._signal_view_signature(pool)
    pool["candles"][1]["close"] += 7
    changed_close = flow._signal_view_signature(pool)
    pool["candles"][1]["volume"] += 11
    changed_volume = flow._signal_view_signature(pool)

    assert first != changed_close
    assert changed_close != changed_volume
    assert first[:4] == changed_volume[:4]


def test_signal_signature_reuses_precomputed_worker_source_identity(case):
    window, flow, session, pool, rules, replay = flow_case(case, ROWS, count=3)
    identity = flow._pool_computation_source_identity(pool)
    with patch.object(
        flow,
        "_pool_computation_source_identity",
        side_effect=AssertionError("worker digest must be reused"),
    ):
        signature = flow._signal_view_signature(pool, source_identity=identity)
    assert signature[-1][0] == identity[-1]


def test_in_process_pool_reuse_is_freshness_bounded(case):
    window, flow, session, old_pool, rules, replay = flow_case(case, ROWS, count=3)
    clock = [datetime(2026, 10, 9, 10, 0, tzinfo=SEOUL_TIMEZONE)]
    flow._now_factory = lambda: clock[0]
    pool = flow._pool_from_candles(
        session, [dict(row) for row in ROWS], requested_count=3,
        request_id="FRESH_KRX", market_data_identity=case.stock.code,
        market_source="KRX",
    )

    clock[0] += timedelta(seconds=59)
    assert flow._pool_matches(pool, case.stock, "M3", 3)
    clock[0] += timedelta(seconds=1)
    assert not flow._pool_matches(pool, case.stock, "M3", 3)
    assert flow._pool_match_failure_reason(pool, case.stock, "M3", 3) == "freshness"


def test_weekend_pool_reuse_does_not_probe_for_every_selection(case):
    window, flow, session, old_pool, rules, replay = flow_case(case, ROWS, count=3)
    clock = [datetime(2026, 10, 10, 9, 0, tzinfo=SEOUL_TIMEZONE)]  # Saturday
    flow._now_factory = lambda: clock[0]
    pool = flow._pool_from_candles(
        session, [dict(row) for row in ROWS], requested_count=3,
        request_id="WEEKEND_KRX", market_data_identity=case.stock.code,
        market_source="KRX",
    )

    clock[0] = datetime(2026, 10, 11, 18, 0, tzinfo=SEOUL_TIMEZONE)  # Sunday
    assert flow._pool_matches(pool, case.stock, "M3", 3)


def test_integrated_sidecar_reuses_fresh_request_but_refreshes_stale_time(case):
    window, flow, session, pool, rules, replay = flow_case(case, ROWS, count=3)
    broker = IntegratedBroker()
    flow._broker = broker
    clock = [datetime(2026, 10, 9, 10, 0, 30, tzinfo=SEOUL_TIMEZONE)]
    flow._now_factory = lambda: clock[0]
    install_sidecar(flow, session, clock[0] - timedelta(seconds=20))

    with patch.object(flow, "_verified_nxt_display_stock", return_value=True):
        flow._ensure_integrated_display_sidecar(window, session, 3)
        assert broker.calls == []
        clock[0] += timedelta(seconds=31)
        flow._ensure_integrated_display_sidecar(window, session, 3)
    assert len(broker.calls) == 1


def test_integrated_sidecar_from_prior_date_refreshes_and_newer_short_result_wins(case):
    window, flow, session, pool, rules, replay = flow_case(case, ROWS, count=3)
    broker = IntegratedBroker()
    flow._broker = broker
    current = datetime(2026, 10, 9, 10, 0, tzinfo=SEOUL_TIMEZONE)
    flow._now_factory = lambda: current
    install_sidecar(
        flow, session, current - timedelta(days=1), candles=ROWS, coverage=3,
    )

    with patch.object(flow, "_verified_nxt_display_stock", return_value=True):
        flow._ensure_integrated_display_sidecar(window, session, 3)
    callback = broker.calls[-1][2]["callback"]
    callback({
        "ok": True,
        "code": case.stock.code,
        "interval": 3,
        "rows": flow._historical_rows_from_candles(ROWS[-2:]),
        "request_id": "NEWER-SHORT",
        "market_data_identity": f"{case.stock.code}_AL",
        "market_source": "INTEGRATED",
        "display_only": True,
    })

    sidecar = flow._integrated_display_sidecars[
        flow._integrated_display_sidecar_key(session)
    ]
    assert sidecar["request_as_of"] == current.isoformat()
    assert sidecar["coverage_count"] == 2
    assert [row["time"] for row in sidecar["candles"]] == [
        row["time"] for row in ROWS[-2:]
    ]


def test_same_date_weekend_sidecar_does_not_refresh_without_new_session(case):
    window, flow, session, pool, rules, replay = flow_case(case, ROWS, count=3)
    broker = IntegratedBroker()
    flow._broker = broker
    current = datetime(2026, 10, 10, 18, 0, tzinfo=SEOUL_TIMEZONE)  # Saturday
    flow._now_factory = lambda: current
    install_sidecar(flow, session, current.replace(hour=9))

    with patch.object(flow, "_verified_nxt_display_stock", return_value=True):
        flow._ensure_integrated_display_sidecar(window, session, 3)
    assert broker.calls == []
