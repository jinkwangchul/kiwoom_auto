"""Short-history direct-timeframe normal-base readiness for real Samsung archives."""
import json
import time
from pathlib import Path
from unittest.mock import Mock

import pytest

from tests.test_indicator_follow_signal_validation_v4_normal_base import case, legacy
from tests.test_indicator_follow_signal_validation_v4_warmup_legend import flow_case
from indicator_follow_validation_timeframe import normalize_validation_timeframe
from indicator_follow_validation_history_contract import required_validation_history_context_bars

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / "runtime" / "signal_validation_v2_history_cache"


@pytest.mark.parametrize("timeframe,filename,expected_rows", [
    ("M120", "005930_120_5060.json", 1037),
    ("MO1", "005930_MO1_2120.json", 501),
    ("Y1", "005930_Y1_3620.json", 41),
])
def test_archived_underfill_has_direct_calc_and_no_redundant_history_fetch(
    case, timeframe, filename, expected_rows,
):
    data = json.loads((CACHE / filename).read_text(encoding="utf-8"))
    rows = data["candles"]
    assert len(rows) == expected_rows
    raw_request_count = int(data["requested_count"])
    minutes = 120 if timeframe == "M120" else 3
    window, flow, old_session, _, rules, replay = flow_case(
        case, rows, count=500, regular=False,
    )
    rules["bar"]["bar_minutes"] = minutes
    rules["validation_timeframe"] = normalize_validation_timeframe(timeframe)
    settings = legacy.ValidationSettingsSnapshot(rules)
    session = legacy.ValidationSession(
        legacy.ValidationRequest(case.stock, settings, minutes),
        operation_active_reader=lambda: False,
    )
    assert session.request.timeframe_key == timeframe
    pool = flow._pool_from_candles(
        session, rows, requested_count=raw_request_count,
        request_id="REAL_DIRECT_SOURCE", market_data_identity="005930",
        market_source="KRX",
    )
    warmup = required_validation_history_context_bars(rules)
    assert raw_request_count >= 500 + warmup
    assert expected_rows < raw_request_count
    assert pool["actual_candle_count"] == expected_rows
    assert pool["source_request_underfilled"] is True
    flow._history_targets[id(window)] = 500
    flow._historical_provider_factory = Mock(
        side_effect=AssertionError("redundant history fetch not authorized"),
    )
    flow._use_pool_for_window(window, session, pool, evaluation_count=100)
    deadline = time.monotonic() + 15
    while not window._normal_base_ready and time.monotonic() < deadline:
        case.app.processEvents()
        time.sleep(0.012)
    assert window._normal_base_ready
    flow._historical_provider_factory.assert_not_called()
    assert len(window._calculation_candles) == expected_rows
    assert window.visualization_cache is not None
    series = window.visualization_cache.series
    for channel in ("RSI", "MACD", "OSC"):
        assert any(
            item_channel == channel and any(value is not None for value in values)
            for _name, item_channel, values in series
        ), (timeframe, channel)
    assert pool["candles"] == rows
    assert all(candle["time"] in {row["time"] for row in rows}
               for candle in window._calculation_candles)



def test_old_m120_cache_is_not_treated_as_recent_broker_evidence(case):
    from datetime import datetime
    from candle_timeframe_aggregation import SEOUL_TIMEZONE
    from indicator_follow_signal_validation_historical_cache import (
        ValidationHistoricalCacheEntry,
    )

    data = json.loads((CACHE / "005930_120_5060.json").read_text(encoding="utf-8"))
    rows = data["candles"]
    assert rows[-1]["time"] == "20260918190000"
    window, flow, session, pool, rules, replay = flow_case(
        case, rows, count=500, regular=False,
    )
    flow._now_factory = lambda: datetime(
        2026, 10, 9, 20, 30, tzinfo=SEOUL_TIMEZONE,
    )
    entry = ValidationHistoricalCacheEntry(
        stock_code="005930",
        stock_name="Samsung",
        timeframe_minutes=120,
        timeframe_key="M120",
        requested_count=5060,
        candles=tuple(rows),
        updated_at=data["updated_at"],
        market_data_identity="005930",
        market_source="KRX",
    )
    assert flow._persistent_cache_requires_broker_probe(entry) is True
    # Probe eligibility is not evidence that the broker will return new bars.
    # A real 120-minute refresh is required before any freshness claim.

