import unittest
from unittest.mock import patch

from PyQt5.QtCore import Qt
from PyQt5.QtTest import QTest
from PyQt5.QtWidgets import QApplication

import gui_indicator_follow_signal_validation_window as window_module
import gui_indicator_follow_signal_validation_v4_window as v4_window_module
import tests.test_indicator_follow_signal_validation_v2 as v2
from indicator_follow_signal_validation_visualization import (
    FAMILY_BOLLINGER,
    FAMILY_MACD_SIGNAL,
    FAMILY_MOVING_AVERAGE,
    FAMILY_OCR_OSC,
    FAMILY_RSI,
    LOWER_AXIS,
    PRICE_AXIS,
    ValidationFilterDescriptor,
    ValidationIndicatorSeriesCache,
    ValidationLowerFilterPresentation,
    build_validation_filter_universe,
    build_validation_lower_filter_presentations,
)
from tests.test_indicator_follow_signal_validation_visualization import (
    _realistic_lower_presentation_rules,
)


def _candles():
    return [
        {"time": "20261001090000", "open": 100.0, "high": 101.0,
         "low": 99.0, "close": 100.0, "volume": 1000},
        {"time": "20261001090300", "open": 101.0, "high": 102.0,
         "low": 100.0, "close": 101.0, "volume": 1001},
        {"time": "20261002090000", "open": 102.0, "high": 103.0,
         "low": 101.0, "close": 102.0, "volume": 1002},
    ]


def _descriptor(identity, family, axis, series_keys, parameter_json, side):
    return ValidationFilterDescriptor(
        identity=identity,
        family=family,
        label=family,
        axis=axis,
        sides=(side,),
        series_keys=tuple(series_keys),
        parameter_json=parameter_json,
        evidence_keys=(identity + "-E",),
        supported_sides=(side,),
        unsupported_sides=(),
        supported=True,
        unavailable_reason="",
    )


class FilterSelectionPresentationTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        v2.IndicatorFollowSignalValidationV2Test.setUpClass()
        cls.app = QApplication.instance() or v2.IndicatorFollowSignalValidationV2Test.app

    def setUp(self):
        self.widgets = []

    def tearDown(self):
        for widget in self.widgets:
            try:
                widget.close()
                widget.deleteLater()
            except RuntimeError:
                pass
        self.app.processEvents()

    def test_price_legend_has_only_buy_and_sell_rows(self):
        buy = _descriptor(
            "BOLL", FAMILY_BOLLINGER, PRICE_AXIS,
            ("BOLLINGER_LOWER", "BOLLINGER_MIDDLE", "BOLLINGER_UPPER"),
            '{"condition":{"compare_target":"BOLLINGER_LOWER","operator":"<=","target":"CLOSE","threshold":0.0},"criterion_label":"볼린저 하단 이하","period":20,"std":2.0}',
            "BUY",
        )
        sell = _descriptor(
            "MA", FAMILY_MOVING_AVERAGE, PRICE_AXIS, ("MA60",),
            '{"condition":{"compare_target":"MA60","operator":"CROSS_DOWN","target":"CLOSE"},"criterion_label":"60이평 하향돌파","periods":[60]}',
            "SELL",
        )
        canvas = window_module.IndicatorFollowSignalValidationChartCanvas(
            _candles(), [], visualization_descriptors=(buy, sell), timeframe_key="M3"
        )
        self.widgets.append(canvas)

        self.assertFalse(hasattr(canvas, "set_filter_selection_families"))
        self.assertFalse(hasattr(canvas, "set_filter_selection_evidence_keys"))
        rows = canvas._price_legend_rows()
        self.assertEqual(["BUY", "SELL"], [row[0] for row in rows])
        self.assertEqual(["▪ 매수 :", "▪ 매도 :"], [row[1] for row in rows])

    def test_price_legend_rows_are_lifted_into_top_margin(self):
        buy = _descriptor(
            "BUY", FAMILY_BOLLINGER, PRICE_AXIS, ("BOLLINGER_LOWER",),
            '{"condition":{"operator":"<=","target":"CLOSE","compare_target":"BOLLINGER_LOWER"}}',
            "BUY",
        )
        sell = _descriptor(
            "SELL", FAMILY_MOVING_AVERAGE, PRICE_AXIS, ("MA60",),
            '{"condition":{"operator":"CROSS_DOWN","target":"CLOSE","compare_target":"MA60"}}',
            "SELL",
        )
        canvas = v4_window_module.IndicatorFollowSignalValidationChartCanvas(
            _candles(), [], visualization_descriptors=(buy, sell),
            timeframe_key="M3",
        )
        self.widgets.append(canvas)
        canvas.resize(1000, 500)
        canvas.set_time_view(0.0, 3.0)
        scale = canvas.price_scale()
        self.assertIsNotNone(scale)
        layout = canvas._price_legend_layout(scale, canvas.font())
        self.assertEqual(2, len(layout))
        self.assertAlmostEqual(
            float(canvas.fontMetrics().height()),
            layout[0]["prefix_rect"].top(),
            delta=1.0,
        )
        self.assertLessEqual(
            layout[-1]["prefix_rect"].bottom(),
            float(scale.plot_top),
        )

    def test_lower_filters_are_appended_as_numbered_text_blocks_per_side(self):
        buy_price = _descriptor(
            "BOLL", FAMILY_BOLLINGER, PRICE_AXIS,
            ("BOLLINGER_LOWER",),
            '{"condition":{"compare_target":"BOLLINGER_LOWER","operator":"<=","target":"CLOSE"}}',
            "BUY",
        )
        buy_lower_1 = _descriptor(
            "RSI-BUY", FAMILY_RSI, LOWER_AXIS, ("RSI", "CRITERION"),
            '{"condition":{"operator":"<=","target":"RSI","threshold":30.0},"criterion_label":"RSI 30 이하"}',
            "BUY",
        )
        buy_lower_2 = _descriptor(
            "OSC-BUY", FAMILY_OCR_OSC, LOWER_AXIS, ("OSC",),
            '{"condition":{"operator":"TURN_UP","target":"OSC"},"criterion_label":"OCR 상승전환"}',
            "BUY",
        )
        sell_lower = _descriptor(
            "OSC-SELL", FAMILY_OCR_OSC, LOWER_AXIS, ("OSC",),
            '{"condition":{"operator":"TURN_DOWN","target":"OSC"},"criterion_label":"OCR 하락전환"}',
            "SELL",
        )
        canvas = v4_window_module.IndicatorFollowSignalValidationChartCanvas(
            _candles(), [],
            visualization_descriptors=(
                buy_price, buy_lower_1, buy_lower_2, sell_lower,
            ),
            timeframe_key="M3",
        )
        self.widgets.append(canvas)

        rows = {side: blocks for side, _label, blocks in canvas._price_legend_rows()}
        buy_lower = [
            block for block in rows["BUY"]
            if block["legend_role"] == "LOWER_FILTER"
        ]
        sell_lower_blocks = [
            block for block in rows["SELL"]
            if block["legend_role"] == "LOWER_FILTER"
        ]
        self.assertEqual(
            ["하단1 RSI 30 이하", "하단2 OCR 상승전환"],
            [block["caption"] for block in buy_lower],
        )
        self.assertEqual(["RSI-BUY", "OSC-BUY"], [
            block["lower_descriptor_identity"] for block in buy_lower
        ])
        self.assertEqual(["하단2 OCR 하락전환"], [
            block["caption"] for block in sell_lower_blocks
        ])
        self.assertTrue(all(
            block["descriptor_identities"]
            == (block["lower_descriptor_identity"],)
            and block["pens"] == ()
            for block in (*buy_lower, *sell_lower_blocks)
        ))

    def test_lower_legend_click_highlights_required_elements_but_keeps_rsi_common(self):
        rsi = _descriptor(
            "RSI-BUY", FAMILY_RSI, LOWER_AXIS, ("RSI", "CRITERION"),
            '{"condition":{"operator":"<=","target":"RSI","threshold":30.0},"criterion_label":"RSI 30 이하"}',
            "BUY",
        )
        macd = _descriptor(
            "MACD-BUY", FAMILY_MACD_SIGNAL, LOWER_AXIS, ("MACD", "SIGNAL"),
            '{"condition":{"operator":"CROSS_UP","target":"MACD","compare_target":"SIGNAL"},"criterion_label":"MACD 상향돌파"}',
            "BUY",
        )
        candles = _candles()
        cache = ValidationIndicatorSeriesCache(
            len(candles),
            (
                ("RSI-BUY", "RSI", (40.0, 41.0, 42.0)),
                ("RSI-BUY", "CRITERION", (30.0, 30.0, 30.0)),
                ("MACD-BUY", "MACD", (-1.0, 0.0, 1.0)),
                ("MACD-BUY", "SIGNAL", (-0.5, 0.0, 0.5)),
            ),
        )
        canvas = v4_window_module.IndicatorFollowSignalValidationChartCanvas(
            candles, [],
            visualization_descriptors=(rsi, macd),
            visualization_cache=cache,
            timeframe_key="M3",
        )
        self.widgets.append(canvas)

        rsi_before = dict(canvas._descriptor_legend_line_pens(rsi, "BUY"))
        macd_before = dict(canvas._descriptor_legend_line_pens(macd, "BUY"))
        canvas._toggle_price_legend_identities("BUY", ("RSI-BUY",))
        self.assertEqual(
            (("BUY", "RSI-BUY"),),
            canvas.highlighted_lower_filter_identities,
        )
        self.assertFalse(canvas.highlighted_price_filter_identities)
        self.assertFalse(canvas.hide_unhighlighted_price_filters)
        rsi_after = dict(canvas._descriptor_legend_line_pens(rsi, "BUY"))
        self.assertEqual(rsi_before["RSI"].width(), rsi_after["RSI"].width())
        self.assertGreaterEqual(rsi_after["CRITERION"].width(), 2)

        canvas._toggle_price_legend_identities("BUY", ("MACD-BUY",))
        macd_after = dict(canvas._descriptor_legend_line_pens(macd, "BUY"))
        self.assertGreaterEqual(macd_after["MACD"].width(), 2)
        self.assertGreaterEqual(macd_after["SIGNAL"].width(), 2)
        self.assertEqual(macd_before["MACD"].style(), macd_after["MACD"].style())

        canvas._toggle_price_legend_identities("BUY", ("RSI-BUY",))
        self.assertNotIn(
            ("BUY", "RSI-BUY"),
            canvas.highlighted_lower_filter_identities,
        )

    def test_phase2_lower_pane_bundles_have_canonical_captions_order_and_identities(self):
        rules = _realistic_lower_presentation_rules()
        descriptors = build_validation_filter_universe(rules)
        presentations = build_validation_lower_filter_presentations(
            rules,
            descriptors,
        )
        cache = ValidationIndicatorSeriesCache(
            len(_candles()),
            tuple(
                (descriptor.identity, channel, (1.0, 2.0, 3.0))
                for descriptor in descriptors
                if descriptor.axis == LOWER_AXIS
                for channel in descriptor.series_keys
            ),
        )
        canvas = v4_window_module.IndicatorFollowSignalValidationChartCanvas(
            _candles(), [],
            visualization_descriptors=descriptors,
            visualization_cache=cache,
            lower_filter_presentations=presentations,
            timeframe_key="M3",
        )
        self.widgets.append(canvas)

        before_layout_state = (
            canvas._TOP,
            canvas._lower_families,
            dict(canvas._lower_pane_heights),
            tuple(canvas._lower_series_groups),
        )
        rows = {
            side: blocks
            for side, _label, blocks in canvas._price_legend_rows()
        }
        lower = {
            side: [
                block for block in blocks
                if block["legend_role"] == "LOWER_FILTER"
            ]
            for side, blocks in rows.items()
        }
        self.assertEqual(58, canvas._TOP)
        self.assertEqual(["BUY", "SELL"], list(rows))
        self.assertEqual([
            "[ RSI(14) : 45 이하 ]",
            "[ MACD(12,26,9) : OCR -91 이하 상승전환 ]",
        ], [block["caption"] for block in lower["BUY"]])
        self.assertEqual([
            "[ RSI(14) : 45 이하 ]",
            (
                "[ MACD(12,26,9) : OCR 73 이상 하락전환 | "
                "MACD선 -1 이하 ]"
            ),
        ], [block["caption"] for block in lower["SELL"]])
        self.assertNotIn("OCR 73 이상 |", lower["SELL"][1]["caption"])

        sell_pane_records = [
            record for record in presentations
            if record.side == "SELL"
            and record.pane_family in {FAMILY_OCR_OSC, FAMILY_MACD_SIGNAL}
        ]
        expected_union = []
        for record in sell_pane_records:
            for identity in record.descriptor_identities:
                if identity not in expected_union:
                    expected_union.append(identity)
        self.assertEqual(
            tuple(expected_union),
            lower["SELL"][1]["descriptor_identities"],
        )
        self.assertEqual(before_layout_state, (
            canvas._TOP,
            canvas._lower_families,
            dict(canvas._lower_pane_heights),
            tuple(canvas._lower_series_groups),
        ))
        self.assertFalse(hasattr(canvas, "selection_indicator_index"))

        reversed_descriptors = tuple(reversed(descriptors))
        reversed_presentations = build_validation_lower_filter_presentations(
            rules,
            reversed_descriptors,
        )
        reversed_canvas = (
            v4_window_module.IndicatorFollowSignalValidationChartCanvas(
                _candles(), [],
                visualization_descriptors=reversed_descriptors,
                lower_filter_presentations=reversed_presentations,
                timeframe_key="M3",
            )
        )
        self.widgets.append(reversed_canvas)
        reversed_rows = {
            side: [
                block["caption"] for block in blocks
                if block["legend_role"] == "LOWER_FILTER"
            ]
            for side, _label, blocks in reversed_canvas._price_legend_rows()
        }
        self.assertEqual(
            {
                side: [block["caption"] for block in blocks]
                for side, blocks in lower.items()
            },
            reversed_rows,
        )

    def test_phase2_legend_wraps_every_block_inside_800px_top_margin(self):
        rules = _realistic_lower_presentation_rules()
        descriptors = build_validation_filter_universe(rules)
        presentations = build_validation_lower_filter_presentations(
            rules,
            descriptors,
        )
        canvas = v4_window_module.IndicatorFollowSignalValidationChartCanvas(
            _candles(), [],
            visualization_descriptors=descriptors,
            lower_filter_presentations=presentations,
            timeframe_key="M3",
        )
        self.widgets.append(canvas)
        canvas.resize(800, 500)
        canvas.set_time_view(0.0, 3.0)
        scale = canvas.price_scale()
        self.assertIsNotNone(scale)

        rows = canvas._price_legend_rows()
        layout = canvas._price_legend_layout(scale, canvas.font())
        self.assertEqual(
            [len(blocks) for _side, _prefix, blocks in rows],
            [len(row["blocks"]) for row in layout],
        )
        self.assertGreater(
            len({item["rect"].top() for row in layout for item in row["blocks"]}),
            len(layout),
        )
        self.assertTrue(all(
            item["rect"].right() <= canvas.width() - canvas._RIGHT
            for row in layout
            for item in row["blocks"]
        ))
        self.assertLessEqual(
            max(
                [row["prefix_rect"].bottom() for row in layout]
                + [
                    item["rect"].bottom()
                    for row in layout
                    for item in row["blocks"]
                ]
            ),
            float(scale.plot_top),
        )

    def test_real_buy_and_sell_lower_legend_clicks_use_wrapped_hit_rectangles(self):
        rules = _realistic_lower_presentation_rules()
        descriptors = build_validation_filter_universe(rules)
        presentations = build_validation_lower_filter_presentations(
            rules,
            descriptors,
        )
        canvas = v4_window_module.IndicatorFollowSignalValidationChartCanvas(
            _candles(), [],
            visualization_descriptors=descriptors,
            lower_filter_presentations=presentations,
            timeframe_key="M3",
        )
        self.widgets.append(canvas)
        canvas.resize(800, 500)
        canvas.set_time_view(0.0, 3.0)
        canvas.show()
        self.app.processEvents()
        scale = canvas.price_scale()
        self.assertIsNotNone(scale)
        layout = canvas._price_legend_layout(scale, canvas.font())

        targets = {}
        for row in layout:
            lower_blocks = [
                item
                for item in row["blocks"]
                if item["block"]["legend_role"] == "LOWER_FILTER"
            ]
            targets[row["side"]] = lower_blocks[-1]
        self.assertEqual({"BUY", "SELL"}, set(targets))
        self.assertGreater(
            targets["SELL"]["rect"].top(),
            layout[-1]["prefix_rect"].top(),
        )

        expected = set()
        for side in ("BUY", "SELL"):
            target = targets[side]
            QTest.mouseClick(
                canvas,
                Qt.LeftButton,
                pos=target["rect"].center().toPoint(),
            )
            self.app.processEvents()
            expected.update(
                (side, identity)
                for identity in target["block"]["descriptor_identities"]
            )
            self.assertEqual(
                expected,
                set(canvas.highlighted_lower_filter_identities),
            )

    def test_phase2_bundle_click_and_projection_refresh_preserve_isolated_state(self):
        rules = _realistic_lower_presentation_rules()
        price = _descriptor(
            "PRICE-BUY", FAMILY_BOLLINGER, PRICE_AXIS,
            ("BOLLINGER_LOWER",),
            '{"criterion_label":"볼린저 하단 이상","period":20,"std":2.0}',
            "BUY",
        )
        descriptors = (
            price,
            *build_validation_filter_universe(rules),
        )
        presentations = build_validation_lower_filter_presentations(
            rules,
            descriptors,
        )
        cache = ValidationIndicatorSeriesCache(
            len(_candles()),
            tuple(
                (descriptor.identity, channel, (1.0, 2.0, 3.0))
                for descriptor in descriptors
                if descriptor.axis == LOWER_AXIS
                for channel in descriptor.series_keys
            ),
        )
        canvas = v4_window_module.IndicatorFollowSignalValidationChartCanvas(
            _candles(), [],
            visualization_descriptors=descriptors,
            visualization_cache=cache,
            lower_filter_presentations=presentations,
            timeframe_key="M3",
        )
        self.widgets.append(canvas)
        rows = {
            side: blocks
            for side, _label, blocks in canvas._price_legend_rows()
        }
        sell_bundle = next(
            block for block in rows["SELL"]
            if block["caption"].startswith("[ MACD(")
        )
        price_block = next(
            block for block in rows["BUY"]
            if block["legend_role"] == "PRICE_FILTER"
        )

        canvas._toggle_price_legend_identities(
            "SELL", sell_bundle["descriptor_identities"]
        )
        self.assertEqual(
            {
                ("SELL", identity)
                for identity in sell_bundle["descriptor_identities"]
            },
            set(canvas.highlighted_lower_filter_identities),
        )
        self.assertFalse(canvas.highlighted_price_filter_identities)
        self.assertFalse(canvas.hide_unhighlighted_price_filters)
        self.assertFalse(canvas.hidden_price_filter_identities)
        canvas._toggle_price_legend_identities(
            "SELL", sell_bundle["descriptor_identities"]
        )
        self.assertFalse(canvas.highlighted_lower_filter_identities)

        buy_rsi_bundle = next(
            block for block in rows["BUY"]
            if block["caption"].startswith("[ RSI(")
        )
        rsi_identity, = buy_rsi_bundle["descriptor_identities"]
        rsi_descriptor = next(
            descriptor for descriptor in descriptors
            if descriptor.identity == rsi_identity
        )
        before = dict(canvas._descriptor_legend_line_pens(
            rsi_descriptor, "BUY"
        ))
        canvas._toggle_price_legend_identities(
            "BUY", buy_rsi_bundle["descriptor_identities"]
        )
        after = dict(canvas._descriptor_legend_line_pens(
            rsi_descriptor, "BUY"
        ))
        self.assertEqual(before["RSI"].width(), after["RSI"].width())
        self.assertGreaterEqual(after["CRITERION"].width(), 2)

        canvas._toggle_price_legend_identities(
            "BUY", price_block["descriptor_identities"]
        )
        price_state = canvas.highlighted_price_filter_identities
        lower_state = canvas.highlighted_lower_filter_identities
        hidden_state = canvas.hidden_price_filter_identities
        hide_unhighlighted = canvas.hide_unhighlighted_price_filters
        reversed_descriptors = tuple(reversed(descriptors))
        refreshed_presentations = build_validation_lower_filter_presentations(
            rules,
            reversed_descriptors,
        )
        canvas.set_visualization_projection(
            reversed_descriptors,
            cache,
            {},
            [],
            refreshed_presentations,
        )
        self.assertEqual(price_state, canvas.highlighted_price_filter_identities)
        self.assertEqual(lower_state, canvas.highlighted_lower_filter_identities)
        self.assertEqual(hidden_state, canvas.hidden_price_filter_identities)
        self.assertEqual(
            hide_unhighlighted,
            canvas.hide_unhighlighted_price_filters,
        )

    def test_explicit_empty_phase2_presentations_hide_lower_bundle(self):
        lower = _descriptor(
            "RSI-BUY", FAMILY_RSI, LOWER_AXIS, ("RSI", "CRITERION"),
            '{"criterion_label":"RSI(14) 45 이하","period":14}',
            "BUY",
        )
        canvas = v4_window_module.IndicatorFollowSignalValidationChartCanvas(
            _candles(), [],
            visualization_descriptors=(lower,),
            lower_filter_presentations=(),
            timeframe_key="M3",
        )
        self.widgets.append(canvas)
        self.assertEqual([], canvas._price_legend_rows())

    def test_phase2_bundle_titles_expose_every_distinct_indicator_signature(self):
        rsi_14 = _descriptor(
            "RSI-14", FAMILY_RSI, LOWER_AXIS, ("RSI", "CRITERION"),
            '{"criterion_label":"RSI(14) 45 이하","period":14}',
            "BUY",
        )
        rsi_21 = _descriptor(
            "RSI-21", FAMILY_RSI, LOWER_AXIS, ("RSI", "CRITERION"),
            '{"criterion_label":"RSI(21) 50 이하","period":21}',
            "BUY",
        )
        ocr_12 = _descriptor(
            "OCR-12", FAMILY_OCR_OSC, LOWER_AXIS, ("OSC", "CRITERION"),
            '{"criterion_label":"OCR 73 이상","fast":12,"slow":26,"signal":9}',
            "BUY",
        )
        ocr_5 = _descriptor(
            "OCR-5", FAMILY_OCR_OSC, LOWER_AXIS, ("OSC", "CRITERION"),
            '{"criterion_label":"OCR -91 이하","fast":5,"slow":35,"signal":5}',
            "BUY",
        )
        presentations = tuple(
            ValidationLowerFilterPresentation(
                key=f"BUY:{descriptor.identity}",
                side="BUY",
                source_path=f"descriptor.{descriptor.identity}",
                filter_token=descriptor.family,
                pane_family=descriptor.family,
                display_order=(index,),
                descriptor_identities=(descriptor.identity,),
                component_descriptor_identities=(descriptor.identity,),
                component_labels=(descriptor.identity,),
            )
            for index, descriptor in enumerate((rsi_14, rsi_21, ocr_12, ocr_5))
        )
        canvas = v4_window_module.IndicatorFollowSignalValidationChartCanvas(
            _candles(), [],
            visualization_descriptors=(rsi_14, rsi_21, ocr_12, ocr_5),
            lower_filter_presentations=presentations,
            timeframe_key="M3",
        )
        self.widgets.append(canvas)
        blocks = canvas._price_legend_rows()[0][2]
        captions = [
            block["caption"] for block in blocks
            if block["legend_role"] == "LOWER_FILTER"
        ]
        self.assertEqual([
            "[ RSI(14/21) : 45 이하 | 50 이하 ]",
            "[ MACD(5,35,5/12,26,9) : OCR 73 이상 | OCR -91 이하 ]",
        ], captions)

    def test_lower_reference_labels_never_create_unselected_category(self):
        rsi = _descriptor(
            "RSI", FAMILY_RSI, LOWER_AXIS, ("RSI", "CRITERION"),
            '{"condition":{"operator":"<=","target":"RSI","threshold":30.0},"criterion_label":"RSI 30 이하","period":14}',
            "BUY",
        )
        ocr = _descriptor(
            "OCR", FAMILY_OCR_OSC, LOWER_AXIS, ("OSC", "CRITERION"),
            '{"condition":{"operator":">=","target":"OSC","threshold":0.0},"criterion_label":"OCR 0 이상","fast":12,"slow":26,"signal":9}',
            "SELL",
        )
        candles = _candles()
        cache = ValidationIndicatorSeriesCache(
            len(candles),
            (
                ("RSI", "RSI", (40.0, 41.0, 42.0)),
                ("RSI", "CRITERION", (30.0, 30.0, 30.0)),
                ("OCR", "OSC", (-1.0, 0.0, 1.0)),
                ("OCR", "CRITERION", (0.0, 0.0, 0.0)),
            ),
        )
        canvas = window_module.IndicatorFollowSignalValidationChartCanvas(
            candles, [], visualization_descriptors=(rsi, ocr),
            visualization_cache=cache, timeframe_key="M3"
        )
        self.widgets.append(canvas)
        canvas.resize(800, 500)
        canvas.set_time_view(0.0, 3.0)

        records = canvas.lower_reference_axis_records()
        self.assertTrue(records)
        self.assertTrue(all("미선택" not in str(record["text"]) for record in records))
        by_family = {}
        for record in records:
            by_family.setdefault(record["family"], []).append(record)
        self.assertTrue(any("매수" in record["text"] for record in by_family[FAMILY_RSI]))
        self.assertTrue(any("매도" in record["text"] for record in by_family[FAMILY_OCR_OSC]))

    def test_window_does_not_restore_selection_presentation_state(self):
        fixture = v2.IndicatorFollowSignalValidationV2Test("runTest")
        fixture.setUp()
        self.addCleanup(fixture.tearDown)
        with patch.object(v2.dialog_module.QTimer, "singleShot"):
            window = window_module.IndicatorFollowSignalValidationWindow(
                fixture.stock, fixture._seed()
            )
        fixture.widgets.append(window)

        self.assertFalse(hasattr(window, "_filter_selection_families_by_side"))
        self.assertFalse(hasattr(window, "_filter_selection_evidence_keys_by_side"))


if __name__ == "__main__":
    unittest.main()
