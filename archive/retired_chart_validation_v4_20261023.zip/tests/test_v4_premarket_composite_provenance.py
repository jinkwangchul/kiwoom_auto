# -*- coding: utf-8 -*-
"""V4 verified PRE calculation pool and nested replay snapshot source identity."""
from copy import deepcopy

import pytest

from routines.지표추종매매.routine_validation_contract import (
    ValidationRequest, ValidationSettingsSnapshot,
)
from routines.지표추종매매.routine_validation_session import ValidationSession
from tests.test_indicator_follow_signal_validation_v4_normal_base import case
from tests.test_indicator_follow_signal_validation_v4_warmup_legend import (
    flow_case,
)


def rows(*times):
    return [
        dict(time=stamp, open=100., high=102., low=99., close=101., volume=20.)
        for stamp in times
    ]


@pytest.mark.parametrize("minutes,key,pre_times", (
    (1, "M1", ("20261008080000", "20261008080100")),
    (3, "M3", ("20261008080000", "20261008080300")),
))
@pytest.mark.parametrize("regular_only", [False, True])
def test_verified_composite_pool_and_nested_snapshot_have_same_authority(
    case, minutes, key, pre_times, regular_only,
):
    base = rows("20261007090000", "20261008090000")
    window, flow, _session, _pool, rules, _ = flow_case(
        case, base, count=2, regular=regular_only,
    )
    rules["bar"]["bar_minutes"] = minutes
    rules["validation_timeframe"] = {"key": key}
    rules["validation_market_scope"] = {"regular_market_only": regular_only}
    settings = ValidationSettingsSnapshot(rules)
    session = ValidationSession(
        ValidationRequest(case.stock, settings, minutes),
        operation_active_reader=lambda: False,
    )
    pool = flow._pool_from_candles(
        session, base, requested_count=2, request_id="KRX_DIRECT_HISTORY",
        market_data_identity=case.stock.code, market_source="KRX",
    )
    before = deepcopy(pool)
    pre = rows(*pre_times)
    flow._integrated_display_sidecars[
        flow._integrated_display_sidecar_key(session)
    ] = {
        "stock_code": case.stock.code,
        "timeframe_key": key,
        "timeframe_minutes": minutes,
        "market_data_identity": case.stock.code + "_AL",
        "market_source": "INTEGRATED",
        "display_only": True,
        "verified_nxt_eligible": True,
        "request_as_of": "2026-10-08T08:50:00+09:00",
        "candles": [*pre, *base],
    }
    view = flow._validation_pool_for_session(session, pool, target_count=10)
    expected = case.stock.code + "_KRX_NXT_PRE_VALIDATION"
    assert view["validation_premarket_calculation"] is True
    assert view["market_source"] == "VALIDATION_COMPOSITE"
    assert view["market_data_identity"] == expected
    snapshot = view["snapshot"]
    assert snapshot.market_source == view["market_source"]
    assert snapshot.market_data_identity == view["market_data_identity"]
    assert snapshot.timeframe_key == key
    assert snapshot.timeframe_minutes == minutes
    assert snapshot.to_rows() == flow._historical_rows_from_candles(
        view["candles"]
    )
    for stamp in pre_times:
        assert stamp in [r["time"] for r in view["candles"]]
    # This path must NEVER modify the raw KRX broker pool/snapshot.
    assert pool["candles"] == before["candles"]
    assert pool["market_source"] == "KRX"
    assert pool["market_data_identity"] == case.stock.code
    assert pool["snapshot"].market_source == "KRX"
    assert pool["snapshot"].market_data_identity == case.stock.code

    # The actual manual replay view must retain composite authority.
    manual, _deficit = flow._normal_base_history_view(
        session, pool, history_target=10,
    )
    assert manual["snapshot"].market_source == "VALIDATION_COMPOSITE"
    assert manual["snapshot"].market_data_identity == expected


@pytest.mark.parametrize("minutes,key,pre_time", (
    (1, "M1", "20261008080000"),
    (3, "M3", "20261008080000"),
))
def test_unverified_pre_is_not_silently_promoted_to_krx(
    case, minutes, key, pre_time,
):
    base = rows("20261007090000", "20261008090000")
    window, flow, _session, _pool, rules, _ = flow_case(
        case, base, count=2, regular=False,
    )
    rules["bar"]["bar_minutes"] = minutes
    rules["validation_timeframe"] = {"key": key}
    settings = ValidationSettingsSnapshot(rules)
    session = ValidationSession(
        ValidationRequest(case.stock, settings, minutes),
        operation_active_reader=lambda: False,
    )
    pool = flow._pool_from_candles(
        session, base, requested_count=2, request_id="KRX_ONLY",
        market_data_identity=case.stock.code, market_source="KRX",
    )
    flow._integrated_display_sidecars[
        flow._integrated_display_sidecar_key(session)
    ] = {
        "stock_code": case.stock.code,
        "timeframe_key": key, "timeframe_minutes": minutes,
        "market_data_identity": case.stock.code + "_AL",
        "market_source": "INTEGRATED", "display_only": True,
        "verified_nxt_eligible": False,
        "candles": rows(pre_time),
    }
    view = flow._validation_pool_for_session(session, pool, target_count=10)
    assert view["market_source"] == "KRX"
    assert view["snapshot"].market_source == "KRX"
    assert all(row["time"] != pre_time for row in view["candles"])
