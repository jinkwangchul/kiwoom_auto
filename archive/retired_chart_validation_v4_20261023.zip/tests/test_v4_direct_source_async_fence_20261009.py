"""Contract fences for direct selected-timeframe sources and V4 async installation."""
from copy import deepcopy
from unittest.mock import patch

import pytest

from tests.test_indicator_follow_signal_validation_v4_normal_base import case
from tests.test_indicator_follow_signal_validation_v4_warmup_legend import flow_case


def candles():
    return [
        dict(time="20261007090000", open=100., high=101., low=99., close=100., volume=1.),
        dict(time="20261007090300", open=102., high=103., low=101., close=102., volume=1.),
        dict(time="20261007090600", open=103., high=104., low=102., close=103., volume=1.),
    ]


@pytest.mark.parametrize("wrong_key,wrong_minutes", (
    ("M1", 1), ("M5", 5), ("M3", 1), ("M1", 3),
))
def test_direct_calculation_rejects_pool_timeframe_mismatch(case, wrong_key, wrong_minutes):
    window, flow, session, pool, rules, replay = flow_case(
        case, candles(), count=3, regular=False,
    )
    pool["timeframe_key"] = wrong_key
    pool["timeframe_minutes"] = wrong_minutes
    before = deepcopy(pool)
    with pytest.raises(ValueError, match="TIMEFRAME"):
        flow._validation_pool_for_session(session, pool, target_count=3)
    assert pool == before


def test_normal_base_rejects_pool_timeframe_mismatch(case):
    window, flow, session, pool, rules, replay = flow_case(
        case, candles(), count=3, regular=False,
    )
    pool["timeframe_key"] = "M1"
    pool["timeframe_minutes"] = 1
    with pytest.raises(ValueError, match="TIMEFRAME"):
        flow._normal_base_history_view(session, pool, 3)


def test_same_selected_timeframe_stays_unchanged(case):
    window, flow, session, pool, rules, replay = flow_case(
        case, candles(), count=3, regular=False,
    )
    before = deepcopy(pool["candles"])
    view = flow._validation_pool_for_session(session, pool, target_count=3)
    assert view["candles"] == before
    assert pool["candles"] == before
    assert view["timeframe_key"] == "M3"
    assert view["timeframe_minutes"] == 3


def test_completed_normal_base_e1_then_e2_idle_is_not_dropped(case):
    window, flow, session, pool, rules, replay = flow_case(
        case, candles(), count=3, regular=False,
    )
    key = id(window)
    token = object()
    payload = {"prepare_token": token, "generation": 0, "normal_base": True}
    flow._prepare_active[key] = token
    flow._prepare_deferred[key] = (1, payload)
    with patch.object(window, "is_chart_view_update_busy", return_value=False), \
         patch.object(flow, "_on_signal_scan_completed") as completed:
        flow._on_chart_interaction_ended(window, 2, False)
    completed.assert_called_once_with(payload)
    assert key not in flow._prepare_deferred
    # The accepted prepare token still belongs to the normal completion callback.
    assert flow._prepare_active[key] is token
