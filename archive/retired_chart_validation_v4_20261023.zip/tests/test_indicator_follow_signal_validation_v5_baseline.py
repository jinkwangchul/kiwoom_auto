"""Focused V5 behavior baseline with all persistence dependencies isolated."""
from __future__ import annotations

from datetime import datetime, timedelta
import json
import os
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
from PyQt5.QtCore import QRectF, QSignalBlocker

import gui_indicator_follow_signal_validation_v4_flow as v4_flow_module
import gui_indicator_follow_signal_validation_v5_flow as flow_module
import gui_indicator_follow_signal_validation_v5_window as window_module
from tests import test_indicator_follow_signal_validation_v2 as legacy
from tests.qt_test_support import ensure_qapplication


@pytest.fixture
def case():
    cls = legacy.IndicatorFollowSignalValidationV2Test
    cls.setUpClass()
    instance = cls(methodName="runTest")
    instance.setUp()
    try:
        yield instance
    finally:
        instance.tearDown()


def window_for(case):
    with patch.object(legacy.dialog_module.QTimer, "singleShot"):
        window = window_module.IndicatorFollowSignalValidationV5Window(
            case.stock,
            case._seed(),
        )
    case.widgets.append(window)
    return window


def candles(count=600):
    rows = []
    stamp = datetime(2026, 10, 7, 15, 30)
    while len(rows) < count:
        value = 100_000.0 + len(rows)
        rows.append({
            "time": stamp.strftime("%Y%m%d%H%M%S"),
            "open": value,
            "high": value + 10.0,
            "low": value - 10.0,
            "close": value + 1.0,
            "volume": 100,
        })
        stamp -= timedelta(minutes=1)
        if stamp.hour < 9:
            stamp = (stamp - timedelta(days=1)).replace(hour=15, minute=30)
    return list(reversed(rows))


def install(window, rows=None):
    rows = candles() if rows is None else rows
    window.set_historical_candle_pool(rows, chart_candle_count=len(rows))
    window.install_normal_base(window._signal_validation_seed.settings_snapshot, "M1")


def descriptor(identity, family, label, axis, side, channel, parameters=None):
    return window_module.ValidationFilterDescriptor(
        identity,
        family,
        label,
        axis,
        (side,),
        (channel,),
        json.dumps(parameters or {}, sort_keys=True),
        (),
    )


def canvas_for(case, *, lower_presentation=False):
    rows = candles(8)
    price = descriptor(
        "price-ma5",
        window_module.FAMILY_MOVING_AVERAGE,
        "MA5",
        window_module.PRICE_AXIS,
        "BUY",
        "MA5",
    )
    lower = descriptor(
        "lower-rsi",
        window_module.FAMILY_RSI,
        "RSI",
        window_module.LOWER_AXIS,
        "BUY",
        "RSI",
        {
            "period": 14,
            "criterion_label": "RSI >= 50",
            "condition": {"operator": "GREATER_THAN_OR_EQUAL", "threshold": 50},
        },
    )
    presentations = ()
    if lower_presentation:
        presentations = (window_module.ValidationLowerFilterPresentation(
            key="BUY:rsi",
            side="BUY",
            source_path="buy.rsi",
            filter_token="RSI",
            pane_family=window_module.FAMILY_RSI,
            display_order=(0,),
            descriptor_identities=(lower.identity,),
            component_descriptor_identities=(lower.identity,),
            component_labels=("RSI",),
        ),)
    canvas = window_module.IndicatorFollowSignalValidationChartCanvas(
        rows,
        [],
        visualization_descriptors=(price, lower),
        visualization_cache=window_module.ValidationIndicatorSeriesCache(
            len(rows),
            (
                (price.identity, "MA5", tuple(row["close"] for row in rows)),
                (lower.identity, "RSI", tuple(45.0 + index for index in range(len(rows)))),
            ),
        ),
        lower_filter_presentations=presentations,
    )
    case.widgets.append(canvas)
    return canvas, price, lower


def test_v5_window_defaults_to_250_visible_candles_with_3500_cap(case):
    window = window_for(case)
    install(window)

    assert window.visible_candle_span == 250
    assert window.visible_start_index == len(window._candles) - 250
    assert window._MAX_VISIBLE_CANDLE_SPAN == 3500


def test_v5_negative_zero_is_display_only_and_preserves_underlying_value(case):
    threshold = -0.00001
    lower = descriptor(
        "ocr-negative-zero",
        window_module.FAMILY_OCR_OSC,
        "OCR",
        window_module.LOWER_AXIS,
        "BUY",
        "CRITERION",
        {"condition": {
            "operator": "LESS_THAN_OR_EQUAL",
            "target": "OSC",
            "threshold": threshold,
        }},
    )
    rows = candles(4)
    canvas = window_module.IndicatorFollowSignalValidationChartCanvas(
        rows,
        [],
        visualization_descriptors=(lower,),
        visualization_cache=window_module.ValidationIndicatorSeriesCache(
            len(rows),
            ((lower.identity, "CRITERION", (threshold,) * len(rows)),),
        ),
    )
    case.widgets.append(canvas)
    pane, = canvas.lower_pane_records()
    scale = canvas._lower_scale(
        window_module.FAMILY_OCR_OSC,
        int(pane["top"]),
        int(pane["bottom"]),
    )
    record, = canvas.lower_reference_line_records(
        window_module.FAMILY_OCR_OSC,
        scale,
    )

    assert canvas._crosshair_number_text(threshold) == "0"
    assert record["text"].endswith(" 0")
    assert record["value"] == threshold
    assert record["value"] < 0


def test_v5_unified_price_lower_multiselect_and_valid_zero_mode(case):
    canvas, price, lower = canvas_for(case)
    both = {("BUY", price.identity), ("BUY", lower.identity)}

    canvas._toggle_price_legend_identities(
        "BUY",
        (price.identity, lower.identity),
    )
    assert set(canvas.highlighted_price_filter_identities) == {("BUY", price.identity)}
    assert set(canvas.highlighted_lower_filter_identities) == {("BUY", lower.identity)}
    assert canvas.hide_unhighlighted_price_filters

    canvas.set_valid_filter_identities((), valid_mode_enabled=True)
    assert canvas.valid_filter_identities == ()
    assert canvas._price_visibility_filter_active()
    assert canvas._effective_price_filter_identities() == set()
    assert canvas._effective_lower_filter_identities() == set()
    assert set(canvas.hidden_price_filter_identities) == {price.identity}

    canvas.set_valid_filter_identities((), valid_mode_enabled=False)
    assert canvas._effective_price_filter_identities() | canvas._effective_lower_filter_identities() == both
    assert canvas.hidden_price_filter_identities == ()


def test_v5_not_styles_outer_red_inner_yellow_in_legend_only(case):
    canvas, price, lower = canvas_for(case, lower_presentation=True)
    series_before = (canvas._price_series_groups, canvas._lower_series_groups)
    line_legend_before = canvas.legend_records()
    canvas.set_not_filter_identities(
        {("BUY", price.identity), ("BUY", lower.identity)},
        {("BUY", lower.identity)},
    )

    blocks = next(blocks for side, _label, blocks in canvas._price_legend_rows()
                  if side == "BUY")
    price_block = next(block for block in blocks if price.identity in block["descriptor_identities"])
    lower_block = next(block for block in blocks if block["legend_role"] == "LOWER_FILTER")
    rect = QRectF(0.0, 0.0, 1000.0, 24.0)
    red_runs = canvas._layout_price_legend_blocks([price_block], rect, canvas.font())[0]["caption_runs"]
    yellow_runs = canvas._layout_price_legend_blocks([lower_block], rect, canvas.font())[0]["caption_runs"]

    assert {run["color"].getRgb() for run in red_runs} == {
        window_module._NOT_FILTER_TEXT.getRgb()
    }
    assert window_module._INNER_NOT_FILTER_TEXT.getRgb() in {
        run["color"].getRgb() for run in yellow_runs
    }
    assert window_module._NOT_FILTER_TEXT.getRgb() not in {
        run["color"].getRgb() for run in yellow_runs
    }
    assert (canvas._price_series_groups, canvas._lower_series_groups) == series_before
    assert canvas.legend_records() == line_legend_before


def test_v5_vertical_navigation_preserves_marking_horizontal_change_disables_it(case):
    window = window_for(case)
    install(window)
    with QSignalBlocker(window.marking_display_check):
        window.marking_display_check.setChecked(True)
    period = (window._candles[350]["time"], window._candles[599]["time"])
    frozen = object()
    window._marking_times = period
    window._marking_snapshot = frozen
    generation = window._marking_generation

    window._pan_chart_view(0.0, 20.0)
    assert window.marking_display_check.isChecked()
    assert window._marking_times == period
    assert window._marking_snapshot is frozen
    assert window._marking_generation == generation

    with patch.object(window_module, "signal_validation_trace_enabled", return_value=False):
        window._set_time_view(
            window.visible_start_index - 10,
            window.visible_candle_span,
            user_horizontal_navigation=True,
        )
    assert not window.marking_display_check.isChecked()
    assert window._marking_times is None
    assert window._marking_snapshot is None
    assert window._marking_generation == generation + 1


def test_v5_flow_owns_injected_stores_and_purges_startup_evictions(case):
    class RecentStore:
        recent_stocks = (case.stock,)

        @staticmethod
        def take_startup_evicted_codes():
            return ("000660",)

    class HistoricalCache:
        def __init__(self):
            self.deleted = []

        def delete_stock(self, code):
            self.deleted.append(code)
            return {"ok": True}

    recent = RecentStore()
    preferences = object()
    history = HistoricalCache()
    flow = flow_module.IndicatorFollowSignalValidationV5Flow(
        object(),
        host=legacy._FakeHost(case.stock),
        recent_stock_store=recent,
        preference_store=preferences,
        historical_cache=history,
    )

    assert flow._recent_stock_store is recent
    assert flow._preference_store is preferences
    assert flow._historical_cache is history
    assert flow.recent_stocks == (case.stock,)
    assert history.deleted == ["000660"]
    assert (
        flow_module._SHARED_SIGNAL_VALIDATION_HISTORICAL_POOLS
        is not v4_flow_module._SHARED_SIGNAL_VALIDATION_HISTORICAL_POOLS
    )
