# -*- coding: utf-8 -*-
"""Selected range timestamps must map before a new display is observable."""
from datetime import datetime, timedelta

import pytest
from PyQt5.QtCore import QSignalBlocker

from tests.test_indicator_follow_signal_validation_v4_marking import (
    connected, position_evaluator, turn_on,
)
from tests.test_indicator_follow_signal_validation_v4_normal_base import (
    case, legacy, wait_for,
)

MINUTES = (5, 10, 15, 30, 60, 120, 240)


@pytest.mark.parametrize("minutes", MINUTES)
def test_period_anchor_remapped_in_same_display_update(case, minutes):
    window, flow = connected(case, evaluator=position_evaluator)
    with QSignalBlocker(window.basic_signal_interval_combo):
        window.basic_signal_interval_combo.setCurrentText(f"{minutes}분")
    start = datetime(2026, 9, 1, 9, 0)
    candles = []
    for idx in range(100):
        price = 100_000. + (idx % 9) * 100.
        candles.append(dict(
            time=(start + timedelta(minutes=idx * minutes)).strftime(
                "%Y%m%d%H%M%S"
            ),
            open=price, high=price + 300., low=price - 200.,
            close=price + 100., volume=1.,
        ))
    settings = window._marking_current_settings()
    session = legacy.ValidationSession(
        legacy.ValidationRequest(case.stock, settings, minutes),
        operation_active_reader=lambda: False,
    )
    flow._validation_sessions[id(window)] = session
    flow._historical_pools[id(window)] = flow._pool_from_candles(
        session, candles, requested_count=100, request_id="KRX_RANGE_TEST",
        market_data_identity=case.stock.code, market_source="KRX",
    )
    window.set_historical_candle_pool(candles, chart_candle_count=100)
    window.install_normal_base(settings, f"M{minutes}")
    window._set_time_view(40, 30)
    turn_on(case, window)
    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    original_times = window._validation_range_times
    assert window.validation_range == (44, 56)

    window.set_historical_display_candles(
        candles[10:], preserve_completed_cycles=True,
    )
    assert window._validation_range_times == original_times
    assert window.validation_range == (34, 46)
    assert window._validation_range_anchor_index == 34
    assert (
        window._candles[window.validation_range[0]]["time"],
        window._candles[window.validation_range[1]]["time"],
    ) == original_times
    assert {
        (x.evaluation_index, x.signal)
        for x in window._range_replay_entries
        if x.signal == x.evaluation_side
    } == {(35, "BUY"), (45, "SELL")}

    window.set_replay_snapshot(window.replay_snapshot, presentation_only=True)
    assert window.validation_range == (34, 46)
    assert window._validation_range_times == original_times
    assert len(window.completed_cycles) == 1
