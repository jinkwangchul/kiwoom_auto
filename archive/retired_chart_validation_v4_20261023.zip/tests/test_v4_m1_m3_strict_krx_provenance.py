# -*- coding: utf-8 -*-
"""Selected minute KRX sources need explicit evidence at every boundary."""
import json
import tempfile

import pytest

import gui_indicator_follow_signal_validation_v4_flow as fm
from indicator_follow_signal_validation_historical_cache import (
    IndicatorFollowSignalValidationHistoricalCache,
)
from tests.test_indicator_follow_signal_validation_v4_normal_base import case, legacy
from tests.test_indicator_follow_signal_validation_v4_warmup_legend import flow_case


ROWS = [
    dict(time="20261007090000", open=100., high=102., low=99., close=101., volume=25.),
    dict(time="20261007090300", open=101., high=103., low=100., close=102., volume=30.),
]
MINUTE_TIMEFRAMES = (
    ("M1", 1), ("M3", 3), ("M5", 5), ("M10", 10), ("M15", 15),
    ("M30", 30), ("M60", 60), ("M120", 120), ("M240", 240),
)


@pytest.mark.parametrize("key,minutes", MINUTE_TIMEFRAMES)
@pytest.mark.parametrize("identity,source,accepted", (
    ("", "", False), ("005930", "", False), ("", "KRX", False),
    ("005930", "INTEGRATED", False), ("005930_AL", "KRX", False),
    ("005930", "KRX", True),
))
def test_broker_result_requires_explicit_krx_evidence(
    case, key, minutes, identity, source, accepted,
):
    window, flow, session, pool, rules, replay = flow_case(case, ROWS, count=2)
    snap = fm.ValidationHistoricalSnapshot(
        stock=case.stock, timeframe_minutes=minutes, timeframe_key=key,
        requested_count=2, request_id="READ_ONLY_TEST",
        rows=[{"time": row["time"]} for row in ROWS],
        market_data_identity=identity, market_source=source,
    )
    result = fm.ValidationHistoricalResult(True, snapshot=snap)
    assert flow._historical_result_matches_validation_source(result, case.stock) is accepted


@pytest.mark.parametrize("key,minutes", MINUTE_TIMEFRAMES)
def test_cache_needs_payload_and_sidecar_both_verified(case, key, minutes):
    window, flow, session, pool, rules, replay = flow_case(case, ROWS, count=2)
    with tempfile.TemporaryDirectory() as root:
        cache = IndicatorFollowSignalValidationHistoricalCache(root)
        flow._historical_cache = cache
        assert cache.store(
            stock_code=case.stock.code, stock_name=case.stock.name,
            timeframe_minutes=minutes, timeframe_key=key,
            requested_count=2, candles=ROWS,
            market_data_identity=case.stock.code, market_source="KRX",
        )
        path = cache.path_for(case.stock.code, minutes, 2, key)
        marker = path.with_name(path.name + ".market-source.json")
        assert flow._cached_history(case.stock, minutes, key, 2) is None

        marker.write_text(json.dumps({
            "canonical_stock_code": case.stock.code,
            "market_data_identity": case.stock.code,
            "market_source": "KRX",
        }), encoding="utf-8")
        assert flow._cached_history(case.stock, minutes, key, 2) is not None

        marker.write_text(json.dumps({
            "canonical_stock_code": case.stock.code,
            "market_data_identity": case.stock.code,
            "market_source": "INTEGRATED",
        }), encoding="utf-8")
        assert flow._cached_history(case.stock, minutes, key, 2) is None

        marker.write_text(json.dumps({
            "canonical_stock_code": case.stock.code,
            "market_data_identity": case.stock.code,
            "market_source": "KRX",
        }), encoding="utf-8")
        raw = json.loads(path.read_text(encoding="utf-8"))
        raw["market_source"] = "INTEGRATED"
        path.write_text(json.dumps(raw, ensure_ascii=False), encoding="utf-8")
        assert flow._cached_history(case.stock, minutes, key, 2) is None


@pytest.mark.parametrize("key,minutes", MINUTE_TIMEFRAMES)
def test_persistence_never_infers_missing_krx_provenance(case, key, minutes):
    window, flow, session, pool, rules, replay = flow_case(case, ROWS, count=2)
    with tempfile.TemporaryDirectory() as root:
        cache = IndicatorFollowSignalValidationHistoricalCache(root)
        flow._historical_cache = cache
        assert not flow._persist_history(
            case.stock, minutes, key, 2, ROWS,
            market_data_identity="", market_source="",
        )
        assert not flow._persist_history(
            case.stock, minutes, key, 2, ROWS,
            market_data_identity="005930", market_source="INTEGRATED",
        )
        assert not cache.path_for(case.stock.code, minutes, 2, key).exists()
        assert flow._persist_history(
            case.stock, minutes, key, 2, ROWS,
            market_data_identity=case.stock.code, market_source="KRX",
        )
        assert flow._cached_history(case.stock, minutes, key, 2) is not None


@pytest.mark.parametrize("key,minutes", MINUTE_TIMEFRAMES)
def test_internal_raw_pool_cannot_infer_krx_authority(case, key, minutes):
    window, flow, _session, pool, rules, replay = flow_case(case, ROWS, count=2)
    settings = legacy.ValidationSettingsSnapshot({
        "bar": {"bar_minutes": minutes},
        "validation_timeframe": {"key": key},
    })
    session = legacy.ValidationSession(
        legacy.ValidationRequest(case.stock, settings, minutes),
        operation_active_reader=lambda: False,
    )
    for identity, source in (
        ("", ""), (case.stock.code, ""), ("", "KRX"),
        (case.stock.code, "INTEGRATED"),
    ):
        with pytest.raises(ValueError, match="MARKET_SOURCE"):
            flow._pool_from_candles(
                session, ROWS, requested_count=2, request_id="UNTRUSTED",
                market_data_identity=identity, market_source=source,
            )
    verified = flow._pool_from_candles(
        session, ROWS, requested_count=2, request_id="VERIFIED",
        market_data_identity=case.stock.code, market_source="KRX",
    )
    assert verified["market_source"] == "KRX"
    assert verified["snapshot"].market_source == "KRX"


def test_period_source_inference_semantics_remain_unchanged(case):
    window, flow, _session, pool, rules, replay = flow_case(case, ROWS, count=2)
    settings = legacy.ValidationSettingsSnapshot({
        "bar": {"bar_minutes": 1},
        "validation_timeframe": {"key": "D1"},
    })
    session = legacy.ValidationSession(
        legacy.ValidationRequest(case.stock, settings, 1),
        operation_active_reader=lambda: False,
    )
    inferred = flow._pool_from_candles(
        session, ROWS, requested_count=2, request_id="PERIOD_LEGACY",
    )
    assert inferred["market_data_identity"] == case.stock.code
    assert inferred["market_source"] == "KRX"

    snap = fm.ValidationHistoricalSnapshot(
        stock=case.stock, timeframe_minutes=1, timeframe_key="D1",
        requested_count=2, request_id="PERIOD_LEGACY",
        rows=[{"time": row["time"]} for row in ROWS],
        market_data_identity="", market_source="",
    )
    assert flow._historical_result_matches_validation_source(
        fm.ValidationHistoricalResult(True, snapshot=snap), case.stock,
    )
