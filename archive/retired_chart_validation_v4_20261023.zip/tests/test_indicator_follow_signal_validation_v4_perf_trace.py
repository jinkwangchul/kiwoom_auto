"""Temporary V4 diagnostics: isolation, bounded delivery and visual parity."""
import importlib.util
from dataclasses import asdict
import os
from pathlib import Path
import tempfile
import threading
import sys
from unittest.mock import patch

import pytest
from tests.test_indicator_follow_signal_validation_v4_normal_base import case


def load(monkeypatch, enabled=False):
    monkeypatch.setenv('KIWOOM_SIGNAL_VALIDATION_V4_PERF', '1' if enabled else '0')
    path = Path(__file__).resolve().parents[1] / 'indicator_follow_signal_validation_perf_trace.py'
    assert path.exists(), 'dedicated default-off collector is missing'
    spec = importlib.util.spec_from_file_location('isolated_perf', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_off_has_no_collector_or_call_overhead(monkeypatch):
    before = set(threading.enumerate())
    with patch('threading.Thread.start', side_effect=AssertionError('worker while OFF')), \
         patch('time.perf_counter', side_effect=AssertionError('clock while OFF')), \
         patch('time.thread_time', side_effect=AssertionError('thread clock while OFF')), \
         patch.object(Path, 'open', side_effect=AssertionError('file while OFF')), \
         patch.object(Path, 'mkdir', side_effect=AssertionError('mkdir while OFF')):
        mod = load(monkeypatch)
    def original():
        return 42
    assert mod.stage('test')(original) is original
    assert mod.phase(object(), visible_bars=1) is None
    assert mod._collector is None
    assert set(threading.enumerate()) == before


def test_bounded_nonblocking_and_failure(monkeypatch):
    mod = load(monkeypatch)
    c = mod.Collector(capacity=2)
    for i in range(20):
        c.offer({'event': 'test', 'elapsed_ms': i})
    assert c.queue.qsize() == 2
    assert c.dropped == 18
    with tempfile.TemporaryDirectory() as directory:
        c.path = Path(directory)  # opening a directory must fail harmlessly
        c.write_batch([{'event': 'test'}])
        assert c.failed


def test_enabled_stage_worker_and_metadata(monkeypatch):
    mod = load(monkeypatch)
    mod.ENABLED = True
    mod._collector = mod.Collector()
    @mod.stage('worker.prepare')
    def work(owner):
        return 17
    thread = threading.Thread(target=lambda: work(object()), name='test-prepare')
    thread.start()
    thread.join()
    record = mod._collector.queue.get_nowait()
    assert record['event'] == 'worker.prepare'
    assert record['thread'] == 'test-prepare'
    assert record['elapsed_ms'] >= 0
    assert record['pid'] == os.getpid()
    assert record['monotonic'] > 0


def test_enabled_phase_records_wall_and_thread_cpu_deltas(monkeypatch):
    mod = load(monkeypatch)
    mod.ENABLED = True
    mod._collector = mod.Collector()
    wall = iter((10.0, 10.25, 10.25))
    cpu = iter((4.0, 4.125))
    monkeypatch.setattr(mod, 'perf_counter', lambda: next(wall))
    monkeypatch.setattr(mod, 'thread_time', lambda: next(cpu))
    probe = mod.phase(object(), visible_bars=7, markers=3, cycles=1)
    probe.checkpoint('labels.phase.example', candidate_count=11, blocker_count=5)
    record = mod._collector.queue.get_nowait()
    assert record['event'] == 'labels.phase.example'
    assert record['elapsed_ms'] == 250.0
    assert record['thread_cpu_ms'] == 125.0
    assert {key: record[key] for key in (
        'visible_bars', 'markers', 'cycles', 'candidate_count', 'blocker_count'
    )} == {
        'visible_bars': 7, 'markers': 3, 'cycles': 1,
        'candidate_count': 11, 'blocker_count': 5,
    }


def test_real_canvas_on_off_parity_and_events(monkeypatch):
    from tests import test_indicator_follow_signal_validation_cycle_label_performance as fixtures
    from PyQt5.QtGui import QImage
    from PyQt5.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    mod = load(monkeypatch)
    mod._collector = mod.Collector()
    monkeypatch.setitem(sys.modules, 'indicator_follow_signal_validation_perf_trace', mod)
    results = []
    for enabled in (False, True):
        mod.ENABLED = enabled
        name = 'perf_window_' + str(enabled)
        path = Path(__file__).resolve().parents[1] / 'gui_indicator_follow_signal_validation_v4_window.py'
        spec = importlib.util.spec_from_file_location(name, path)
        wm = importlib.util.module_from_spec(spec)
        monkeypatch.setitem(sys.modules, name, wm)
        spec.loader.exec_module(wm)
        c = wm.IndicatorFollowSignalValidationChartCanvas(fixtures._candles(28),
            [{'evaluation_index': 9, 'side': 'BUY'}])
        c.resize(741, 463)
        c.set_validation_range(0, 27)
        cycle = wm.IndicatorFollowValidationCompletedCycle(**asdict(fixtures._cycle(1, 2, 9, 100.125)))
        c.set_completed_cycle_average_lines((cycle,))
        c.render(QImage(c.size(), QImage.Format_ARGB32))
        c.render(QImage(c.size(), QImage.Format_ARGB32))
        from tests.test_indicator_follow_cycle_label_deferred import Owner
        c._input_frame_owner = Owner(c)
        c._maybe_begin_cycle_label_preview()
        preview = c._cycle_label_records_for_paint(c.price_scale())
        c._input_frame_owner.busy = False
        c._settle_cycle_label_preview()
        results.append((c.completed_cycle_average_label_records(), c._markers,
                        c._validation_range, asdict(cycle), preview))
        c.close()
    assert results[0] == results[1]
    records = list(mod._collector.queue.queue)
    events = {r['event'] for r in records}
    assert {'canvas.paint', 'canvas.static', 'labels.layout', 'labels.signature',
            'labels.blockers', 'labels.records'} <= events
    phase_events = {r['event'] for r in records if r['event'].startswith('labels.phase.')}
    assert {
        'labels.phase.cache_key', 'labels.phase.cache_hit',
        'labels.phase.numpy_import', 'labels.phase.blockers',
        'labels.phase.geometry', 'labels.phase.scoring',
        'labels.phase.final_cache',
    } <= phase_events
    for record in (r for r in records if r['event'].startswith('labels.phase.')):
        assert record['elapsed_ms'] >= 0
        assert record['thread_cpu_ms'] >= 0
        assert all(isinstance(record[key], int) for key in (
            'visible_bars', 'markers', 'cycles', 'candidate_count', 'blocker_count'
        ))
    assert {r['cache_hit'] for r in records if r['event'] == 'canvas.paint'} == {False, True}
    assert {r['preview'] for r in records if r['event'] == 'labels.records'} == {False, True}
    assert 'labels.settle' in events


def test_opt_in_initializes_one_daemon_without_opening_file(monkeypatch):
    with patch('threading.Thread.start') as start, \
         patch.object(Path, 'open', side_effect=AssertionError('eager file IO')):
        mod = load(monkeypatch, enabled=True)
    assert mod.ENABLED and mod._collector is not None
    start.assert_called_once()


def test_real_daemon_delivery_and_cap(monkeypatch):
    import json
    import time
    mod = load(monkeypatch)
    with tempfile.TemporaryDirectory() as directory:
        c = mod.Collector()
        c.path = Path(directory) / 'perf.jsonl'
        worker = threading.Thread(target=c.run, daemon=True)
        worker.start()
        c.offer({'event': 'test', 'elapsed_ms': 1})
        deadline = time.monotonic() + 3
        while (not c.path.exists() or not c.path.stat().st_size) and time.monotonic() < deadline:
            time.sleep(.01)
        assert json.loads(c.path.read_text())['event'] == 'test'
        original = c.path.read_bytes()
        monkeypatch.setattr(mod, 'MAX_BYTES', len(original))
        c.offer({'event': 'stop-at-cap'})
        worker.join(3)
        assert not worker.is_alive()
        assert c.failed and c.path.read_bytes() == original


def test_rate_limit_and_trace_failure_cannot_change_return(monkeypatch):
    mod = load(monkeypatch)
    mod.ENABLED = True
    mod._collector = mod.Collector()
    monkeypatch.setattr(mod, 'perf_counter', lambda: 10.)
    for _ in range(100):
        mod.emit('burst', 9., None)
    assert mod._collector.queue.qsize() == 1
    monkeypatch.setattr(mod, 'perf_counter', lambda: 10.1)
    mod.emit('burst', 10., None)
    records = list(mod._collector.queue.queue)
    assert records[-1]['suppressed'] == 99
    def broken():
        raise OSError('clock failure')
    monkeypatch.setattr(mod, 'perf_counter', broken)
    assert mod.stage('failure')(lambda: 42)() == 42


def test_real_async_marking_worker_preserves_semantics(monkeypatch, case):
    from tests.test_indicator_follow_signal_validation_v4_marking import connected, turn_on, fm
    mod = load(monkeypatch)
    mod.ENABLED = True
    mod._collector = mod.Collector()
    window, flow = connected(case)
    before = turn_on(case, window)
    before_markers = window.canvas.marker_records()
    before_period = window._marking_times
    window.marking_display_check.setChecked(False)
    window._marking_cache = None
    monkeypatch.setattr(fm, '_perf_stage', mod.stage)
    after = turn_on(case, window)
    assert before == after
    assert window.canvas.marker_records() == before_markers
    assert window._marking_times == before_period
    records = list(mod._collector.queue.queue)
    worker = [r for r in records if r['event'] == 'worker.marking']
    assert worker and worker[0]['thread'] != threading.current_thread().name
    assert worker[0]['instance_id'] == id(window)


def test_first_numpy_load_does_not_block_label_paint(monkeypatch):
    import builtins
    import time
    import gui_indicator_follow_signal_validation_v4_window as wm
    from tests import test_indicator_follow_signal_validation_cycle_label_performance as fixtures
    from PyQt5.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    monkeypatch.setattr(wm, '_cycle_label_numpy_module', None, raising=False)
    monkeypatch.setattr(wm, '_cycle_label_numpy_started', False, raising=False)
    entered = threading.Event()
    release = threading.Event()
    calls = []
    original_import = builtins.__import__

    def observed_import(name, *args, **kwargs):
        if name == 'numpy':
            calls.append(threading.current_thread().name)
            if threading.current_thread() is threading.main_thread():
                raise AssertionError('NumPy import ran on the GUI/main thread')
            entered.set()
            if not release.wait(5):
                raise TimeoutError('test preload release not received')
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, '__import__', observed_import)
    canvas = wm.IndicatorFollowSignalValidationChartCanvas(
        fixtures._candles(28), [{'evaluation_index': 9, 'side': 'BUY'}])
    try:
        canvas.resize(741, 463)
        canvas.set_validation_range(0, 27)
        cycle = wm.IndicatorFollowValidationCompletedCycle(
            **asdict(fixtures._cycle(1, 2, 9, 100.125)))
        canvas.set_completed_cycle_average_lines((cycle,))
        assert entered.wait(3), 'prepare step did not start NumPy worker'
        started = time.perf_counter()
        while_loading = canvas.completed_cycle_average_label_records()
        assert time.perf_counter() - started < .5
        assert len(while_loading) == 1
    finally:
        release.set()
        for worker in threading.enumerate():
            if worker.name == 'v4-cycle-label-numpy-prepare':
                worker.join(3)
        canvas.close()
    assert calls and all(name != threading.main_thread().name for name in calls)


def test_numpy_preload_failure_falls_back_without_retry(monkeypatch):
    import builtins
    import gui_indicator_follow_signal_validation_v4_window as wm
    monkeypatch.setattr(wm, '_cycle_label_numpy_module', None)
    monkeypatch.setattr(wm, '_cycle_label_numpy_started', False)
    invoked = threading.Event()
    calls = []
    original_import = builtins.__import__

    def failing_import(name, *args, **kwargs):
        if name == 'numpy':
            calls.append(threading.current_thread().name)
            invoked.set()
            raise OSError('optional array runtime unavailable')
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, '__import__', failing_import)
    wm._prepare_cycle_label_numpy()
    assert invoked.wait(3)
    for worker in threading.enumerate():
        if worker.name == 'v4-cycle-label-numpy-prepare':
            worker.join(3)
    wm._prepare_cycle_label_numpy()
    assert len(calls) == 1
    assert wm._cycle_label_numpy_module is None


def test_presentation_phase_keeps_output_identical_when_disabled(monkeypatch, case):
    import gui_indicator_follow_signal_validation_v4_window as wm
    import indicator_follow_signal_validation_perf_trace as perf
    from tests.test_indicator_follow_signal_validation_v4_normal_base import candles

    collector = perf.Collector()
    monkeypatch.setattr(perf, '_collector', collector)
    monkeypatch.setattr(perf, 'ENABLED', True)
    monkeypatch.setattr(wm, '_PERF_ENABLED', True)
    rows = candles(80)
    settings = case._seed().settings_snapshot
    enabled_result = wm.prepare_signal_validation_presentation(
        rows, (), settings, chart_start_index=0, chart_count=len(rows),
    )
    recorded = list(collector.queue.queue)
    events = {record['event'] for record in recorded}
    assert {'presentation.indicator_cache', 'presentation.chart_series_mapping'} <= events
    assert all(record.get('thread_cpu_ms', -1) >= 0 for record in recorded)
    assert all(record.get('calculation_bars') == len(rows) for record in recorded)

    monkeypatch.setattr(wm, '_PERF_ENABLED', False)
    disabled_result = wm.prepare_signal_validation_presentation(
        rows, (), settings, chart_start_index=0, chart_count=len(rows),
    )
    assert enabled_result == disabled_result
    assert list(collector.queue.queue) == recorded


def test_marking_off_phase_reports_cause_without_source_data(monkeypatch, case):
    import gui_indicator_follow_signal_validation_v4_window as wm
    import indicator_follow_signal_validation_perf_trace as perf
    from tests.test_indicator_follow_signal_validation_v4_normal_base import window_for

    collector = perf.Collector()
    monkeypatch.setattr(perf, '_collector', collector)
    monkeypatch.setattr(perf, 'ENABLED', True)
    monkeypatch.setattr(wm, '_PERF_ENABLED', True)
    window = window_for(case)
    window._disable_marking(
        clear_cache=True, refresh=False, reason='source_revalidation_failed',
    )
    records = [r for r in collector.queue.queue if r['event'] == 'marking.disabled']
    assert len(records) == 1
    record = records[0]
    assert record['reason'] == 'source_revalidation_failed'
    assert record['clear_cache'] is True
    assert not {'source_hash', 'stock_code', 'account'} & set(record)
