# -*- coding: utf-8 -*-
"""Temporary manual range replay must never be promoted into the base result."""
from __future__ import annotations

from tests.test_indicator_follow_signal_validation_v4_normal_base import (
    case, range_signal_flow, wait_for, marker_keys,
)


def test_normal_origin_range_presentation_refresh_and_clear_do_not_leak_signals(case):
    window, flow = range_signal_flow(case)
    assert not window._entries and not window._calculation_entries
    window._complete_validation_range_drag(40, 60)
    wait_for(case, lambda: window._range_replay_entries_available)
    assert marker_keys(window) == {(42, "BUY"), (55, "SELL")}
    assert window._range_replay_from_normal_base
    assert not window._entries

    window.set_replay_snapshot(window.replay_snapshot, presentation_only=True)
    case.app.processEvents()
    assert window.validation_range == (40, 60)
    assert marker_keys(window) == {(42, "BUY"), (55, "SELL")}
    assert not window._entries and not window._calculation_entries, (
        "range-only replay evidence was promoted to authoritative base"
    )

    window._clear_validation_range_interaction()
    case.app.processEvents()
    assert window.validation_range is None
    assert window.replay_snapshot is None
    assert window._normal_base_ready
    assert not window._entries and not window._calculation_entries
    assert not window._range_replay_entries
    assert marker_keys(window) == set()


def test_normal_origin_range_preserves_scope_after_display_reprojection(case):
    window, flow = range_signal_flow(case)
    window._complete_validation_range_drag(40, 60)
    wait_for(case, lambda: window._range_replay_entries_available)
    selected_times = window._validation_range_times

    # Simulate the legitimate repaint path after display-only sidecar refresh.
    window.set_historical_display_candles(
        list(window._candles), preserve_completed_cycles=True,
    )
    window.set_replay_snapshot(window.replay_snapshot, presentation_only=True)
    case.app.processEvents()
    assert window._validation_range_times == selected_times
    assert marker_keys(window) == {(42, "BUY"), (55, "SELL")}
    assert not window._entries and not window._calculation_entries

    window._clear_validation_range_interaction()
    case.app.processEvents()
    assert window.replay_snapshot is None
    assert window._normal_base_ready
    assert marker_keys(window) == set()



def test_range_then_display_refresh_marking_on_off_never_leaks_manual_markers(case):
    from tests.test_indicator_follow_signal_validation_v4_marking import (
        connected, position_evaluator, turn_on,
    )
    window, flow = connected(case, evaluator=position_evaluator)
    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    assert window._range_replay_from_normal_base
    assert marker_keys(window)

    window.set_replay_snapshot(window.replay_snapshot, presentation_only=True)
    case.app.processEvents()
    assert not window._entries and not window._calculation_entries

    turn_on(case, window)
    assert window.validation_range is None
    assert window.replay_snapshot is None
    assert window._normal_base_ready
    assert {m["provenance"] for m in window.canvas.marker_records()} == {"marking"}
    assert all(m["evaluation_time"] >= window._marking_times[0]
               and m["evaluation_time"] <= window._marking_times[1]
               for m in window.canvas.marker_records())

    window.marking_display_check.setChecked(False)
    wait_for(case, lambda: window._visualization_projection_active is None)
    assert not window.canvas.marker_records()
    assert window.replay_snapshot is None
    assert window._normal_base_ready
    assert not window._entries and not window._calculation_entries
