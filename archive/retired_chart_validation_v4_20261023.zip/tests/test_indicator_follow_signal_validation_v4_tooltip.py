"""V4 display-only title localization and original evidence preservation."""
from unittest.mock import patch

import pytest

from tests.test_indicator_follow_signal_validation_v4_marking import (
    case, connected, position_evaluator, turn_on, wait_for, wm,
)


@pytest.mark.parametrize("manual", [False, True])
def test_korean_titles_preserve_original_evidence_and_execution(case, manual):
    window, flow = connected(case, evaluator=position_evaluator)
    turn_on(case, window)
    if manual:
        window._complete_validation_range_drag(44, 56)
        wait_for(case, lambda: window._range_replay_entries_available)
        window.marking_display_check.setChecked(False)
        window._signal_tooltip_provenance = None
        window._refresh_signal_tooltips_only()
        assert all(record["tooltip"].startswith(("\uB9E4\uC218 ", "\uB9E4\uB3C4 "))
                   for record in window.canvas.marker_records())
    original_records = []
    build = wm._marker_records

    def capture(*args):
        records = build(*args)
        original_records.extend(dict(record) for record in records)
        return records

    with patch.object(wm, "_marker_records", side_effect=capture):
        records = window._chart_marker_records()
    assert {record["side"] for record in records} == {"BUY", "SELL"}
    for original, record in zip(original_records, records):
        side = record["side"]
        korean = "\uB9E4\uC218" if side == "BUY" else "\uB9E4\uB3C4"
        assert original["tooltip"].startswith(side + " ")
        assert record["tooltip"] == korean + original["tooltip"][len(side):]
        assert record["tooltip"].splitlines()[1:] == original["tooltip"].splitlines()[1:]
        assert len(record["tooltip"].splitlines()) > 1
        assert "\uB9C8\uD0B9" not in record["tooltip"]
        assert "\uC120\uD0DD \uAE30\uAC04" not in record["tooltip"]
        assert {key: value for key, value in record.items() if key not in ("tooltip", "provenance")} == {
            key: value for key, value in original.items() if key != "tooltip"}


def test_title_translation_does_not_replace_evidence_or_ticker_text(case):
    window, flow = connected(case, evaluator=position_evaluator)
    turn_on(case, window)
    text = "BUY \u00b7 09/28 14:54\nMA 5: 123.45 / MA 20: 120.00\nBUY SELL BUYER"
    with patch.object(wm, "signal_evidence_tooltip", return_value=text):
        records = window._chart_marker_records()
    assert records
    for record in records:
        assert record["tooltip"].startswith("\uB9E4\uC218" + text[3:])


def test_manual_clear_restores_marking_and_clears_pinned_evidence(case):
    window, flow = connected(case, evaluator=position_evaluator)
    snapshot = turn_on(case, window)
    window._complete_validation_range_drag(44, 56)
    wait_for(case, lambda: window._range_replay_entries_available)
    window.canvas._pinned_marker_key = (45, "BUY")
    window.canvas._active_tooltip = "old manual tooltip"
    window._clear_validation_range_interaction()
    assert window._marking_snapshot is snapshot
    assert window.marking_display_check.isChecked()
    assert window.canvas.pinned_marker_key is None
    assert window.canvas._active_tooltip == ""
